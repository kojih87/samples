﻿using System;
using System.Text;

namespace ZZ.Log
{
    /// <summary>
    /// StringBuilderクラスの拡張メソッドを定義するクラス。
    /// (ZZLoggerからのみ利用)
    /// </summary>
    internal static class StringBuilderExtension
    {
        #region メソッド
        /// <summary>
        /// 文字列バッファが空ではない場合に改行を追加する。
        /// </summary>
        /// <param name="buf">文字列バッファ</param>
        /// <returns>文字列バッファ</returns>
        static StringBuilder AppendLineIfNotEmpty(this StringBuilder buf)
        {
            return (buf.Length > 0)
                ? buf.AppendLine()
                : buf;
        }

        /// <summary>
        /// 文字列バッファにメッセージを追加する。
        /// </summary>
        /// <param name="buf">文字列バッファ</param>
        /// <param name="pattern">メッセージ または メッセージパターン</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        /// <returns>文字列バッファ</returns>
        internal static StringBuilder AppendMessage(this StringBuilder buf, string pattern, params object[] args)
        {
            if (pattern != null)
            {
                if (args == null || args.Length == 0)
                {
                    //メッセージを追加
                    buf.Append(pattern);
                }
                else
                {
                    //整形したメッセージを追加
                    buf.AppendFormat(pattern, args);
                }
            }
            return buf;
        }

        /// <summary>
        /// 文字列バッファに例外の内容を追加する。
        /// </summary>
        /// <param name="buf">文字列バッファ</param>
        /// <param name="index">例外</param>
        /// <returns>文字列バッファ</returns>
        internal static StringBuilder AppendException(this StringBuilder buf, Exception exception)
        {
            const string INDENT = "    ";

            var i = 0;
            for (var e = exception; e != null; e = e.InnerException)
            {
                //例外の内容を追加
                buf.AppendLineIfNotEmpty()
                    .AppendFormat("[{0,2}] {1}: {2}", i++, e.GetType(), e.Message).AppendLine()
                    .Append(INDENT).Append(e.StackTrace.Replace(Environment.NewLine, Environment.NewLine + INDENT));
            }
            return buf;
        }
        #endregion
    }
}
