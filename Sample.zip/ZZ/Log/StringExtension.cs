﻿namespace ZZ.Log
{
    /// <summary>
    /// stringクラスの拡張メソッドを定義するクラス。
    /// (ZZLoggerからのみ利用)
    /// </summary>
    internal static class StringExtension
    {
        #region 定数
        /// <summary>
        /// CSV特殊文字を定義する。
        /// </summary>
        static readonly char[] CSV_SPECIAL_CHARS = new char[] { '"', ',', '\r', '\n' };
        #endregion


        #region メソッド
        /// <summary>
        /// 文字列内にCSV特殊文字が存在 または 強制フラグがtrue の場合、
        /// 囲み文字をエスケープして両端に追加する。
        /// </summary>
        /// <param name="field">文字列</param>
        /// <param name="isForced">強制フラグ</param>
        /// <returns>編集後の文字列</returns>
        internal static string EscapeCsv(this string field, bool isForced = false)
        {
            //CSV特殊文字が存在 または 強制フラグがtrue の場合
            if (isForced || field?.IndexOfAny(CSV_SPECIAL_CHARS) >= 0)
            {
                field = string.Format("\"{0}\"", field.Replace("\"", "\"\""));
            }
            return field;
        }
        #endregion
    }
}
