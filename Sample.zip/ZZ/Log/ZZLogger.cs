﻿using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Core;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace ZZ.Log
{
    /// <summary>
    /// アプリケーションログを出力するクラス。
    /// </summary>
    public class ZZLogger
    {
        #region 変数
        /// <summary>
        /// log4netにメッセージを記録するためのオブジェクトを格納する。
        /// </summary>
        ILog _log;

        /// <summary>
        /// log4netにメッセージを記録するためのオブジェクトを格納する。(イベントログ用)
        /// </summary>
        ILog _eventLog;
        #endregion


        #region プロパティ
        /// <summary>
        /// ユーザ識別情報を取得・設定する。
        /// </summary>
        public static string User { get; set; }
        #endregion


        #region 生成・破棄
        /// <summary>
        /// クラスフィールドを初期化する。
        /// </summary>
        static ZZLogger()
        {
            //log4net設定ファイルの読み込み
            XmlConfigurator.ConfigureAndWatch(new FileInfo(@"log4net.config"));

            //ログファイル名の動的変更
            const string REP_FILENAME = "REPLACE_PATH";
            var appenders = LogManager.GetRepository().GetAppenders()
                .Where(appender => appender is FileAppender).ToArray();
            foreach (FileAppender appender in appenders)
            {
                var fileName = appender.File;
                if (fileName.Contains(REP_FILENAME))
                {
                    //置換後のログファイルパス
                    var asmLocation = Assembly.GetEntryAssembly()?.Location
                        ?? Assembly.GetCallingAssembly()?.Location
                        ?? "UnknownAssembly";
                    var asmName = Path.GetFileNameWithoutExtension(asmLocation);
                    var afterPath = asmName + "/" + asmName;

                    //ログファイルパスの置換
                    appender.File = Regex.Replace(fileName, REP_FILENAME + ".*", afterPath);
                    appender.ActivateOptions();
                    //旧ファイルの削除
                    if (File.Exists(fileName))
                    {
                        File.Delete(fileName);
                    }
                }
            }
        }

        /// <summary>
        /// インスタンスフィールドを初期化する。
        /// </summary>
        /// <param name="callerType">ログ名</param>
        ZZLogger(string name)
        {
            _log = LogManager.GetLogger(name);
            _eventLog = LogManager.GetLogger("EventLog");
        }

        /// <summary>
        /// 呼び出し元の型専用のログ出力オブジェクトを取得する。
        /// </summary>
        /// <returns>ログ出力オブジェクト</returns>
        public static ZZLogger GetLogger()
        {
            //呼び出し元の型でログ出力オブジェクトを生成
            var callerType = new StackFrame(1).GetMethod().DeclaringType;
            return new ZZLogger(callerType.FullName);
        }
        #endregion


        #region メソッド
        #region 非公開
        /// <summary>
        /// ログを出力する。
        /// </summary>
        /// <param name="level">ログレベル</param>
        /// <param name="pattern">メッセージ または メッセージパターン</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        /// <param name="exception">発生した例外</param>
        void Write(Level level, string pattern, object[] args, Exception exception)
        {
            //出力する情報の取得
            var message = new StringBuilder()
                //メッセージ
                .AppendMessage(pattern, args)
                //例外内容
                .AppendException(exception)
                //文字列化
                .ToString()
                .TrimEnd('\r', '\n');

            //ログ出力
            _log.Logger.Log(null, level, string.Format("{0},{1}", User, message.EscapeCsv()), null);
        }

        /// <summary>
        /// イベントログを出力する。
        /// </summary>
        /// <param name="level">ログレベル</param>
        /// <param name="pattern">メッセージ または メッセージパターン</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        void WriteEvent(Level level, string pattern, object[] args)
        {
            //出力する情報の取得
            var message = new StringBuilder()
                //メッセージ
                .AppendMessage(pattern, args)
                //文字列化
                .ToString()
                .TrimEnd('\r', '\n');

            //イベントログ出力
            _eventLog.Logger.Log(null, level, message, null);
        }
        #endregion

        /// <summary>
        /// デバッグログを出力する。
        /// </summary>
        /// <param name="pattern">メッセージ または メッセージパターン</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void Debug(string pattern, params object[] args)
        {
            Write(Level.Debug, pattern, args, null);
        }

        /// <summary>
        /// 情報ログを出力する。
        /// </summary>
        /// <param name="messageId">メッセージID</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void Info(string messageId, params object[] args)
        {
            Write(Level.Info, messageId, args, null);
        }

        /// <summary>
        /// 警告ログを出力する。
        /// </summary>
        /// <param name="messageId">メッセージID</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void Warn(string messageId, params object[] args)
        {
            Write(Level.Warn, messageId, args, null);
        }
        /// <summary>
        /// 警告ログを出力する。
        /// </summary>
        /// <param name="exception">発生した例外</param>
        /// <param name="messageId">メッセージID</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void Warn(Exception exception, string messageId = null, params object[] args)
        {
            Write(Level.Warn, messageId, args, exception);
        }

        /// <summary>
        /// エラーログを出力する。
        /// </summary>
        /// <param name="messageId">メッセージID</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void Error(string messageId, params object[] args)
        {
            Write(Level.Error, messageId, args, null);
        }
        /// <summary>
        /// エラーログを出力する。
        /// </summary>
        /// <param name="exception">発生した例外</param>
        /// <param name="messageId">メッセージID</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void Error(Exception exception, string messageId = null, params object[] args)
        {
            Write(Level.Error, messageId, args, exception);
        }

        /// <summary>
        /// 致命的なエラーログを出力する。
        /// </summary>
        /// <param name="messageId">メッセージID</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void Fatal(string messageId, params object[] args)
        {
            Write(Level.Fatal, messageId, args, null);
        }
        /// <summary>
        /// 致命的なエラーログを出力する。
        /// </summary>
        /// <param name="exception">発生した例外</param>
        /// <param name="messageId">メッセージID</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void Fatal(Exception exception, string messageId = null, params object[] args)
        {
            Write(Level.Fatal, messageId, args, exception);
        }

        /// <summary>
        /// イベントログにエラーログを出力する。
        /// </summary>
        /// <param name="messageId">メッセージID</param>
        /// <param name="args">メッセージパターンの置換オブジェクト</param>
        public void ErrorEvent(string messageId, params object[] args)
        {
            WriteEvent(Level.Error, messageId, args);
        }
        #endregion
    }
}
