﻿using System;

namespace ZZ.DB
{
    /// <summary>
    /// Typeクラスの拡張メソッドを定義するクラス。
    /// (ZZDBManagerからのみ利用)
    /// </summary>
    internal static class TypeExtension
    {
        #region メソッド
        /// <summary>
        /// Null許容型の場合はベースの型を取得する。
        /// </summary>
        /// <param name="type">型</param>
        /// <returns>Null許容型の場合はベースの型、そうでない場合は指定した型</returns>
        internal static Type GetGenericTypeIfNullable(this Type type)
        {
            // Null許容型の場合
            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                return type.GenericTypeArguments[0];
            }
            return type;
        }
        #endregion
    }
}
