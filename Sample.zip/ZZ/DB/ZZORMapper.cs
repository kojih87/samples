﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace ZZ.DB
{
    /// <summary>
    /// レコードとオブジェクトのマッピングをするクラス。
    /// </summary>
    /// <typeparam name="TType">オブジェクトの型</typeparam>
    public class ZZORMapper<TType>
    {
        #region 変数
        /// <summary>
        /// 型変換処理を格納する。
        /// </summary>
        Func<object, Type, object> _convert;

        /// <summary>
        /// レコード読み込み処理を格納する。
        /// </summary>
        Func<DbDataReader, TType> _loadRecord;

        /// <summary>
        /// 列番号に対応するプロパティ情報のマップを格納する。
        /// </summary>
        Dictionary<int, PropertyInfo> _map;
        #endregion


        #region 生成・解放
        /// <summary>
        /// インスタンスフィールドを初期化する。
        /// </summary>
        /// <param name="convert">型変換処理</param>
        /// <param name="reader">レコード (オブジェクトへのマッピングを行わない場合は省略)</param>
        public ZZORMapper(Func<object, Type, object> convert, DbDataReader reader = null)
        {
            var type = typeof(TType);

            //型変換処理の設定
            _convert = convert;

            //値の場合
            if (reader == null)
            {
                //レコード読み込み処理の設定
                _loadRecord = LoadRecordToValue;
            }
            //オブジェクトの場合
            else
            {
                //レコード読み込み処理の設定
                _loadRecord = LoadRecordToObject;

                //キー変換処理
                string convertKey(string name) => Regex.Replace(name, "_", "").ToUpper();

                //プロパティ情報の取得
                var props = type
                    .GetProperties(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy)
                    .ToDictionary(prop => convertKey(prop.Name));

                //列番号に対応するプロパティ情報のマップを生成
                _map = new Dictionary<int, PropertyInfo>();
                for (var i = 0; i < reader.FieldCount; i++)
                {
                    //列名の変換 ("_"を除去、大文字化)
                    var key = convertKey(reader.GetName(i));

                    //対応するプロパティの有無判定
                    if (props.ContainsKey(key) == false)
                    {
                        continue;
                    }

                    //追加
                    _map.Add(i, props[key]);
                }
            }
        }
        #endregion


        #region メソッド
        #region 非公開
        /// <summary>
        /// レコードの内容をオブジェクトに読み込む。(先頭列)
        /// </summary>
        /// <param name="reader">レコード</param>
        /// <returns>オブジェクト</returns>
        TType LoadRecordToValue(DbDataReader reader)
        {
            return (TType)_convert(reader[0], typeof(TType));
        }

        /// <summary>
        /// レコードの内容をオブジェクトに読み込む。(マッピング)
        /// </summary>
        /// <param name="reader">レコード</param>
        /// <returns>オブジェクト</returns>
        TType LoadRecordToObject(DbDataReader reader)
        {
            //オブジェクトの生成
            var obj = Activator.CreateInstance<TType>();

            //列番号に対応するプロパティに値を設定
            foreach (var e in _map)
            {
                var prop = e.Value;
                var value = _convert(reader[e.Key], prop.PropertyType);
                prop.SetValue(obj, value);
            }

            return obj;
        }
        #endregion

        /// <summary>
        /// レコードの内容をオブジェクトに読み込む。
        /// </summary>
        /// <param name="reader">レコード</param>
        /// <returns>オブジェクト</returns>
        public TType LoadRecord(DbDataReader reader)
        {
            return _loadRecord(reader);
        }
        #endregion
    }
}
