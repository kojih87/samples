﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;

namespace ZZ.DB
{
    /// <summary>
    /// データベース操作を管理するクラス。
    /// </summary>
    public class ZZDBManager
    {
        #region 定数
        /// <summary>
        /// 型に対応する型変換処理を定義する。
        /// </summary>
        static readonly Dictionary<Type, Func<Type, string, object>> CONVERT_MAP =
            new Dictionary<Type, Func<Type, string, object>>()
            {
                // 真偽値
                { typeof(bool), (t, s) => bool.Parse(s) },
                // 整数型
                { typeof(sbyte), (t, s) => sbyte.Parse(s) },
                { typeof(short), (t, s) => short.Parse(s) },
                { typeof(int), (t, s) => int.Parse(s) },
                { typeof(long), (t, s) => long.Parse(s) },
                { typeof(byte), (t, s) => byte.Parse(s) },
                { typeof(ushort), (t, s) => ushort.Parse(s) },
                { typeof(uint), (t, s) => uint.Parse(s) },
                { typeof(ulong), (t, s) => ulong.Parse(s) },
                // 浮動小数点型
                { typeof(float), (t, s) => float.Parse(s) },
                { typeof(double), (t, s) => double.Parse(s) },
                // 固定小数点型
                { typeof(decimal), (t, s) => decimal.Parse(s) },
                // 文字/文字列型
                { typeof(char), (t, s) => char.Parse(s) },
                { typeof(string), (t, s) => s },
                // 日付/時刻型
                { typeof(DateTime), (t, s) => DateTime.Parse(s) },
                // 列挙型
                { typeof(Enum), (t, s) => Enum.Parse(t, s) }
            };
        #endregion


        #region 変数
        /// <summary>
        /// コネクションを格納する。
        /// </summary>
        NpgsqlConnection _con;

        /// <summary>
        /// トランザクションを格納する。
        /// </summary>
        NpgsqlTransaction _tran;

        /// <summary>
        /// コマンドを格納する。
        /// </summary>
        NpgsqlCommand _cmd;
        #endregion


        #region 生成・破棄
        /// <summary>
        /// インスタンスを初期化する。
        /// </summary>
        public ZZDBManager()
        {
        }
        #endregion


        #region メソッド - コネクション
        /// <summary>
        /// コネクションを開く。
        /// </summary>
        public void Open()
        {
            //既に開いている場合
            if (_con != null)
            {
                return;
            }

            //コネクションを開く
            var conStr = ConfigurationManager.ConnectionStrings["skdb"].ConnectionString;
            _con = new NpgsqlConnection(conStr);
            _con.Open();
        }

        /// <summary>
        /// コネクションを閉じる。
        /// </summary>
        public void Close()
        {
            //コネクションが開いていない場合
            if (_con == null)
            {
                return;
            }

            //コマンドのクリア
            ClearCommand();
            //トランザクションの終了
            Rollback();

            //コネクションを閉じる
            _con.Close();
            _con = null;
        }
        #endregion


        #region メソッド - トランザクション
        /// <summary>
        /// トランザクションを開始する。
        /// </summary>
        public void BeginTransaction()
        {
            //トランザクションが既に開始されている場合
            if (_tran != null)
            {
                return;
            }

            //トランザクションの開始
            _tran = _con.BeginTransaction();
        }

        /// <summary>
        /// トランザクションを終了する。(コミット)
        /// </summary>
        public void Commit()
        {
            //トランザクションが開始されていない場合
            if (_tran == null)
            {
                return;
            }

            //トランザクションの終了
            _tran.Commit();
        }

        /// <summary>
        /// トランザクションを終了する。(ロールバック)
        /// </summary>
        public void Rollback()
        {
            //トランザクションが開始されていない場合
            if (_tran == null)
            {
                return;
            }

            //トランザクションの終了
            _tran.Rollback();
        }
        #endregion


        #region メソッド - コマンド設定
        #region 非公開
        /// <summary>
        /// コマンドをクリアする。
        /// </summary>
        void ClearCommand()
        {
            //コマンドが存在しない場合
            if (_cmd == null)
            {
                return;
            }

            //コマンドの破棄
            _cmd.Dispose();
            _cmd = null;
        }
        #endregion

        /// <summary>
        /// コマンドを設定する。
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="type">タイプ</param>
        public void SetCommand(string text, CommandType type = CommandType.Text)
        {
            if (_cmd == null)
            {
                //コマンドの生成
                _cmd = _con.CreateCommand();
            }
            else
            {
                //コマンドパラメータのクリア
                _cmd.Parameters.Clear();
            }

            //コマンドの設定
            _cmd.CommandType = type;
            _cmd.CommandText = text;
        }

        /// <summary>
        /// コマンドパラメータを設定する。
        /// </summary>
        public void SetCommandParameter(string name, object value)
        {
            if (_cmd.Parameters.Contains(name) == false)
            {
                //パラメータの追加
                var param = _cmd.CreateParameter();
                param.ParameterName = name;
                _cmd.Parameters.AddWithValue(name, value);
            }

            //パラメータの設定
            _cmd.Parameters[name].Value = value;
        }
        #endregion


        #region メソッド - コマンド実行
        #region 非公開
        /// <summary>
        /// 値の型を返還する。
        /// </summary>
        /// <param name="value">値</param>
        /// <param name="type">変換後の型</param>
        /// <returns>変換後の値</returns>
        object Convert(object value, Type type)
        {
            //値がnullの場合
            if (value == null || value is DBNull)
            {
                return null;
            }

            //型変換が不要な場合
            var oldType = value.GetType();
            var newType = type.GetGenericTypeIfNullable();
            if (oldType == newType)
            {
                return value;
            }

            //型変換が必要な場合
            var strVal = value.ToString();
            return CONVERT_MAP[newType](newType, strVal);
        }
        #endregion

        /// <summary>
        /// INSERT/UPDATE/DELETE文を実行して、影響を与えた件数を取得する。
        /// </summary>
        /// <returns>件数</returns>
        public int ExecuteNonQuery()
        {
            //更新クエリの実行
            return _cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// SELECT文を実行して、抽出結果を取得する。(先頭行/先頭列)
        /// </summary>
        /// <typeparam name="T">抽出結果の型</typeparam>
        /// <returns>抽出結果</returns>
        public T ExecuteScalar<T>()
        {
            //選択クエリの実行
            var value = _cmd.ExecuteScalar();

            //型変換
            return (T)Convert(value, typeof(T));
        }

        /// <summary>
        /// SELECT文を実行して、抽出結果を取得する。(先頭行)
        /// </summary>
        /// <typeparam name="T">抽出結果の型</typeparam>
        /// <returns>抽出結果</returns>
        public T ExecuteReaderOnce<T>()
        {
            //選択クエリの実行
            using (var reader = _cmd.ExecuteReader())
            {
                //O/Rマッパの生成
                var mapper = new ZZORMapper<T>(Convert,
                    (CONVERT_MAP.ContainsKey(typeof(T))) ? null : reader);

                //抽出結果の取得(先頭行)
                var ret = default(T);
                if (reader.Read())
                {
                    //レコードからオブジェクトの生成
                    ret = mapper.LoadRecord(reader);
                }

                return ret;
            }
        }

        /// <summary>
        /// SELECT文を実行して、抽出結果を取得する。
        /// </summary>
        /// <typeparam name="T">抽出結果の型</typeparam>
        /// <returns>抽出結果リスト</returns>
        public List<T> ExecuteReader<T>()
        {
            //選択クエリの実行
            using (var reader = _cmd.ExecuteReader())
            {
                //O/Rマッパの生成
                var mapper = new ZZORMapper<T>(Convert,
                    (CONVERT_MAP.ContainsKey(typeof(T))) ? null : reader);

                //抽出結果の取得
                var list = new List<T>();
                while (reader.Read())
                {
                    //レコードからオブジェクトの生成
                    list.Add(mapper.LoadRecord(reader));
                }

                return list;
            }
        }

        /// <summary>
        /// SELECT文を実行して、抽出結果を取得する。(汎用)
        /// </summary>
        /// <returns>データテーブル</returns>
        public DataTable ExecuteReader()
        {
            //選択クエリの実行
            using (var reader = _cmd.ExecuteReader())
            {
                //データテーブルに読み込み
                var table = new DataTable();
                table.Load(reader);
                return table;
            }
        }
        #endregion
    }
}