﻿namespace Test.Defines.Dto
{
    /// <summary>
    /// テストケース共通情報を保持するクラス。
    /// </summary>
    public abstract class TestCaseInfo
    {
        #region プロパティ
        /// <summary>
        /// テストケース番号を取得・設定する。
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// テストケース名を取得・設定する。
        /// </summary>
        public string Name { get; set; }
        #endregion
    }
}
