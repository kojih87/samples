﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Test.Defines.Dto
{
    /// <summary>
    /// テストケース情報(モデル)を保持するクラス。
    /// </summary>
    public class TestCaseModelInfo : TestCaseInfo
    {
        #region プロパティ
        /// <summary>
        /// テスト対象型を取得・設定する。
        /// </summary>
        public Type Type { get; set; }

        /// <summary>
        /// テスト対象メソッドを取得・設定する。
        /// </summary>
        public MethodInfo Method { get; set; }

        /// <summary>
        /// テスト対象メソッドの引数を取得・設定する。
        /// </summary>
        public object[] MethodParameters { get; set; }


        /// <summary>
        /// 実行結果(期待値)を取得・設定する。
        /// </summary>
        public ResultInfo ExpectedResult { get; set; }

        /// <summary>
        /// ログ出力(期待値)を取得・設定する。
        /// </summary>
        public LogInfo ExpectedLog { get; set; }

        /// <summary>
        /// データベース更新期待値ファイルパスを取得・設定する。
        /// </summary>
        public string ExpectedDatabase { get; set; }

        /// <summary>
        /// ファイル出力期待値フォルダパスを取得・設定する。
        /// </summary>
        public string ExpectedFile { get; set; }

        /// <summary>
        /// ローカルグループメンバ更新期待値ファイルパスを取得・設定する。
        /// </summary>
        public string ExpectedLocalGroup { get; set; }
        #endregion


        #region メソッド

        public object Invoke()
        {
            return null;
        }


        #endregion
    }
}
