﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Test.Defines.Dto
{
    public class TestCaseControllerInfo : TestCaseInfo
    {
        #region プロパティ



        /// <summary>
        /// テスト対象のHTTPメソッドを取得・設定する。
        /// </summary>
        public HttpMethod HttpMethod { get; set; }

        /// <summary>
        /// テスト対象のURIを取得・設定する。
        /// </summary>
        public string Uri { get; set; }

        public Dictionary<string, object> Pa { get; set; }


        /// <summary>
        /// HTTP応答期待値を取得・設定する。
        /// </summary>
        public HttpResponseInfo Expected { get; set; }
        #endregion


    }
}
