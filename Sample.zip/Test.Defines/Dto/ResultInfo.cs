﻿namespace Test.Defines.Dto
{
    /// <summary>
    /// 実行結果の情報を保持するクラス。
    /// </summary>
    public class ResultInfo
    {
        #region プロパティ
        /// <summary>
        /// 戻り値を取得・設定する。
        /// </summary>
        public object ReturnValue { get; set; }

        /// <summary>
        /// 発生した例外の型名を取得・設定する。
        /// </summary>
        public string ThrowsExceptionTypeName { get; set; }
        #endregion
    }
}
