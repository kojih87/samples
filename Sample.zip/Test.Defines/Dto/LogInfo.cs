﻿namespace Test.Defines.Dto
{
    /// <summary>
    /// ログファイルの情報を保持するクラス。
    /// </summary>
    public class LogInfo
    {
        #region プロパティ
        /// <summary>
        /// ログのファイルパスを取得・設定する。
        /// </summary>
        public string LogFile { get; set; }

        /// <summary>
        /// イベントログのファイルパスを取得・設定する。
        /// </summary>
        public string EventLogFile { get; set; }
        #endregion
    }
}
