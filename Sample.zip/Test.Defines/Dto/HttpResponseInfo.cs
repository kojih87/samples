﻿using System.Net;

namespace Test.Defines.Dto
{
    /// <summary>
    /// HTTP応答の情報を保持するクラス。
    /// </summary>
    public class HttpResponseInfo
    {
        #region プロパティ
        /// <summary>
        /// HTTPステータスコードを取得・設定する。
        /// </summary>
        public HttpStatusCode StatusCode { get; set; }

        /// <summary>
        /// HTTP応答内容を取得・設定する。
        /// </summary>
        public string ContentText { get; set; }
        #endregion
    }
}
