﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Defines.Dto
{
    /// <summary>
    /// モックの情報を保持するクラス。
    /// </summary>
    public class MockInfo
    {
        #region プロパティ


        #endregion
    }
}
