﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Defines
{
    /// <summary>
    /// テストで使用する定数を定義するクラス。
    /// </summary>
    public static class TestConst
    {
        /// <summary>
        /// ファイルパスに関する定数を定義する内部クラス。
        /// </summary>
        public static class Path
        {
            /// <summary>
            /// テスト資源格納フォルダのパスを定義する。
            /// ※プロジェクトフォルダからの相対パス
            /// </summary>
            public const string DIR_ROOT = @"テスト資源";

            /// <summary>
            /// テストケース格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_TESTCASE = @"";

            /// <summary>
            /// オブジェクト定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_OBJECT = @"オブジェクト";

            /// <summary>
            /// モック定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_MOCK = @"Mock定義";

            /// <summary>
            /// データベース初期化定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_INIT_DB = @"初期化\DB";

            /// <summary>
            /// ファイル初期化定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_INIT_FILE = @"初期化\ファイル";

            /// <summary>
            /// ローカルグループ初期化定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_INIT_GROUP = @"初期化\ローカルグループ";

            /// <summary>
            /// ログ出力期待値定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_EXP_LOG = @"期待値\ログ出力";

            /// <summary>
            /// イベントログ出力期待値定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_EXP_EVTLOG = @"期待値\イベントログ出力";

            /// <summary>
            /// データベース更新期待値定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_EXP_DB = @"期待値\DB更新";

            /// <summary>
            /// ファイル出力期待値格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_EXP_FILE = @"期待値\ファイル出力";

            /// <summary>
            /// ローカルグループ期待値定義格納フォルダのパスを定義する。
            /// ※テスト資源からの相対パス
            /// </summary>
            public const string DIR_EXP_GROUP = @"期待値\ローカルグループ";

            /// <summary>
            /// ログファイルパス(実績値)を定義する。
            /// ※カレントディレクトリからの相対パス
            /// </summary>
            public const string FILE_ACT_LOG = "debug.log";

            /// <summary>
            /// イベントログファイルパス(実績値)を定義する。
            /// ※カレントディレクトリからの相対パス
            /// </summary>
            public const string FILE_ACT_EVTLOG = "event.log";
        }

        /// <summary>
        /// Excelに関する定数を定義する内部クラス。
        /// </summary>
        public static class Excel
        {

            /// <summary>
            /// 開始行番号を定義する。
            /// </summary>
            public const int ROW_START = 5;
        }


        public static class Account
        {
            public const string GROUP = "LG_";
        }
    }
}
