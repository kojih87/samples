﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Defines.Dto;
using Test.IO;

namespace Test
{
    /// <summary>
    /// Excelからテストケースを読み込み、単体テストを実施する基底クラス。
    /// </summary>
    public abstract partial class TestRunnerBase
    {
        #region メソッド
        /// <summary>
        /// Excelからテストケース情報を読み込む。
        /// </summary>
        /// <returns>テストケース情報リスト</returns>
        public static List<TestCaseInfo> LoadTestCase()
        {
            using (var xls = new ExcelManager())
            {
                var list = new List<TestCaseInfo>();

                list.Add(new TestCaseModelInfo());
                list.Add(new TestCaseModelInfo());


                return list;
            }
        }


        #endregion
    }
}
