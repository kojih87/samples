﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Defines;
using Test.Defines.Dto;
using Test.IO;
using ZZ.DB;

namespace Test
{
    /// <summary>
    /// Excelからテストケースを読み込み、単体テストを実施する基底クラス。
    /// </summary>
    public abstract partial class TestRunnerBase
    {
        #region 定数

        #endregion


        #region 変数
        /// <summary>
        /// 
        /// </summary>
        ZZDBManager _dbMngr = null;
        #endregion


        #region メソッド

        #endregion
        /// <summary>
        /// モデルのテストを実施する。
        /// </summary>
        /// <param name="info">テストケース情報(モデル)</param>
        void Run(TestCaseModelInfo info)
        {
            //■■■■■■■■■■■■■■■ 準備 ■■■■■■■■■■■■■■■


            //■■■■■■■■■■■■■■■ 実行 ■■■■■■■■■■■■■■■
            WriteLine();
            var actual = new ResultInfo();
            try
            {
                //テスト対象メソッドの実行
                actual.ReturnValue = info.Invoke();
            }
            catch (Exception ex)
            {
                //発生した例外
                actual.ThrowsExceptionTypeName = ex.GetType().FullName;
            }
            WriteLine();

            //■■■■■■■■■■■■■■■ 検証 ■■■■■■■■■■■■■■■
            //実行結果(戻り値、発生した例外)
            VerifyResult(info.ExpectedResult, actual);
            //ログ出力(ログ、イベントログ)
            VerifyLog(info.ExpectedLog);
            //データベース更新
            VerifyDatabase(info.ExpectedDatabase);
            //ファイル出力
            VerifyFile(info.ExpectedFile);
            //ローカルグループメンバ更新
            VerifyLocalGroup(info.ExpectedLocalGroup);
        }


        /// <summary>
        /// 実行結果を検証する。
        /// </summary>
        /// <param name="expected">期待値</param>
        /// <param name="actual">実績値</param>
        void VerifyResult(ResultInfo expected, ResultInfo actual)
        {
            //戻り値の検証
            AssertAreEqual(expected.ReturnValue,
                actual.ReturnValue, "検証：戻り値");

            //発生した例外の検証
            AssertAreEqual(expected.ThrowsExceptionTypeName,
                actual.ThrowsExceptionTypeName, "検証：発生した例外");
        }

        /// <summary>
        /// ログ出力を検証する。
        /// </summary>
        /// <param name="expected">期待値</param>
        void VerifyLog(LogInfo expected)
        {
            //ログ出力の検証
            var actualLogFile = TestConst.Path.FILE_ACT_LOG;
            if (expected.LogFile == null)
            {
                var file = new FileInfo(actualLogFile);
                AssertAreEqual(0, file.Length, "検証：ログ出力(空)");
            }
            else
            {
                FileAssertAreEqual(expected.LogFile,
                    actualLogFile, "検証：ログ出力");
            }

            //イベントログ出力の検証
            var actualEventLogFile = TestConst.Path.FILE_ACT_EVTLOG;
            if (expected.EventLogFile == null)
            {
                var file = new FileInfo(actualEventLogFile);
                AssertAreEqual(0, file.Length, "検証：ログ出力(空)");
            }
            else
            {
                FileAssertAreEqual(expected.EventLogFile,
                    actualEventLogFile, "検証：イベントログ出力");
            }
        }

        /// <summary>
        /// データベース更新を検証する。
        /// </summary>
        /// <param name="expected">期待値ファイルパス</param>
        void VerifyDatabase(string expected)
        {
            if (expected == null)
            {
                return;
            }

            using (var xls = new ExcelManager())
            {
                //期待値ファイルを開く
                xls.Open(expected);
                //ワークシート名リストを取得
                var names = xls.GetWorksheetNames();

                foreach (var name in names)
                {
                    //ワークシートを選択
                    xls.SelectWorksheet(name);
                    //列名リストの取得
                    var columns = xls.GetColumnValues(TestConst.Excel.ROW_START - 1, 1);



                    //行数分繰り返す
                    for (var row = TestConst.Excel.ROW_START; xls.IsEnableCell(row, 1); row++)
                    {
                        foreach (var col in columns)
                        {

                        }
                    }

                }




            }
        }

        void VerifyFile(string expected)
        {
            if (expected == null)
            {
                return;
            }

        }

        /// <summary>
        /// ローカルグループメンバ更新を検証する。
        /// </summary>
        /// <param name="expected">期待値ファイルパス</param>
        void VerifyLocalGroup(string expected)
        {
            if (expected == null)
            {
                return;
            }

            //期待値の取得
            var expectedMembers = new List<string>();
            using (var xls = new ExcelManager())
            {
                xls.Open(expected);
                xls.SelectWorksheet();
                for (var row = TestConst.Excel.ROW_START; xls.HasCellValue(row, 1); row++)
                {
                    expectedMembers.Add(xls.GetCellValue(row, 1));
                }
            }

            //実績値の取得
            var context = new PrincipalContext(ContextType.Machine);
            var group = GroupPrincipal.FindByIdentity(context, TestConst.Account.GROUP);
            var actualMembers = group.Members
                .Select(p => (p as UserPrincipal).Name)
                .ToList();

            //ローカルグループの検証
            AssertAreEqual(expectedMembers,
                actualMembers, "検証：ローカルグループメンバ更新");
        }

        /// <summary>
        /// 期待値と実績値が一致するか検証する。
        /// </summary>
        /// <param name="expected">期待値</param>
        /// <param name="actual">実績値</param>
        /// <param name="message">メッセージ または メッセージパターン</param>
        /// <param name="args">メッセージパターンに埋め込むオブジェクト配列</param>
        void AssertAreEqual(object expected, object actual, string message, params object[] args)
        {
            Console.WriteLine(message, args);
            Assert.AreEqual(expected, actual, message, args);
        }

        /// <summary>
        /// 期待値ファイルと実績値ファイルの内容が一致するか検証する。
        /// </summary>
        /// <param name="expected">期待値ファイルパス</param>
        /// <param name="actual">実績値ファイルパス</param>
        /// <param name="message">メッセージ または メッセージパターン</param>
        /// <param name="args">メッセージパターンに埋め込むオブジェクト配列</param>
        void FileAssertAreEqual(string expected, string actual, string message, params object[] args)
        {
            Console.WriteLine(message, args);
            FileAssert.AreEqual(expected, actual, message, args);
        }
    }
}
