﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using Test.Defines.Dto;

namespace Test
{
    /// <summary>
    /// Excelからテストケースを読み込み、単体テストを実施する基底クラス。
    /// </summary>
    public abstract partial class TestRunnerBase
    {
        #region メソッド
        /// <summary>
        /// コントローラのテストを実施する。
        /// </summary>
        /// <param name="info">テストケース情報(コントローラ)</param>
        void Run(TestCaseControllerInfo info)
        {

            //■■■■■■■■■■■■■■■ 準備 ■■■■■■■■■■■■■■■
            //インメモリサーバの取得
            var server = GetHttpServer();


            //■■■■■■■■■■■■■■■ 実行 ■■■■■■■■■■■■■■■
            var actual = new HttpResponseInfo();
            using (var client = new HttpMessageInvoker(server))
            {
                //HTTP要求
                using (var req = CreateHttpRequest(info.HttpMethod, info.Uri))
                using (var res = client.SendAsync(req, CancellationToken.None).Result)
                {
                    //HTTPステータスコード
                    actual.StatusCode = res.StatusCode;
                    //HTTP応答内容
                    actual.ContentText = res.Content.ReadAsStringAsync().Result;
                }
            }

            //■■■■■■■■■■■■■■■ 検証 ■■■■■■■■■■■■■■■
            //HTTP応答
            VerifyHttpResponse(info.Expected, actual);
        }



        HttpServer GetHttpServer()
        {
            if (_server == null)
            {
                var config = new HttpConfiguration();




                _server = new HttpServer(config);

            }
            return _server;
        }

        HttpRequestMessage CreateHttpRequest(HttpMethod method, string uri)
        {
            //HTTP要求の生成
            var req = new HttpRequestMessage(method, uri);



            return req;
        }


        void VerifyHttpResponse(HttpResponseInfo expected, HttpResponseInfo actual)
        {
            //HTTPステータスコードの検証
            AssertAreEqual(expected.StatusCode,
                actual.StatusCode, "検証：HTTPステータスコード");

            //HTTP応答内容の検証
            AssertAreEqual(expected.ContentText,
                actual.ContentText, "検証：HTTP応答内容");
        }

        #endregion
    }
}
