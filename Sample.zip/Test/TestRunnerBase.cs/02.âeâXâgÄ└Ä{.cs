﻿using NUnit.Framework;
using System;
using System.Web.Http;
using Test.Defines.Dto;

namespace Test
{
    /// <summary>
    /// Excelからテストケースを読み込み、単体テストを実施する基底クラス。
    /// </summary>
    public abstract partial class TestRunnerBase
    {
        #region 変数
        /// <summary>
        /// インメモリサーバを格納する。
        /// </summary>
        HttpServer _server = null;
        #endregion


        #region メソッド
        /// <summary>
        /// 最初の1度だけ、単体テストの前処理を行う。
        /// </summary>
        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            Console.WriteLine("OneTimeSetUp");
        }

        /// <summary>
        /// 単体テストの前処理を行う。
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            Console.WriteLine("SetUp");
        }

        /// <summary>
        /// 読み込んだテストケース情報をもとに単体テストを実施する。
        /// </summary>
        /// <param name="info">テストケース情報</param>
        [TestCaseSource("LoadTestCase")]
        public void Run(TestCaseInfo info)
        {
            Console.WriteLine("Run");
            //テストケース情報(モデル)の場合
            if (info is TestCaseModelInfo modelInfo)
            {
                Run(modelInfo);
            }
            //テストケース情報(コントローラ)の場合
            else if (info is TestCaseControllerInfo controlInfo)
            {
                Run(controlInfo);
            }
        }

        /// <summary>
        /// 単体テストの後処理を行う。
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            Console.WriteLine("TearDown");
        }

        /// <summary>
        /// 最後の1度だけ、単体テストの後処理を行う。
        /// </summary>
        [OneTimeTearDown]
        public void OneTimeTearDown()
        {
            //インメモリサーバの解放
            _server?.Dispose();
            _server = null;
        }

        #region 非公開

        void Write(string message)
        {
            Console.WriteLine("----------", message);
        }
        void WriteLine()
        {
            Console.WriteLine("--------------------------------------------------------------------------------");
        }
        #endregion
        #endregion
    }
}
