﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace Test
{
    public class TestUtil
    {
        #region 定数
        /// <summary>
        /// 型名解析パターンを定義する。
        /// </summary>
        static readonly string TYPENAME_PATTERN = new StringBuilder()
            .Append(@"(?<typename>[A-Za-z0-9]+)")
            .Append(@"(")
            .Append(@"((?<nullable>\?))")
            .Append(@"|")
            .Append(@"(<(?<generics>[^>]+)>)")
            .Append(@"){0,1}")
            .Append(@"(")
            .Append(@"(?<array>\[\])")
            .Append(@"){0,1}")
            .ToString();

        /// <summary>
        /// 型変換マップを定義する。
        /// </summary>
        static readonly Dictionary<Type, Func<string, object>> CONVERT_MAP = new Dictionary<Type, Func<string, object>>()
        {
            { typeof(int), (s) => int.Parse(s) },
            { typeof(bool), (s) => bool.Parse(s) },
            { typeof(DateTime), (s) => DateTime.Parse(s) },
            { typeof(int), (s) => int.Parse(s) },
        };

        const BindingFlags BINDING_FLAGS = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        #endregion


        #region プロパティ
        /// <summary>
        /// 型名変換マップを取得・設定する。
        /// </summary>
        public static Dictionary<string, string> TypeNameMap { get; private set; }
            = new Dictionary<string, string>();
        #endregion


        #region メソッド
        /// <summary>
        /// 型名を解析して型を取得する。
        /// </summary>
        /// <param name="name">型名</param>
        /// <returns>型</returns>
        public static Type GetType(string name)
        {
            return Type.GetType(ConvertTypeName(name));
        }

        /// <summary>
        /// 文字列型の値を型変換する。
        /// </summary>
        /// <param name="type">変換後の型</param>
        /// <param name="value">値(文字列)</param>
        /// <returns>変換後の値</returns>
        public static object Convert(Type type, string value)
        {
            var key = type.IsEnum ? typeof(Enum) : type;
            return CONVERT_MAP[key]?.Invoke(value);
        }

        /// <summary>
        /// フィールドを取得する。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="name">フィールド名</param>
        /// <returns>フィールド</returns>
        public static FieldInfo GetField(Type type, string name)
        {
            return type.GetField(name, BINDING_FLAGS);
        }

        /// <summary>
        /// プロパティを取得する。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="name">プロパティ名</param>
        /// <returns>プロパティ</returns>
        public static PropertyInfo GetProperty(Type type, string name)
        {
            return type.GetProperty(name, BINDING_FLAGS);
        }

        /// <summary>
        /// メソッドを取得する。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="name">メソッド名</param>
        /// <param name="paramTypes">メソッド引数型</param>
        /// <param name="genericTypes">メソッドジェネリック型</param>
        /// <returns>メソッド</returns>
        public static MethodInfo GetMethod(Type type, string name, Type[] paramTypes, Type[] genericTypes = null)
        {
            var method = type.GetMethod(name, BINDING_FLAGS, null, paramTypes, null);
            if (genericTypes != null)
            {
                method = method.MakeGenericMethod(genericTypes); ;
            }
            return method;
        }

        #region 非公開
        /// <summary>
        /// 型名をリフレクションで取得できる形式に変換する。
        /// </summary>
        /// <param name="name">型名</param>
        /// <returns>変換後の型名</returns>
        static string ConvertTypeName(string name)
        {
            //型名解析
            var mc = Regex.Match(name, TYPENAME_PATTERN);
            if (mc.Success == false)
            {
                throw new NotSupportedException(
                    string.Format("型名が誤っています。：\"{0}\"", name));
            }

            var buf = new StringBuilder();

            //クラス名
            var typeName = mc.Groups["typename"].Value;
            if (TypeNameMap.ContainsKey(typeName))
            {
                typeName = TypeNameMap[typeName];
            }

            //Null許容型
            if (mc.Groups["nullable"].Success)
            {
                buf.AppendFormat("System.Nullable`1[{0}]", typeName);
            }
            else
            {
                buf.Append(typeName);
            }

            //ジェネリクス
            if (mc.Groups["generics"].Success)
            {
                var aryName = mc.Groups["generics"].Value.Split(',');
                var joinName = string.Join(",",
                    aryName.Select(n => "[" + ConvertTypeName(n) + "]"));
                buf.AppendFormat("`{0}[{1}]", aryName.Length, joinName);
            }

            //配列
            if (mc.Groups["array"].Success)
            {
                buf.Append("[]");
            }

            return buf.ToString();
        }
        #endregion
        #endregion
    }
}
