﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.IO
{
    /// <summary>
    /// Excelを操作するクラス。
    /// </summary>
    public class ExcelManager : IDisposable
    {
        #region 変数
        /// <summary>
        /// パッケージを格納する。
        /// </summary>
        ExcelPackage _package;

        /// <summary>
        /// ワークシートを格納する。
        /// </summary>
        ExcelWorksheet _sheet;
        #endregion


        #region 生成・破棄
        /// <summary>
        /// インスタンスを解放する。
        /// </summary>
        public void Dispose()
        {
            Close();
        }
        #endregion


        #region メソッド
        /// <summary>
        /// ワークブックを開く。
        /// </summary>
        /// <param name="path">ファイルパス</param>
        public void Open(string path)
        {
            using (var stream = File.Open(path,
                FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                _package = new ExcelPackage(stream);
            }
        }

        /// <summary>
        /// ワークブックを閉じる。
        /// </summary>
        public void Close()
        {
            //ワークシートの解放
            _sheet?.Dispose();
            _sheet = null;

            //パッケージの解放
            _package?.Dispose();
            _package = null;
        }

        /// <summary>
        /// ワークシート名リストを取得する。
        /// </summary>
        /// <returns>ワークシート名リスト</returns>
        public string[] GetWorksheetNames()
        {
            return _package.Workbook.Worksheets
                .Select(s => s.Name)
                .ToArray();
        }

        /// <summary>
        /// 指定した名前のワークシートを選択する。
        /// 省略した場合は先頭のワークシートを選択する。
        /// </summary>
        /// <param name="name">シート名</param>
        public void SelectWorksheet(string name = null)
        {
            if (name == null)
            {
                _sheet = _package.Workbook.Worksheets[0];
            }
            else
            {
                _sheet = _package.Workbook.Worksheets[name];
            }
        }

        /// <summary>
        /// 指定した座標から右方向を捜索して列名リストを取得する。
        /// </summary>
        /// <param name="row">行番号</param>
        /// <param name="col">列番号</param>
        /// <returns>列名リスト</returns>
        public List<string> GetColumnValues(int row, int col)
        {
            var list = new List<string>();
            while (IsEnableCell(row, col))
            {
                list.Add(GetCellValue(row, col++));
            }
            return list;
        }

        /// <summary>
        /// 指定した座標から下方向を捜索して有効なセルの件数をカウントする。
        /// </summary>
        /// <param name="row">行番号</param>
        /// <param name="col">列番号</param>
        /// <returns>件数</returns>
        public int CountRow(int row, int col)
        {
            var count = 0;
            while (IsEnableCell(row + count, col))
            {
                count++;
            }
            return count;
        }

        /// <summary>
        /// 指定した座標のセルが有効か判定する。
        /// (左右の罫線で判定)
        /// </summary>
        /// <param name="row">行番号</param>
        /// <param name="col">列番号</param>
        /// <returns>有効な場合はtrue、そうでない場合はfalse</returns>
        public bool IsEnableCell(int row, int col)
        {
            var border = _sheet.Cells[row, col].Style.Border;
            return border.Left.Style != ExcelBorderStyle.None
                && border.Right.Style != ExcelBorderStyle.None;
        }

        /// <summary>
        /// 指定した座標のセルに値が存在するか判定する。
        /// </summary>
        /// <param name="row">行番号</param>
        /// <param name="col">列番号</param>
        /// <returns>存在する場合はtrue、そうでない場合はfalse</returns>
        public bool HasCellValue(int row, int col)
        {
            return GetCellValue(row, col) != null;
        }

        /// <summary>
        /// 指定した座標のセルから表示値を取得する。
        /// </summary>
        /// <param name="row">行番号</param>
        /// <param name="col">列番号</param>
        /// <returns>表示値</returns>
        public string GetCellValue(int row, int col)
        {
            return _sheet.Cells[row, col].Text;
        }
        #endregion
    }
}
