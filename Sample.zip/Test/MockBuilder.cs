﻿using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    /// <summary>
    /// Mockを構築するクラス。
    /// </summary>
    public class MockBuilder
    {
        #region MyRegion

        #endregion


        #region MyRegion

        Type _type = null;
        Type _mockType = null;
        Mock _mock = null;
        #endregion


        #region MyRegion

        #endregion


        #region メソッド
        /// <summary>
        /// Mock化する対象を設定する。
        /// </summary>
        /// <param name="type">Mock化する型</param>
        /// <param name="isCallBase">本来の実装を動作させる場合はtrue</param>
        /// <returns>ビルダ</returns>
        public MockBuilder SetTarget(Type type, bool isCallBase = false)
        {
            //Mockの生成
            _type = type;
            _mockType = Type.GetType("Moq.Mock`1").MakeGenericType(_type);
            _mock = Activator.CreateInstance(_mockType) as Mock;

            //本来の実装を動作させるか設定
            TestUtil.GetProperty(_mockType, "CallBase")
                .SetMethod.Invoke(_mock, new object[] { isCallBase });

            return this;
        }

        public MockBuilder Setup(string methodName, Type[] paramTypes)
        {
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Mock Build()
        {



            return _mock;
        }
        #endregion
    }
}
