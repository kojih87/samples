(function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** 対象要素 */
        TARGET: 'input:file',
        /** ドロップエリア要素 */
        DROPAREA: '.droparea'
    };

    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    let FileuploadClass = function () {
        /**
         * 要素セレクタ毎に表示中のデータを格納する。
         */
        this._data = null;
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    FileuploadClass.prototype.initialize =
        /**
         * インスタンスを初期化する。
         */
        function () {
            //対象要素の取得
            let $target = $(DEF_SELECTOR.TARGET),
                length = $target.length;
            if (length == 0) {
                return;
            }

            //対象要素の設定
            $target
                //非表示
                .hide()
                //代替要素の追加
                .after(
                    '<div class="fileupload">'
                    + '<input type="text" class="state" readonly value="(未選択)" />'
                    + '<div class="droparea">'
                    + 'ファイルをここへドロップ<br />'
                    + '<span>または</span><br />'
                    + 'クリック'
                    + '</div>'
                    + '</div>'
                )
                //イベントの登録
                .on('change', file_change);
            //イベントの登録 (代替要素)
            $target.next()
                .delegate(DEF_SELECTOR.DROPAREA, 'click', droparea_click)
                .delegate(DEF_SELECTOR.DROPAREA, 'dragenter dragleave', droparea_drag)
                .delegate(DEF_SELECTOR.DROPAREA, 'drop', droparea_drop);
            //イベントの登録 (エリア外のドロップ無効)
            $(document).on('dragover drop', document_cancel);

            //データの初期化
            this._data = {};
        };

    FileuploadClass.prototype.destroy =
        /**
         * インスタンスを破棄する。
         */
        function () {
            if (this._data == null) {
                return;
            }

            //データの破棄
            this._data = null;

            //対象要素の設定解除
            let $target = $(DEF_SELECTOR.TARGET);
            $target.next().off().remove();
            $target.off();
            $(document).off('dragover drop');
        };

    /* ファイル
    ----------------------------------------------------------*/
    FileuploadClass.prototype.setFile =
        /**
         * 選択されたファイルを設定する。
         * @param {string} selector 要素セレクタ
         * @param {File}   file     ファイル
         */
        function (selector, file) {
            //データの設定
            this._data[selector] = file;

            //状態の更新
            let name = file.name,
                size = file.size;
            if (size < 1024) {
                size = size + 'Byte';
            } else {
                size = (Math.round(size / 1024 * 100) / 100) + 'kByte';
            }
            $(selector).next().find('.state').val(name + ' ／ ' + size);
        };

    FileuploadClass.prototype.getFile =
        /**
         * 選択されたファイルを取得する。
         * @param {string} selector 要素セレクタ
         * @returns ファイル
         */
        function (selector) {
            return this._data[selector];
        };


    //==============================================================================
    // イベント
    //==============================================================================
    /**
     * document の DragOver、Drop イベントを処理する。
     */
    function document_cancel() {
        return false;
    }

    /**
     * ドロップエリア要素 の DragEnter、DragLeave イベントを処理する。
     * @param {Event} evt イベント
     */
    function droparea_drag(evt) {
        //スタイルの切り替え
        $(evt.target).toggleClass('droparea-hover');
        return false;
    };

    /**
     * ドロップエリア要素 の Drop イベントを処理する。
     * @param {Event} evt イベント
     */
    function droparea_drop(evt) {
        //スタイルの切り替え
        $(evt.target).toggleClass('droparea-hover');

        //ファイルの設定
        let selector = '#' + evt.target.parentNode.previousSibling.id,
            file = evt.originalEvent.dataTransfer.files[0];
        global.Fileupload.setFile(selector, file);
        return false;
    };

    /**
     * ドロップエリア要素 の Click イベントを処理する。
     * @param {Event} evt イベント
     */
    function droparea_click(evt) {
        let droparea = evt.target;
        if (droparea.tagName.toLowerCase() == 'span') {
            droparea = droparea.parentNode;
        }
        //対象要素 の Click イベントを発火
        droparea.parentNode.previousSibling.click();
        droparea = null;
    };

    /**
     * 対象要素 の Change イベントを処理する。
     * @param {Event} evt イベント
     */
    function file_change(evt) {
        //ファイルの設定
        let selector = '#' + evt.target.id,
            file = evt.target.files[0];
        global.Fileupload.setFile(selector, file);
    };


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    global.Fileupload = new FileuploadClass();
}(this));