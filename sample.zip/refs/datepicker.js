(function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /** 設定 */
    const DEF_CONF = {
        /** タイプ */
        TYPE: {
            /** 日 */
            DAY: 'day',
            /** 月 */
            MONTH: 'month',
            /** 年 */
            YEAR: 'year',
            /** 半期 */
            HALF: 'half'
        },

        /** タイプ毎のビュー階層 */
        VIEWS: {
            /** 日 */
            'day': ['day', 'month', 'year'],
            /** 月 */
            'month': ['month', 'year'],
            /** 年 */
            'year': ['year'],
            /** 半期 */
            'half': ['half', 'year']
        },

        /** タイプ毎の行列数 */
        MATRIX: {
            /** 日 */
            'day': { maxRow: 6, maxCol: 7 },
            /** 月 */
            'month': { maxRow: 3, maxCol: 4 },
            /** 年 */
            'year': { maxRow: 3, maxCol: 4 },
            /** 半期 */
            'half': { maxRow: 1, maxCol: 2 }
        },

        /** カレンダー状態の初期値 */
        DEFAULT: {
            /** タイプ */
            TYPE: 'day',
            /** 最小日付 */
            MIN: new Date(1990, 0, 1),
            /** 最大日付 */
            MAX: new Date(2999, 11, 31)
        },

        /** 属性監視オプション */
        OPTS: {
            attributes: true,
            attributeFilter: ['data-val']
        },

        /** 表示値 */
        TEXT: {
            /** 曜日 */
            DAYS: ['日', '月', '火', '水', '木', '金', '土'],
            /** 月 */
            MONTH: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
            /** 半期 */
            HALF: ['上期', '下期']
        }
    };

    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** 対象要素 */
        TARGET: '.datepicker',
        /** ポップアップ要素 */
        POPUP: '#datepicker-popup',
        /** アクション要素 */
        ACTION: '.calendar-action'
    };

    /** 属性 */
    const DEF_ATTR = {
        /** タイプ */
        TYPE: 'data-type',
        /** 値 */
        VAL: 'data-val',
        /** 最小値 */
        MINVAL: 'data-minval',
        /** 最大値 */
        MAXVAL: 'data-maxval',
        /** アクション */
        ACTION: 'data-action'
    };


    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    let DatepickerClass = function () {
        /**
         * 対象要素の属性監視オブジェクトを格納する。
         * @type {MutationObserver}
         */
        this._observer = null;

        /**
         * ポップアップ表示中の対象要素を格納する。
         */
        this._$el = null;

        /**
         * 表示中のポップアップ要素を格納する。
         */
        this._$popup = null;

        /**
         * カレンダーの状態を格納する。
         */
        this._state = null;

        /**
         * キャンセルフラグを格納する。
         * @type {boolean}
         */
        this._cancel = false;

        /**
         * 曜日ヘッダを格納する。
         * @type {string}
         */
        this._header = null;
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    DatepickerClass.prototype.initialize =
        /**
         * インスタンスを初期化する。
         */
        function () {
            //対象要素の取得
            let $target = $(DEF_SELECTOR.TARGET),
                length = $target.length;
            if (length == 0) {
                return;
            }

            //対象要素の設定
            $target
                //読み取り専用
                .attr('readonly', true)
                //イベントの登録
                .on('click', datepicker_focus)
                .on('focus', datepicker_focus)
                .on('blur', datepicker_blur);
            //対象要素の属性監視
            this._observer = new MutationObserver(datepicker_modified);
            for (let i = 0; i < length; i++) {
                this._observer.observe($target[i], DEF_CONF.OPTS);
            }
        };

    DatepickerClass.prototype.destroy =
        /**
         * インスタンスを破棄する。
         */
        function () {
            if (this._observer == null) {
                return;
            }

            //対象要素の設定解除
            $(DEF_SELECTOR.TARGET)
                //読み取り専用解除
                .attr('readonly', false)
                //イベントの削除
                .off();

            //対象要素の属性監視解除
            this._observer.disconnect();
            this._observer = null;
        };

    /* ポップアップ表示・非表示
    ----------------------------------------------------------*/
    DatepickerClass.prototype.show =
        /**
         * ポップアップを表示する。
         * @param {HTMLInputElement} el 対象要素
         */
        function (el) {
            //既に表示中の場合
            if (this._$popup != null) {
                return;
            }

            //対象要素の設定
            this._$el = $(el)
                //要素の追加
                .after(
                    '<div id="datepicker-popup">'
                    + '<div class="calendar">'
                    + '<nav>'
                    + '<svg class="calendar-action" data-action="prev"><path d="M25,5 L15,15 25,25"></path></svg>'
                    + '<span class="calendar-action" data-action="up"></span>'
                    + '<svg class="calendar-action" data-action="next"><path d="M15,5 L25,15 15,25"></path></svg>'
                    + '</nav>'
                    + '<table></table>'
                    + '</div>'
                    + '</div>'
                );
            let rect = el.getBoundingClientRect();
            el = null;

            //ポップアップ要素
            this._$popup = $(DEF_SELECTOR.POPUP)
                //イベントの登録
                .on('mousedown', popup_mousedown)
                .delegate(DEF_SELECTOR.ACTION, 'click', action_click)
                //表示位置の設定
                .offset({ top: rect.bottom + 12, left: rect.left });

            //カレンダーの更新
            this.updateCalendar();
        };

    DatepickerClass.prototype.hide =
        /**
         * 表示中のポップアップを削除する。
         */
        function () {
            //ポップアップ操作中の場合
            if (this._cancel) {
                this._cancel = false;
                this._$el.focus();
                return;
            }
            //表示中ではない場合
            if (this._$popup == null) {
                return;
            }

            //ポップアップ要素の削除
            this._$popup.remove();
            this._$popup = null;
            this._$el = null;
            this._state = null;
        };

    DatepickerClass.prototype.cancelHide =
        /**
         * 次のポップアップ削除をキャンセルする。
         */
        function () {
            this._cancel = true;
        };

    /* アクション
    ----------------------------------------------------------*/
    DatepickerClass.prototype.action =
        /**
         * アクションを実行する。
         * @param {HTMLInputElement} el アクション要素
         */
        function (el) {
            let $el = $(el),
                act = $el.attr(DEF_ATTR.ACTION),
                val = $el.attr(DEF_ATTR.VAL);
            el = null;

            //アクションの判定
            switch (act) {
                case 'prev':
                case 'next':
                    this._state.viewDate = this.convValToDate(this._state.baseType, val);
                    break;
                case 'up':
                    this._state.index++;
                    break;
                case 'down':
                    this._state.index--;
                    this._state.viewDate = this.convValToDate(this._state.baseType, val);
                    break;
                case 'select':
                    this._$el.attr(DEF_ATTR.VAL, val);
                    this.hide();
                    return;
            }
            //カレンダーの更新
            this.updateCalendar();
        };

    DatepickerClass.prototype.reflectValue =
        /**
         * data-val属性値を値に反映する。
         * @param {HTMLInputElement} el 対象要素
         */
        function (el) {
            //値の変換
            let $el = $(el),
                type = $el.attr(DEF_ATTR.TYPE),
                date = this.convValToDate(type, $el.attr(DEF_ATTR.VAL)),
                text = this.convDateToText(type, date),
                text_org = $el.val();
            el = null;
            if (text != text_org) {
                //値の反映
                $el.val(text).change();
            }
        };

    /* カレンダー
    ----------------------------------------------------------*/
    DatepickerClass.prototype.updateCalendar =
        /**
         * カレンダーを更新する。
         */
        function () {
            let state = this.__getState(),
                views = DEF_CONF.VIEWS[state.baseType],
                type = views[state.index];

            //ナビゲーションの編集
            let prevViewDate = this.__getPrevViewDate(type, state.viewDate, state.minDate),
                nextViewDate = this.__getNextViewDate(type, state.viewDate, state.maxDate),
                viewText = this.__getViewText(type, state.viewDate),
                canUp = state.index < views.length - 1;
            this._$popup.find('svg[data-action=prev]')
                .css('visibility', prevViewDate ? 'visible' : 'hidden')
                .attr(DEF_ATTR.VAL, this.convDateToVal(state.baseType, prevViewDate));
            this._$popup.find('svg[data-action=next]')
                .css('visibility', nextViewDate ? 'visible' : 'hidden')
                .attr(DEF_ATTR.VAL, this.convDateToVal(state.baseType, nextViewDate));
            this._$popup.find('span')
                .text(viewText)
                .attr('class', canUp ? 'calendar-action' : '');

            //カレンダーの編集
            let matrix = DEF_CONF.MATRIX[type],
                d = this.__getFirstDate(type, state.viewDate),
                html;
            html = this.__getHeader(type) + '<tbody>';
            for (let row = 0; row < matrix.maxRow; row++) {
                html += '<tr>';
                for (let col = 0; col < matrix.maxCol; col++) {
                    if (this.__isWithinRange(type, d, state.minDate, state.maxDate)) {
                        let act = (state.index == 0 ? 'select' : 'down'),
                            val = this.convDateToVal(state.baseType, d),
                            cls = this.__getCellClass(type, d, state.currDate, state.viewDate),
                            txt = this.__getCellText(type, d);
                        html += '<td class="' + cls + '" '
                            + DEF_ATTR.ACTION + '="' + act + '" '
                            + DEF_ATTR.VAL + '="' + val + '">'
                            + txt + '</td>';
                    } else {
                        html += '<td><br /></td>';
                    }
                    //次の日付
                    this.__moveNextDate(type, d);
                }
                html += '</tr>';
            }
            html += '</tbody>';
            this._$popup.find('table').html(html);
        };

    DatepickerClass.prototype.__getState =
        /**
         * カレンダーの状態を取得する。
         * @returns カレンダー状態
         */
        function () {
            //状態が存在しない場合
            if (this._state == null) {
                //対象要素の属性から生成
                let type = this._$el.attr(DEF_ATTR.TYPE) || DEF_CONF.DEFAULT.TYPE,
                    minDate = this.convValToDate(type, this._$el.attr(DEF_ATTR.MINVAL))
                        || DEF_CONF.DEFAULT.MIN,
                    maxDate = this.convValToDate(type, this._$el.attr(DEF_ATTR.MAXVAL))
                        || DEF_CONF.DEFAULT.MAX,
                    currDate = this.convValToDate(type, this._$el.attr(DEF_ATTR.VAL))
                        || new Date();
                this._state = {
                    baseType: type,
                    minDate: minDate,
                    maxDate: maxDate,
                    currDate: currDate,
                    viewDate: currDate,
                    index: 0
                };
            }
            return this._state;
        };

    DatepickerClass.prototype.__getPrevViewDate =
        /**
         * 前ビューの日付を取得する。
         * @param {string} type ビューのタイプ
         * @param {Date}   d    日付
         * @param {Date}   min  最小日付
         * @returns 前ビューの日付 または null
         */
        function (type, d, min) {
            let date = null;
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    let val = this.convDateToVal(DEF_CONF.TYPE.MONTH, d),
                        minVal = this.convDateToVal(DEF_CONF.TYPE.MONTH, min);
                    if (minVal < val) {
                        date = new Date(d.getFullYear(), d.getMonth() - 1, d.getDate());
                        if (d.getMonth() == date.getMonth()) {
                            date.setDate(0);
                        }
                    }
                    break;
                case DEF_CONF.TYPE.MONTH:
                case DEF_CONF.TYPE.HALF:
                    if (min.getFullYear() < d.getFullYear()) {
                        date = new Date(d.getFullYear() - 1, d.getMonth(), d.getDate());
                    }
                    break;
                case DEF_CONF.TYPE.YEAR:
                    let year = Math.floor((d.getFullYear() - 1) / 12) * 12 + 1;
                    if (min.getFullYear() < year) {
                        date = new Date(d.getFullYear() - 12, d.getMonth(), d.getDate());
                    }
                    break;
            }
            return date;
        };

    DatepickerClass.prototype.__getNextViewDate =
        /**
         * 次ビューの日付を取得する。
         * @param {string} type タイプ
         * @param {Date}   d    日付
         * @param {Date}   max  最大日付
         * @returns 次ビューの日付 または null
         */
        function (type, d, max) {
            let date = null;
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    let val = this.convDateToVal(DEF_CONF.TYPE.MONTH, d),
                        maxVal = this.convDateToVal(DEF_CONF.TYPE.MONTH, max);
                    if (val < maxVal) {
                        date = new Date(d.getFullYear(), d.getMonth() + 1, d.getDate());
                        //日が移動後の月末より大きい場合
                        if (1 < date.getMonth() - d.getMonth()) {
                            date.setDate(0);
                        }
                    }
                    break;
                case DEF_CONF.TYPE.MONTH:
                case DEF_CONF.TYPE.HALF:
                    if (d.getFullYear() < max.getFullYear()) {
                        date = new Date(d.getFullYear() + 1, d.getMonth(), d.getDate());
                    }
                    break;
                case DEF_CONF.TYPE.YEAR:
                    let year = Math.floor((d.getFullYear() - 1) / 12) * 12 + 13;
                    if (year < max.getFullYear()) {
                        return new Date(d.getFullYear() + 12, d.getMonth(), d.getDate());
                    }
                    break;
            }
            return date;
        };

    DatepickerClass.prototype.__getViewText =
        /**
         * ビューのタイトルを取得する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         * @returns タイトル
         */
        function (type, d) {
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    return this.convDateToText(DEF_CONF.TYPE.MONTH, d);
                case DEF_CONF.TYPE.MONTH:
                case DEF_CONF.TYPE.HALF:
                    return this.convDateToText(DEF_CONF.TYPE.YEAR, d);
                case DEF_CONF.TYPE.YEAR:
                    let year = Math.floor((d.getFullYear() - 1) / 12) * 12 + 1;
                    return year + ' - ' + (year + 11);
            }
        };

    DatepickerClass.prototype.__getHeader =
        /**
         * カレンダーのヘッダを取得する。
         * @param {string} type タイプ
         * @returns 日カレンダーの場合は曜日ヘッダ、そうでない場合は空
         */
        function (type) {
            if (type == DEF_CONF.TYPE.DAY) {
                if (this._header == null) {
                    this._header = '<thead><tr>';
                    for (let i = 0; i < DEF_CONF.TEXT.DAYS.length; i++) {
                        let cls = '';
                        if (i == 0) {
                            cls = ' class="calendar-cell-holiday"';
                        } else if (i == 6) {
                            cls = ' class="calendar-cell-saturday"';
                        }
                        this._header += '<th' + cls + '>' + DEF_CONF.TEXT.DAYS[i] + '</th>'
                    }
                    this._header += '</tr></thead>';
                }
                return this._header;
            }
            return '';
        };

    DatepickerClass.prototype.__getFirstDate =
        /**
         * カレンダーに表示する先頭の日付を取得する。
         * @param {string} type タイプ
         * @param {Date}   d    日付
         * @returns 先頭日付
         */
        function (type, d) {
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    let date = new Date(d.getFullYear(), d.getMonth(), 1);
                    date.setDate(1 - date.getDay());
                    return date;
                case DEF_CONF.TYPE.MONTH:
                case DEF_CONF.TYPE.HALF:
                    return new Date(d.getFullYear(), 0, d.getDate());
                case DEF_CONF.TYPE.YEAR:
                    let year = Math.floor((d.getFullYear() - 1) / 12) * 12 + 1;
                    return new Date(year, d.getMonth(), d.getDate());
            }
        };

    DatepickerClass.prototype.__moveNextDate =
        /**
         * カレンダーに表示する次の日付へ移動する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         */
        function (type, d) {
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    d.setDate(d.getDate() + 1);
                    return;
                case DEF_CONF.TYPE.MONTH:
                    d.setMonth(d.getMonth() + 1);
                    return;
                case DEF_CONF.TYPE.YEAR:
                    d.setFullYear(d.getFullYear() + 1);
                    return;
                case DEF_CONF.TYPE.HALF:
                    d.setMonth(d.getMonth() + 6);
                    return;
            }
        };

    DatepickerClass.prototype.__isWithinRange =
        /**
         * 現在の日付が範囲内か判定する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         * @param {Date}   min  最小日付
         * @param {Date}   max  最大日付
         * @returns 範囲内の場合はtrue、そうでない場合はfalse
         */
        function (type, d, min, max) {
            let val = this.convDateToVal(type, d),
                minVal = this.convDateToVal(type, min),
                maxVal = this.convDateToVal(type, max);
            return (minVal <= val && val <= maxVal);
        };

    DatepickerClass.prototype.__getCellClass =
        /**
         * セルに追加するCSSクラスを取得する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         * @param {Date}   c    選択中の日付
         * @param {Date}   v    ビューの日付
         * @returns CSSクラス
         */
        function (type, d, c, v) {
            let val = this.convDateToVal(type, d),
                currVal = this.convDateToVal(type, c),
                cls = 'calendar-action';
            //選択中の場合
            if (val == currVal) {
                cls += ' calendar-cell-current';
            }
            //日カレンダーの場合
            if (type == DEF_CONF.TYPE.DAY) {
                //ビューの年月以外の場合
                if (d.getFullYear() != v.getFullYear()
                    || d.getMonth() != v.getMonth()) {
                    cls += ' calendar-cell-other-month';
                }
                //日曜の場合
                else if (d.getDay() == 0) {
                    cls += ' calendar-cell-holiday';
                }
                //土曜の場合
                else if (d.getDay() == 6) {
                    cls += ' calendar-cell-saturday';
                }
            }
            return cls;
        };

    DatepickerClass.prototype.__getCellText =
        /**
         * セルに表示する文字列を取得する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         * @returns 表示値
         */
        function (type, d) {
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    return d.getDate().toString();
                case DEF_CONF.TYPE.MONTH:
                    return DEF_CONF.TEXT.MONTH[d.getMonth()];
                case DEF_CONF.TYPE.YEAR:
                    return d.getFullYear().toString();
                case DEF_CONF.TYPE.HALF:
                    return DEF_CONF.TEXT.HALF[Math.floor(d.getMonth() / 6)];
            }
        };

    /* 関数
    ----------------------------------------------------------*/
    DatepickerClass.prototype.convValToDate =
        /**
         * 定型文字列を日付型に変換する。
         * @param {string} type タイプ
         * @param {string} val  日付を表す定型文字列
         * @returns 日付
         */
        function (type, val) {
            let date = null;
            if (val != null) {
                let v1 = val.substr(0, 4),
                    v2 = val.substr(4, 2),
                    v3 = val.substr(6, 2);
                switch (type) {
                    case DEF_CONF.TYPE.DAY:
                        //yyyyMMdd形式 (年月日)
                        date = new Date(parseInt(v1), parseInt(v2) - 1, parseInt(v3));
                        break;
                    case DEF_CONF.TYPE.MONTH:
                        //yyyyMM形式 (年月)
                        date = new Date(parseInt(v1), parseInt(v2) - 1, 1);
                        break;
                    case DEF_CONF.TYPE.YEAR:
                        //yyyy形式 (年)
                        date = new Date(parseInt(v1), 0, 1);
                        break;
                    case DEF_CONF.TYPE.HALF:
                        //yyyy9H形式 (年半期)
                        date = new Date(parseInt(v1), (parseInt(v2.substr(0, 1)) - 1) * 6, 1);
                        break;
                }
                //console.log('(%s) %s ⇒ %i年%i月%i日', type, val, date.getFullYear(), date.getMonth() + 1, date.getDate());
            }
            return date;
        };

    DatepickerClass.prototype.convDateToVal =
        /**
         * 日付型を定型文字列に変換する。
         * @param {string} type タイプ
         * @param {Date}   date 日付
         * @returns 日付を表す定型文字列
         */
        function (type, date) {
            let val = null;
            if (date != null) {
                switch (type) {
                    case DEF_CONF.TYPE.DAY:
                        //yyyyMMdd形式 (年月日)
                        val = date.getFullYear()
                            + ('0' + (date.getMonth() + 1)).slice(-2)
                            + ('0' + date.getDate()).slice(-2);
                        break;
                    case DEF_CONF.TYPE.MONTH:
                        //yyyyMM形式 (年月)
                        val = date.getFullYear()
                            + ('0' + (date.getMonth() + 1)).slice(-2);
                        break;
                    case DEF_CONF.TYPE.YEAR:
                        //yyyy形式 (年)
                        val = date.getFullYear().toString();
                        break;
                    case DEF_CONF.TYPE.HALF:
                        //yyyy9H形式 (年半期)
                        val = date.getFullYear()
                            + ((Math.floor(date.getMonth() / 6) + 1) + 'H');
                        break;
                }
                //console.log('(%s) %i年%i月%i日 ⇒ %s', type, date.getFullYear(), date.getMonth() + 1, date.getDate(), val);
            }
            return val;
        };

    DatepickerClass.prototype.convDateToText =
        /**
         * 日付型を表示文字列に変換する。
         * @param {string} type タイプ
         * @param {Date}   date 日付
         * @returns 日付を表す表示文字列
         */
        function (type, date) {
            let text = null;
            if (date != null) {
                switch (type) {
                    case DEF_CONF.TYPE.DAY:
                        //yyyy年 M月 d日（Ｎ）形式
                        text = date.getFullYear() + '年'
                            + (' ' + (date.getMonth() + 1)).slice(-2) + '月'
                            + (' ' + date.getDate()).slice(-2) + '日'
                            + '（' + DEF_CONF.TEXT.DAYS[date.getDay()] + '）';
                        break;
                    case DEF_CONF.TYPE.MONTH:
                        //yyyy年 M月形式
                        text = date.getFullYear() + '年'
                            + (' ' + (date.getMonth() + 1)).slice(-2) + '月';
                        break;
                    case DEF_CONF.TYPE.YEAR:
                        //yyyy年形式
                        text = date.getFullYear() + '年';
                        break;
                    case DEF_CONF.TYPE.HALF:
                        //yyyy年Ｎ期形式
                        text = date.getFullYear() + '年'
                            + DEF_CONF.TEXT.HALF[Math.floor(date.getMonth() / 6)];
                        break;
                }
                //console.log('(%s) %i年%i月%i日 ⇒ %s', type, date.getFullYear(), date.getMonth() + 1, date.getDate(), text);
            }
            return text;
        };


    //==============================================================================
    // イベント
    //==============================================================================
    /**
     * 対象要素 の 属性変更 イベントを処理する。
     * @param {MutationRecord[]} mutations 変更
     */
    function datepicker_modified(mutations) {
        let length = mutations.length;
        for (let i = 0; i < length; i++) {
            //値の反映
            global.Datepicker.reflectValue(mutations[i].target);
        }
    };

    /**
     * 対象要素 の Click、Focus イベントを処理する。
     * @param {Event} event イベント
     */
    function datepicker_focus(event) {
        //ポップアップの表示
        global.Datepicker.show(event.target);
    };

    /**
     * 対象要素 の Blur イベントを処理する。
     */
    function datepicker_blur() {
        //ポップアップの削除
        global.Datepicker.hide();
    };

    /**
     * ポップアップ要素 の MouseDown イベントを処理する。
     */
    function popup_mousedown() {
        //次のポップアップ削除をキャンセル
        global.Datepicker.cancelHide();
    };

    /**
     * アクション要素 の Click イベントを処理する。
     * @param {Event} event イベント
     */
    function action_click(event) {
        //アクションの実行
        global.Datepicker.action(event.target);
    };


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    global.Datepicker = new DatepickerClass();
}(this));