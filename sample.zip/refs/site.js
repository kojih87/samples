(function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /** サイト設定 */
    const DEF_CONF = {
        /** ウィンドウタイトル */
        WIN_TITLE: {
            /** WEB公開 */
            USER: 'NW給電情報',
            /** WEB管理 */
            ADMIN: 'NW給電情報管理'
        },

        /** 管理箇所 */
        TEAM: '○○チーム',

        /** URL接頭辞 */
        URL_PREFIX: {
            /** メニューデータ */
            MENU: 'refs/menu/',
            /** 画面 */
            PAGE: 'pages/',
            /** コンテンツデータ(全NW社員向け) */
            DATA: 'data/',
            /** コンテンツデータ */
            DATA_SEC: 'security/data/',
            /** PDF */
            PDF: 'security/pdf/',
            /** WebAPI(管理向け) */
            API: 'api/'
        },

        /** 画面の親フォルダ別の設定 */
        CATEGORY: {
            /** 実績 (全NW社員向け) */
            'result_pub': { isAdmin: false, menuNo: 0 },
            /** 実績 */
            'result': { isAdmin: false, menuNo: 1 },
            /** 定期報告 */
            'report': { isAdmin: false, menuNo: 1 },
            /** 主管部管理 */
            'admin': { isAdmin: true, menuNo: 2 },
            /** NW中給管理 */
            'admin_nw': { isAdmin: true, menuNo: 3 },
            /** 上記以外 (通常あり得ない) */
            DEFAULT: { isAdmin: false, menuNo: 0 }
        },

        /** メニューデータ (menuNoと対応) */
        MENU_DATA: [
            //全NW社員向け
            'user_pub.json',
            //一部NW社員向け
            'user.json',
            //主管部管理メニュー
            'admin.json',
            //NW中給管理メニュー
            'admin_nw.json'
        ],

        /** 全NW社員向け */
        FILE_PUB: [
            'minute',
            'max_record',
            'power_of_month',
            'energy_of_month',
            'energy_of_year'
        ],

        /** 外部ライブラリ */
        LIBRARIES: {
            /** スタイル */
            STYLE: [
                //日付選択
                'refs/datepicker.css',
                //ファイルアップロード
                'refs/fileupload.css',
                //グリッド
                'refs/download/handsontable.min.css'
            ],
            /** スクリプト */
            SCRIPT: [
                //日付選択
                'refs/datepicker.js',
                //ファイルアップロード
                'refs/fileupload.js',
                //PDF
                'refs/download/pdf.min.js',
                'refs/site-pdf.js',
                //グラフ
                'refs/download/Chart.min.js',
                'refs/site-chart.js',
                //グリッド
                'refs/download/handsontable.min.js',
                'refs/site-grid.js'
            ]
        },

        /** エラーメッセージ */
        ERROR: {
            /** PDF表示エラー */
            PDF_404: '対象のPDFファイルは表示できません。',
            /** データ取得エラー(権限) */
            JSON_403: '閲覧する権限がありません。<br />業務上必要な場合は申請してください。',
            /** データ取得エラー */
            JSON_404: 'データの取得に失敗しました。<br />30分経過しても解消されない場合はシステム管理者に連絡してください。',
            /** 想定外エラー (通常あり得ない) */
            DEFAULT: '想定外のエラーが発生しました。<br />システム管理者に連絡してください。'
        }
    };

    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** メニュー */
        MENU: 'body > nav',
        /** ページナビゲーション */
        PAGE_NAVI: '.page-navi',

        /** 画面スクリプト */
        SCRIPT: '#script',
        /** コンテンツ */
        CONTENTS: '#contents',

        /** ローディング */
        LOADING: '#loading'
    };

    /* 定数
    ----------------------------------------------------------*/
    global.DEF = {
        /** PDF */
        PDF: {
            PREFIX: '../../' + DEF_CONF.URL_PREFIX.PDF
        },
        /** グラフ */
        CHART: {
            /** グラフタイプ */
            TYPE: {
                /** 線 */
                LINE: 'line',
                /** 棒 */
                BAR: 'bar'
            },
            /** X軸タイプ */
            X_AXIS_TYPE: {
                /** 288点／日 (5分間隔) */
                DAY_288: 'day288',
                /** 48点／日 (30分間隔) */
                DAY_048: 'day048',
                /** 24点／日 (60分間隔) */
                DAY_024: 'day024',
                /** 2カ月 (1日間隔) */
                MONTH: 'month',
                /** 13カ月 (1日間隔) */
                YEAR: 'year'
            },
            /** 積み上げ棒色リスト (10色まで想定) */
            BAR_RGB: [
                [255, 80, 80],
                [255, 148, 64],
                [252, 252, 32],
                [164, 252, 24],
                [80, 255, 80],
                [64, 228, 255],
                [64, 164, 255],
                [80, 80, 255],
                [164, 128, 255],
                [255, 128, 255]
            ]
        }
    };


    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    let SiteClass = function () {
        /**
         * 読み込み中件数を格納する。
         * @type {number}
         */
        this._loadingCount = 0;

        /**
         * 管理フラグを格納する。
         * @type {boolean}
         */
        this._isAdmin = false;

        /**
         * コンテンツデータを格納する。
         * @type {JSON}
         */
        this._contentsData = null;

        /**
         * 現在のページ番号を格納する。
         * @type {number}
         */
        this._pageIndex = 0;

        /**
         * 数値整形用オブジェクトを格納する。
         */
        this._numFormat = new Intl.NumberFormat('ja-JP');

        /**
         * 画面設定を格納する。
         */
        this.config = null;

        /**
         * 各画面で実装するコールバックを格納する。
         */
        this.callbacks = {
            /**
             * 初期化時に画面設定を取得する。
             * @returns 画面設定
             */
            configure: null,

            /**
             * ページ遷移後に画面を更新する。
             * @param {boolean} isFirst 初回フラグ
             * @param {JSON}    data    コンテンツデータ
             * @param {number}  index   現在のページ番号
             */
            updateScreen: null
        };
    };

    /* 初期化
    ----------------------------------------------------------*/
    SiteClass.prototype.initialize =
        /**
         * インスタンスを初期化する。
         * @param {boolean} isFirst 初回フラグ
         */
        function (isFirst) {
            //画面設定の取得
            this.config = this.callbacks.configure();

            //外部ライブラリの初期化
            this.__initializeLibraries(isFirst);
            //共通部品の構築
            this.__buildCommonParts(isFirst);
            //コンテンツの設定
            this.__setupContents();
        };

    SiteClass.prototype.__initializeLibraries =
        /**
         * 外部ライブラリを初期化する。
         */
        function (isFirst) {
            //初回の場合
            if (isFirst) {
                //外部スタイルの読み込み
                $('link').last().after(
                    DEF_CONF.LIBRARIES.STYLE.map(function (item) {
                        return '<link href="' + item + '" rel="stylesheet" />';
                    }).join('')
                );
                //外部スクリプトの読み込み
                $('script').last().before(
                    DEF_CONF.LIBRARIES.SCRIPT.map(function (item) {
                        return '<script src="' + item + '"></script>';
                    }).join('')
                );
            }

            //外部ライブラリの初期化
            global.Datepicker.initialize();
            global.Fileupload.initialize();
            this.Pdf.initialize();
            this.Chart.initialize();
            this.Grid.initialize();
        };

    SiteClass.prototype.__buildCommonParts =
        /**
         * 共通部品を構築する。
         * @param {boolean} isFirst 初回フラグ
         */
        function (isFirst) {
            //初回以外の場合
            if (!isFirst) {
                return;
            }

            //親ディレクトリ別の設定を取得
            let conf = (function () {
                let ary = location.href.split('/'),
                    dir = ary[ary.length - 2].toLowerCase(),
                    c = DEF_CONF.CATEGORY[dir];
                return {
                    isAdmin: c.isAdmin,
                    title: c.isAdmin
                        ? DEF_CONF.WIN_TITLE.ADMIN : DEF_CONF.WIN_TITLE.USER,
                    team: c.isAdmin
                        ? '' : '<span>（' + DEF_CONF.TEAM + '）</span>',
                    menuUrl: DEF_CONF.URL_PREFIX.MENU + DEF_CONF.MENU_DATA[c.menuNo]
                };
            }());

            //管理フラグの設定
            this._isAdmin = conf.isAdmin;

            //ウィンドウタイトルの設定
            document.title = conf.title;

            //コンテンツヘッダの構築
            $('body > main > header').html('<h1></h1>' + conf.team);

            //メニューの構築
            this.getJson(conf.menuUrl, function (json) {
                //HTMLの構築
                let html = '<svg viewbox="0 0 32 32">'
                    + '<rect x="0" y="0" width="32" height="32" />'
                    + '<g>'
                    + '<line x1="7" y1="9" x2="25" y2="9" />'
                    + '<line x1="7" y1="16" x2="25" y2="16" />'
                    + '<line x1="7" y1="23" x2="25" y2="23" />'
                    + '</g>'
                    + '</svg>'
                    + '<ul>'
                    + json.map(function (item) {
                        //カテゴリブロック
                        return '<li><span>' + item.category + '</span><ul>'
                            + item.menus.map(function (menu) {
                                //メニューリンク
                                return '<li>' + menu.label.link(
                                    DEF_CONF.URL_PREFIX.PAGE + menu.link) + '</li>'
                            }).join('') + '</ul></li>'
                    }).join('')
                    + '</ul>';

                //メニュー部
                $(DEF_SELECTOR.MENU)
                    //要素の追加
                    .append(html)
                    //イベントの登録
                    .delegate('a', 'click', menu_click)
                    .delegate('svg', 'click', menuSwitch_click);
            });
        };

    SiteClass.prototype.__setupContents =
        /**
         * コンテンツを設定する。
         */
        function () {
            //画面設定の取得
            let title = this.config.title,
                data = this.config.data,
                pageNavi = this.config.pageNavi,
                isAdmin = this._isAdmin;

            //コンテンツタイトルの設定
            $('body > main > header > h1').text(title);

            //ページナビゲーションの設定
            if (pageNavi) {
                //前ページ・次ページ要素の追加
                $('#current')
                    .before(
                        $('<a href="javascript:void(0);" class="page-navi" data-add="1" style="visibility:hidden;">'
                            + '<svg>'
                            + '<polygon points="0,16 16,0 16,32"></polygon>'
                            + '</svg>'
                            + '</a>')
                            .append(pageNavi.prev))
                    .after(
                        $('<a href="javascript:void(0);" class="page-navi" data-add="-1" style="visibility:hidden;">'
                            + '<svg>'
                            + '<polygon points="16,16 0,0 0,32"></polygon>'
                            + '</svg>'
                            + '</a>')
                            .prepend(pageNavi.next));
                //イベントの登録
                $(DEF_SELECTOR.PAGE_NAVI).on('click', pageNavi_click);
            }

            //コンテンツの設定
            if (data != null) {
                //URL接頭辞の取得
                let dataPrefix = (function () {
                    if (isAdmin) {
                        //管理者向け (WebAPI)
                        return DEF_CONF.URL_PREFIX.API;
                    } else {
                        let file = location.href.split('/').pop().split('.').shift();
                        return DEF_CONF.FILE_PUB.indexOf(file) < 0
                            //一部NW社員向け
                            ? DEF_CONF.URL_PREFIX.DATA_SEC
                            //全NW社員向け
                            : DEF_CONF.URL_PREFIX.DATA;
                    }
                }());
                //コンテンツデータの取得
                this.getJson(dataPrefix + data, function __callbackContentsData(json) {
                    //コンテンツデータの設定
                    global.Site._contentsData = json;
                    //先頭ページへ遷移
                    global.Site.navigatePage(0, true);
                });
            } else {
                //コンテンツデータの設定
                this._contentsData = null;
                //先頭ページへ遷移
                this.navigatePage(0, true);
            }
        };

    /* 破棄
    ----------------------------------------------------------*/
    SiteClass.prototype.destroy =
        /**
         * インスタンスを破棄する。
         * @param {boolean} isLast 最終フラグ
         */
        function (isLast) {
            //イベントの削除
            this.__removeEvents(isLast);
            //外部ライブラリの破棄
            this.__destroyLibraries(isLast);
        };

    SiteClass.prototype.__removeEvents =
        /**
         * イベントを削除する。
         * @param {boolean} isLast 最終フラグ
         */
        function (isLast) {
            //最終の場合
            if (isLast) {
                //イベントの削除
                $(DEF_SELECTOR.MENU).off();
                $(DEF_SELECTOR.PAGE_NAVI).off();
            }
        };

    SiteClass.prototype.__destroyLibraries =
        /**
         * 外部ライブラリを破棄する。
         * @param {boolean} isLast 最終フラグ
         */
        function (isLast) {
            //外部ライブラリの破棄
            global.Datepicker.destroy();
            global.Fileupload.destroy();
            this.Pdf.destroy();
            this.Chart.destroy();
            this.Grid.destroy();

            //最終の場合
            if (isLast) {
                //インスタンスの解放
                global.Datepicker = null;
                global.Fileupload = null;
                this.Pdf = null;
                this.Chart = null;
                this.Grid = null;
            }
        };

    /* ローディング
    ----------------------------------------------------------*/
    SiteClass.prototype.loading =
        /**
         * 読み込み中の画面表示に切り替える。
         */
        function () {
            //既に読み込み中の場合
            if (0 < this._loadingCount++) {
                //処理を中断
                return;
            }

            //ローディング要素の表示
            let $loading = $(DEF_SELECTOR.LOADING);
            //存在しない場合
            if ($loading.length == 0) {
                $(DEF_SELECTOR.CONTENTS).after('<div id="loading"><div><br /></div></div>');
            }
            //存在する場合
            else {
                $loading.show();
            }
        };

    SiteClass.prototype.loaded =
        /**
         * 全ての読み込みが完了した場合、読み込み中の画面表示を解除する。
         */
        function () {
            //完了していない場合
            if (1 < this._loadingCount) {
                //処理を中断
                this._loadingCount--;
                return;
            }

            //ローディング要素の表示解除
            $(DEF_SELECTOR.LOADING)
                .delay(100)
                .fadeOut(100, function () {
                    global.Site._loadingCount--;
                });
        };

    SiteClass.prototype.isLoading =
        /**
         * 読み込み中か判定する。
         * @returns 読み込み中の場合はtrue、そうでない場合はfalse
         */
        function () {
            return (0 < this._loadingCount);
        };

    /* 画面遷移
    ----------------------------------------------------------*/
    SiteClass.prototype.navigateUrl =
        /**
         * 指定されたコンテンツへ遷移する。(メニューリンク)
         * @param {string} url コンテンツのURL
         */
        function (url) {
            try {
                //読み込み中
                this.loading();

                //ロケーションの書き換え(アドレスバー)
                history.replaceState(null, null, url);
                //コンテンツ遷移
                this.getHtml(url, function __callbackContentsHtml(html) {
                    //破棄
                    global.Site.destroy();

                    let $html = $(html);
                    //画面スクリプトの差し替え
                    $(DEF_SELECTOR.SCRIPT)
                        .replaceWith($html.filter(DEF_SELECTOR.SCRIPT));
                    //コンテンツの差し替え
                    $(DEF_SELECTOR.CONTENTS)
                        .replaceWith($html.find(DEF_SELECTOR.CONTENTS));

                    //初期化
                    global.Site.initialize();
                });

            } finally {
                //読み込み完了
                this.loaded();
            }
        };

    SiteClass.prototype.navigatePage =
        /**
         * 指定されたページへ遷移する。(ページナビゲーション等)
         * @param {number}  index   ページ番号
         * @param {boolean} isFirst 初回フラグ (省略可)
         */
        function (index, isFirst) {
            try {
                //読み込み中
                this.loading();

                //画面設定の取得
                let pageNavi = this.config.pageNavi;
                //ページ番号の設定
                if (pageNavi) {
                    this._pageIndex = (function (i, min, max) {
                        //範囲内に設定
                        i = (i < min ? min : max < i ? max : i);
                        //ナビゲーションの表示切替
                        let $navi = $(DEF_SELECTOR.PAGE_NAVI);
                        $navi.eq(0).css('visibility', i == max ? 'hidden' : 'visible');
                        $navi.eq(1).css('visibility', i == min ? 'hidden' : 'visible');
                        return i;
                    }(index, 0, pageNavi.max - 1));
                } else {
                    this._pageIndex = index;
                }
                //画面の更新
                this.callbacks.updateScreen(isFirst, this._contentsData, this._pageIndex);

            } finally {
                //読み込み完了
                this.loaded();
            }
        };

    SiteClass.prototype.setError =
        /**
         * エラーメッセージを表示する。
         * @param {string} errCode  エラーコード(省略可)
         * @param {string} selector メッセージを表示する要素セレクタ(省略可)
         * @param {any}    ex       発生した例外等
         */
        function (errCode, selector, ex) {
            //メッセージの生成
            let message = '<div class="error">'
                + (DEF_CONF.ERROR[errCode] || DEF_CONF.ERROR.DEFAULT);
            if (ex != null) {
                message += '<br /><div>--<div class="selectable">';
                if (ex.stack) {
                    message += ex.stack.replace(/\n/g, '<br />');
                } else if (ex.message) {
                    message += ex.message.replace(/\n/g, '<br />');
                } else {
                    message += ex.toString().replace(/\n/g, '<br />');
                }
                message += '</div></div>';
            }
            message += '</div>';

            //要素の設定 (省略時、コンテンツ)
            $(selector || DEF_SELECTOR.CONTENTS)
                .html(message);
        };

    /* HTTP通信
    ----------------------------------------------------------*/
    SiteClass.prototype.getHtml =
        /**
         * 非同期でHTTP通信を行う。(get html)
         * @param {string}   url      要求するURL
         * @param {Function} callback 成功した応答を処理するコールバック
         */
        function (url, callback) {
            this.__ajax('get', url, null, 'HTML', callback);
        };

    SiteClass.prototype.getJson =
        /**
         * 非同期でHTTP通信を行う。(get json)
         * @param {string}   url      要求するURL
         * @param {Function} callback 成功した応答を処理するコールバック
         */
        function (url, callback) {
            this.__ajax('get', url, null, 'JSON', callback);
        };

    SiteClass.prototype.post =
        /**
         * 非同期でHTTP通信を行う。(post json)
         * @param {string}   url      要求するURL
         * @param {JSON}     params   要求するパラメータ
         * @param {Function} callback 成功した応答を処理するコールバック
         */
        function (url, params, callback) {
            this.__ajax('post', url, params, 'JSON', callback);
        };

    SiteClass.prototype.__ajax =
        /**
         * 非同期でHTTP通信を行う。
         * @param {string}   method   メソッド
         * @param {string}   url      要求するURL
         * @param {JSON}     params   要求するパラメータ
         * @param {string}   dataType 応答のデータタイプ
         * @param {Function} callback 成功した応答を処理するコールバック
         */
        function (method, url, params, dataType, callback) {
            //読み込み中
            this.loading();

            //HTTP要求
            $.ajax({
                type: method,
                url: url,
                data: params,
                dataType: dataType,
                cache: false,
                async: true
            })
                //成功した場合の処理
                .then(function (data, textStatus, jqXHR) {
                    //コールバックの呼び出し
                    callback(data);
                })

                //失敗した場合の処理
                .catch(function (jqXHR, textStatus, errorThrown) {
                    //ajax通信でエラーが発生した場合
                    if (jqXHR.status != null) {
                        global.Site.setError(dataType.toUpperCase() + '_' + jqXHR.status);
                    }
                    //コールバック内でエラーが発生した場合 (※jqXHR=エラー)
                    else {
                        global.Site.setError(null, null, jqXHR);
                    }
                })

                //常に実行する処理
                .then(function () {
                    //読み込み完了
                    global.Site.loaded();
                });
        };

    /* 関数
    ----------------------------------------------------------*/
    SiteClass.prototype.formatNumber =
        /**
         * 数値をカンマ区切りに整形する。
         * @param {number} val 数値
         * @returns 整形した文字列
         */
        function (val) {
            return this._numFormat.format(val);
        };

    SiteClass.prototype.formatDate =
        /**
         * 日付を表す文字列を表示値に整形する。
         * @param {string}  val     値(yyyy|yyyyMM|yyyyMMdd|yyyyMMddHH) または 日付
         * @param {boolean} isShort 年を除去する場合はtrue(省略可)
         * @returns 整形した日付
         */
        function (val, isShort) {
            //値を表示値に変換
            let text = null;
            if (typeof val == 'string') {
                let date;
                switch (val.length) {
                    case 4:
                        //yyyy形式
                        date = global.Datepicker.convValToDate('year', val);
                        text = global.Datepicker.convDateToText('year', date);
                        break;

                    case 6:
                        //yyyyMM形式
                        date = global.Datepicker.convValToDate('month', val);
                        text = global.Datepicker.convDateToText('month', date);
                        break;

                    case 8:
                        //yyyyMMdd形式
                        date = global.Datepicker.convValToDate('day', val);
                        text = global.Datepicker.convDateToText('day', date);
                        break;

                    case 10:
                        //yyyyMMddHH形式
                        date = global.Datepicker.convValToDate('day', val);
                        text = global.Datepicker.convDateToText('day', date)
                            + (' ' + parseInt(val.substr(8))).slice(-2) + '時';
                        break;
                }
            } else if (val != null) {
                text = global.Datepicker.convDateToText('day', val);
            }
            //短い場合
            if (isShort) {
                //年を除去
                text = text.substr(5);
            }
            return text;
        };

    SiteClass.prototype.formatTime =
        /**
         * 時分を表示値に整形する。
         * @param {number} hour   時
         * @param {number} minute 分(省略可)
         * @returns 整形した時刻
         */
        function (hour, minute) {
            let text = (' ' + hour).slice(-2) + '時';
            if (minute != null) {
                text += (' ' + minute).slice(-2) + '分';
            }
            return text;
        };

    SiteClass.prototype.convValToDate =
        /**
         * 定型文字列を日付型に変換する。
         * @param {string} val 日付を表す定型文字列
         * @returns 日付
         */
        function (val) {
            let wk = val || '';
            switch (wk.length) {
                case 10:
                    //yyyyMMddHH形式
                    let date = global.Datepicker.convValToDate('day', val);
                    date.setHours(parseInt(wk.substr(8, 2)));
                    return date;
                case 8:
                    //yyyyMMdd形式
                    return global.Datepicker.convValToDate('day', val);
                case 6:
                    if (val.endsWith('H')) {
                        //yyyy9H形式
                        return global.Datepicker.convValToDate('half', val);
                    }
                    //yyyyMM形式
                    return global.Datepicker.convValToDate('month', val);
                case 4:
                    //yyyy形式
                    return global.Datepicker.convValToDate('year', val);
                default:
                    return null;
            }
        };


    //==============================================================================
    // イベント
    //==============================================================================
    /**
     * メニュー表示切替要素 の Click イベントを処理する。
     */
    function menuSwitch_click() {
        try {
            //メニュー表示切替
            $('body').toggleClass('menu-hide');
            //グラフのリサイズ
            global.Site.Chart.resize();

        } catch (ex) {
            //想定外エラー (通常発生しない)
            global.Site.setError(null, null, ex);
        }
    };

    /**
     * メニューリンク要素 の Click イベントを処理する。
     * @param {Event} event イベント
     * @returns 画面遷移を無効にするためfalse
     */
    function menu_click(event) {
        try {
            //読み込み中ではない場合
            if (global.Site.isLoading() == false) {
                //コンテンツ遷移
                global.Site.navigateUrl($(event.target).attr('href'));
            }

        } catch (ex) {
            //想定外エラー (通常発生しない)
            global.Site.setError(null, null, ex);
        }
        return false;
    };

    /**
     * ページナビゲーション要素 の Click イベントを処理する。
     * @param {Event} event イベント
     */
    function pageNavi_click(event) {
        try {
            //読み込み中ではない場合
            if (global.Site.isLoading() == false) {
                //ページ遷移
                global.Site.navigatePage(global.Site._pageIndex
                    + parseInt($(event.target).attr('data-add')));
            }

        } catch (ex) {
            //想定外エラー (通常発生しない)
            global.Site.setError(null, null, ex);
        }
    };


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    global.Site = new SiteClass();
}(this));

//DOMツリーの構築が完了した時
document.addEventListener('DOMContentLoaded', function () {
    try {
        //読み込み中
        Site.loading();
        //初期化
        Site.initialize(true);

    } catch (ex) {
        //想定外エラー (通常発生しない)
        Site.setError(null, null, ex);
    }
}, false);

//リソースの読み込みが完了した時
window.addEventListener('load', function () {
    try {
        //読み込み完了
        Site.loaded();

    } catch (ex) {
        //想定外エラー (通常発生しない)
        Site.setError(null, null, ex);
    }
}, false);

//ページから離れる時
window.addEventListener('unload', function () {
    try {
        //破棄
        Site.destroy(true);

    } catch (ex) {
        //想定外エラー (通常発生しない)
        Site.setError(null, null, ex);
    } finally {
        Site = null;
    }
}, false);