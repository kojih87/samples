(function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* PDF.js設定
    ----------------------------------------------------------*/
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'refs/download/pdf.worker.min.js';
    pdfjsLib.cMapUrl = 'refs/download/cmaps/';

    /* 内部定数
    ----------------------------------------------------------*/
    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** 対象要素 */
        TARGET: '.pdf',
        /** ダウンロードボタン */
        DOWNLOAD: '.pdf-download'
    };


    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    let SitePdfClass = function () {
        /**
         * 要素セレクタ毎に表示中のデータを格納する。
         */
        this._data = null;
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    SitePdfClass.prototype.initialize =
        /**
         * インスタンスを初期化する。
         */
        function () {
            //対象要素の取得
            let $target = $(DEF_SELECTOR.TARGET),
                length = $target.length;
            if (length == 0) {
                return;
            }

            //対象要素の設定
            $target
                //イベントの登録
                .delegate(DEF_SELECTOR.DOWNLOAD, 'click', download_click);

            //データの初期化
            this._data = {};
        };

    SitePdfClass.prototype.destroy =
        /**
         * インスタンスを破棄する。
         */
        function () {
            if (this._data == null) {
                return;
            }

            //データの破棄
            for (let selector in this._data) {
                this.__setData(selector, null);
            }
            this._data = null;

            //対象要素の設定解除
            $(DEF_SELECTOR.TARGET)
                //イベントの削除
                .off()
                //子要素の削除
                .empty();
        };

    /* PDF遷移
    ----------------------------------------------------------*/
    SitePdfClass.prototype.navigate =
        /**
         * 指定されたPDFファイルを表示する。
         * @param {string} selector 要素セレクタ
         * @param {string} path     PDFフォルダからの相対パス
         */
        function (selector, path) {
            let container = null,
                canvas = null;

            //読み込み中
            global.Site.loading();

            //ドキュメントの取得
            let url = global.DEF.PDF.PREFIX + path;
            pdfjsLib.getDocument(url)
                //成功した場合の処理(ドキュメント)
                .then(function (pdf) {
                    //データの設定
                    global.Site.Pdf.__setData(selector, pdf, path.split('/').pop());
                    //先頭ページの取得
                    return pdf.getPage(1);
                })
                //成功した場合の処理(先頭ページ)
                .then(function (page) {
                    //対象要素の設定
                    container = document.querySelector(selector);
                    container.innerHTML = '<div>'
                        + '<button class="pdf-download">ダウンロード</button>'
                        + '</div>'
                        + '<canvas></canvas>';
                    canvas = container.querySelector('canvas');

                    //キャンバスのサイズ調整
                    let scale = container.clientWidth / page.getViewport(1).width,
                        viewport = page.getViewport(scale);
                    canvas.width = viewport.width;
                    canvas.height = viewport.height;

                    //読み込み中
                    global.Site.loading();
                    //キャンバスへ描画
                    return page.render({
                        canvasContext: canvas.getContext('2d'),
                        viewport: viewport
                    });
                })
                //成功した場合の処理(描画)
                .then(function () {
                    //読み込み完了
                    global.Site.loaded();
                })

                //失敗した場合の処理
                .catch(function (ex) {
                    //データの設定
                    global.Site.Pdf.__setData(selector, null);
                    //エラー表示
                    global.Site.setError('PDF_404', selector, ex);
                })

                //常に実行する処理
                .finally(function () {
                    //読み込み完了
                    global.Site.loaded();
                    container = null;
                    canvas = null;
                });
        };

    SitePdfClass.prototype.__setData =
        /**
         * 表示中のデータを設定する。
         * @param {string} selector 要素セレクタ
         * @param {any}    pdf      PDFオブジェクト
         * @param {string} name     ファイル名
         */
        function (selector, pdf, name) {
            //既に設定されている場合
            if (this._data[selector] != null) {
                this._data[selector].pdf.cleanup();
                this._data[selector].pdf.destroy();
                this._data[selector].pdf = null;
                this._data[selector] = null;
            }
            //PDFオブジェクトが指定された場合
            if (pdf != null) {
                this._data[selector] = {
                    pdf: pdf,
                    name: name
                };
                pdf = null;
            }
        };

    /* PDFダウンロード
    ----------------------------------------------------------*/
    SitePdfClass.prototype.download =
        /**
         * 表示中のPDFファイルをダウンロードする。
         * @param {string} selector 要素セレクタ
         */
        function (selector) {
            //データの取得
            this._data[selector].pdf.getData().then(function (data) {
                //保存
                let blob = new Blob([data], { 'type': 'application/octet-stream' }),
                    name = global.Site.Pdf._data[selector].name;
                if (window.navigator.msSaveOrOpenBlob) {
                    window.navigator.msSaveOrOpenBlob(blob, name);
                } else if (window.URL && window.URL.createObjectURL) {
                    let a = document.createElement('a');
                    a.download = name;
                    a.href = window.URL.createObjectURL(blob);
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    a = null;
                }
            });
        };


    //==============================================================================
    // イベント
    //==============================================================================
    /**
     * ダウンロードボタン の Click イベントを処理する。
     * @param {Event} event イベント
     */
    function download_click(event) {
        //PDFダウンロード
        global.Site.Pdf.download('#' + $(event.target).parents(DEF_SELECTOR.TARGET).attr('id'));
    };


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    global.Site.Pdf = new SitePdfClass();
}(this));