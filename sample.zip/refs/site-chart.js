(function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* Chart.js設定
    ----------------------------------------------------------*/
    //レスポンシブ
    Chart.defaults.global.responsive = true;
    //アニメーション
    Chart.defaults.global.animation = false;
    //余白
    Chart.defaults.global.layout.padding.top = 5;
    Chart.defaults.global.layout.padding.bottom = 5;
    Chart.defaults.global.layout.padding.left = 5;
    Chart.defaults.global.layout.padding.right = 5;
    //フォント
    Chart.defaults.global.defaultFontFamily = 'Consolas, Meiryo';
    Chart.defaults.global.defaultFontSize = 14;
    Chart.defaults.global.legend.labels.fontSize = 15;
    Chart.defaults.global.tooltips.titleFontSize = 18;
    Chart.defaults.global.tooltips.bodyFontSize = 18;
    //色
    Chart.defaults.global.defaultColor = 'rgba(0,0,0,0)';
    Chart.defaults.global.defaultFontColor = '#333333';
    //凡例
    Chart.defaults.global.legend.fullWidth = false;
    Chart.defaults.global.legend.labels.boxWidth = 24;
    Chart.defaults.global.legend.labels.padding = 14;
    //ツールチップ
    Chart.defaults.global.hover.intersect = false;
    Chart.defaults.global.hover.mode = 'index';
    Chart.defaults.global.tooltips.intersect = false;
    Chart.defaults.global.tooltips.mode = 'index';
    Chart.defaults.global.tooltips.position = 'nearest';
    //折れ線
    Chart.defaults.global.elements.line.borderWidth = 3;
    Chart.defaults.global.elements.line.fill = false;
    Chart.defaults.global.elements.line.tension = 0;
    Chart.defaults.global.elements.point.radius = 0;

    /* 内部定数
    ----------------------------------------------------------*/
    const DEF_CONF = {
        /** X軸ID */
        X_AXIS_ID: {
            /** メイン */
            MAIN: 'x-axis',
            /** サブ(軸表示用) */
            SUB: 'x-axis-display'
        },
        /** Y軸ID */
        Y_AXIS_ID: {
            /** 主軸 */
            MAIN: 'y-axis-main',
            /** 主軸(積み上げ) */
            MAIN_STACK: 'y-axis-main-stack',
            /** 気温軸 */
            SUB: 'y-axis-sub'
        },
        /** X軸ラベル(年) */
        X_AXIS_YEAR_LABELS: ['前年3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月', '1月', '2月', '3月', '']
    };

    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** 対象要素 */
        TARGET: '.chart'
    };


    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    let SiteChartClass = function () {
        /**
         * 要素セレクタ毎に表示中のデータを格納する。
         */
        this._data = null;
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    SiteChartClass.prototype.initialize =
        /**
         * インスタンスを初期化する。
         */
        function () {
            //対象要素の取得
            let $target = $(DEF_SELECTOR.TARGET),
                length = $target.length;
            if (length == 0) {
                return;
            }

            //対象要素の設定
            $target
                //子要素の追加
                .html('<canvas></canvas>');

            //データの初期化
            this._data = {};
        };

    SiteChartClass.prototype.destroy =
        /**
         * インスタンスを破棄する。
         */
        function () {
            //データの破棄
            for (let selector in this._data) {
                this._data[selector].destroy();
                this._data[selector] = null;
            }
            this._data = null;

            //対象要素の設定解除
            $(DEF_SELECTOR.TARGET)
                //子要素の削除
                .empty();
        };

    /* グラフ生成
    ----------------------------------------------------------*/
    SiteChartClass.prototype.__createChart =
        /**
         * グラフ操作オブジェクトを生成する。
         * @param {string} selector 要素セレクタ
         * @returns オブジェクト
         */
        function (selector) {
            //設定の取得
            let conf = global.Site.config.chart[selector];

            //オブジェクトの生成 (Chart.js)
            return new Chart(
                document.querySelector(selector + ' canvas').getContext('2d'),
                {
                    type: 'bar',
                    data: {
                        //データセット
                        datasets: this.__createDatasets(conf)
                    },
                    options: {
                        //軸
                        scales: {
                            xAxes: this.__createXAxes(conf),
                            yAxes: this.__createYAxes(conf)
                        },
                        //ツールチップ
                        tooltips: {
                            callbacks: {
                                label: function (tooltipItems, data) {
                                    return data.datasets[tooltipItems.datasetIndex].label + '：'
                                        + ('      ' + global.Site.formatNumber(tooltipItems.yLabel)).slice(-6);
                                }
                            }
                        },
                        //凡例
                        legend: {
                            labels: {
                                usePointStyle: true,
                                filter: function (legendItem, data) {
                                    //ラベルがnullの場合は非表示
                                    return legendItem.text != null;
                                },
                                generateLabels: function (chart) {
                                    return chart.data.datasets.map(function (dataset, i) {
                                        //点のスタイルで表示
                                        let pointStyle;
                                        switch (dataset.type) {
                                            case global.DEF.CHART.TYPE.LINE:
                                                //折れ線
                                                pointStyle = 'line';
                                                break;
                                            case global.DEF.CHART.TYPE.BAR:
                                                //積み上げ棒
                                                pointStyle = 'rect';
                                                break;
                                        }
                                        return {
                                            text: dataset.label,
                                            fillStyle: dataset.backgroundColor,
                                            hidden: !chart.isDatasetVisible(i),
                                            lineCap: dataset.borderCapStyle,
                                            lineDash: dataset.borderDash,
                                            lineDashOffset: dataset.borderDashOffset,
                                            lineJoin: dataset.borderJoinStyle,
                                            lineWidth: dataset.borderWidth,
                                            strokeStyle: dataset.borderColor,
                                            pointStyle: pointStyle,
                                            datasetIndex: i
                                        };
                                    });
                                }
                            }
                        }
                    }
                }
            );
        };

    /* グラフ生成 - X軸
    ----------------------------------------------------------*/
    SiteChartClass.prototype.__createXAxes =
        /**
         * X軸を生成する。
         * @param {any} conf グラフ設定
         * @returns X軸
         */
        function (conf) {
            let i = 0;
            switch (conf.xAxisType) {
                case global.DEF.CHART.X_AXIS_TYPE.DAY_288:
                    return [
                        this.__createXAxis(false, i++, this.__createXAxisTimeLabels(5), false),
                        this.__createXAxis(true, i++, this.__createXAxisTimeLabels(60, true), false)
                    ];

                case global.DEF.CHART.X_AXIS_TYPE.DAY_048:
                    return [
                        this.__createXAxis(false, i++, this.__createXAxisTimeLabels(30), false),
                        this.__createXAxis(true, i++, this.__createXAxisTimeLabels(60, true), false)
                    ];

                case global.DEF.CHART.X_AXIS_TYPE.DAY_024:
                    return [
                        this.__createXAxis(true, i++, this.__createXAxisTimeLabels(60), false)
                    ];

                case global.DEF.CHART.X_AXIS_TYPE.MONTH:
                case global.DEF.CHART.X_AXIS_TYPE.YEAR:
                    return [
                        this.__createXAxis(false, i++, null, false),
                        this.__createXAxis(true, i++, null, true)
                    ];
            }
        };

    SiteChartClass.prototype.__createXAxis =
        /**
         * X軸を生成する。
         * @param {boolean}  isDisplay  表示用の場合はtrue、そうでない場合はfalse
         * @param {number}   i          X軸番号
         * @param {string[]} labels     X軸ラベル
         * @param {boolean}  isAutoSkip 間引く場合はtrue、そうでない場合はfalse
         * @returns X軸
         */
        function (isDisplay, i, labels, isAutoSkip) {
            return {
                display: isDisplay,
                stacked: true,
                id: (i == 0) ? DEF_CONF.X_AXIS_ID.MAIN : DEF_CONF.X_AXIS_ID.SUB,
                labels: labels,
                ticks: {
                    autoSkip: isAutoSkip,
                    maxRotation: 0,
                    labelOffset: (labels && labels[0] == '') ? -20 : 0
                }
            };
        };

    SiteChartClass.prototype.__createXAxisTimeLabels =
        /**
         * X軸ラベルを生成する。(時間)
         * @param {number}  step    分単位の間隔(5|30|60)
         * @param {boolean} isSpace 先頭を空にする場合はtrue(省略可)
         * @returns X軸ラベル
         */
        function (step, isSpace) {
            let isHourOnly = (step == 60),
                labels = [],
                i = 0;
            for (let hour = 0; hour < 24; hour++) {
                let hourLabel = (' ' + hour).slice(-2) + '時';
                if (isHourOnly) {
                    labels[i++] = hourLabel;
                }
                else {
                    for (let minute = 0; minute < 60; minute += step) {
                        labels[i++] = hourLabel + (' ' + minute).slice(-2) + '分';
                    }
                }
            }
            labels[i++] = isHourOnly ? '24時' : '24時 0分';
            if (isSpace) {
                labels[0] = '';
            } else {
                labels.shift();
            }
            return labels;
        };

    SiteChartClass.prototype.__createXAxisDateLabels =
        /**
         * X軸ラベルを生成する。(日付)
         * @param {number} year  年
         * @param {number} month 月(1～12)
         * @param {number} range 範囲
         * @returns X軸ラベル
         */
        function (year, month, range) {
            let d = new Date(year, month - 1, 1),
                max = new Date(year, month + range, 1),
                labels = [],
                i = 0;
            while (d < max) {
                labels[i++] = (' ' + (d.getMonth() + 1)).slice(-2) + '月'
                    + (' ' + d.getDate()).slice(-2) + '日';
                d.setDate(d.getDate() + 1);
            }
            return labels;
        };

    /* グラフ生成 - Y軸
    ----------------------------------------------------------*/
    SiteChartClass.prototype.__createYAxes =
        /**
         * Y軸を生成する。
         * @param {any} conf グラフ設定
         * @returns Y軸
         */
        function (conf) {
            let min = conf.yAxis.min,
                step = conf.yAxis.step,
                count = conf.yAxis.count,
                max = min + (step * count),
                yAxes = [],
                i = 0;

            //主軸
            yAxes[i++] = {
                id: DEF_CONF.Y_AXIS_ID.MAIN,
                ticks: {
                    min: min,
                    max: max,
                    callback: function (value, index, values) {
                        //最上部の場合
                        if (index == 0) {
                            //単位＋カンマ区切り
                            let unit = '(' + global.Site.config.chart['#chart1'].yAxis.unit + ')';
                            return [unit, global.Site.formatNumber(value), ''];
                        }
                        //上記以外の場合
                        else {
                            //カンマ区切り
                            return global.Site.formatNumber(value);
                        }
                    }
                }
            };

            //主軸(積み上げ)
            yAxes[i++] = {
                id: DEF_CONF.Y_AXIS_ID.MAIN_STACK,
                display: false,
                stacked: true,
                ticks: {
                    min: min,
                    max: max
                }
            };

            //気温軸
            yAxes[i++] = (function () {
                //気温軸データが存在チェック
                let hasTemperature = (0 <= conf.datasets.map(function (dsConf) {
                    return dsConf.isTemperature;
                }).indexOf(true));
                return {
                    id: DEF_CONF.Y_AXIS_ID.SUB,
                    position: 'right',
                    gridLines: {
                        display: false
                    },
                    scaleLabel: {
                        display: false
                    },
                    ticks: {
                        display: hasTemperature,
                        min: 0,
                        max: 10 * conf.yAxis.count,
                        stepSize: 5,
                        callback: function (value, index, values) {
                            //境界の計算
                            let n = Math.floor((values.length / 5) * 2);

                            //境界より上部の場合
                            if (index < n) {
                                //非表示
                                return '';
                            }
                            //境界の場合
                            else if (index == n) {
                                //単位＋
                                return ['(℃)', value, ''];
                            }
                            //上記以外の場合
                            else {
                                return value;
                            }
                        }
                    }
                };
            }());

            return yAxes;
        };

    /* グラフ生成 - データセット
    ----------------------------------------------------------*/
    SiteChartClass.prototype.__createDatasets =
        /**
         * データセットを生成する。
         * @param {any} conf サイト設定
         * @returns データセット
         */
        function (conf) {
            return conf.datasets.map(function (dsConf) {
                return global.Site.Chart.__createDataset(dsConf);
            });
        };

    SiteChartClass.prototype.__createDataset =
        /**
         * データセットを生成する。
         * @param {any} dsConf データセット設定
         * @returns データセット
         */
        function (dsConf) {
            let rgb = dsConf.rgb.join(',');
            switch (dsConf.type) {
                //積み上げ棒
                case global.DEF.CHART.TYPE.BAR:
                    return {
                        yAxisID: DEF_CONF.Y_AXIS_ID.MAIN_STACK,
                        type: 'bar',
                        label: dsConf.label,
                        stacked: true,
                        borderWidth: 0.3,
                        borderColor: 'rgba(0,0,0,1)',
                        backgroundColor: 'rgba(' + rgb + ',1)'
                    };

                //折れ線
                case global.DEF.CHART.TYPE.LINE:
                    return {
                        yAxisID: dsConf.isTemperature ? DEF_CONF.Y_AXIS_ID.SUB : DEF_CONF.Y_AXIS_ID.MAIN,
                        type: 'line',
                        label: dsConf.label,
                        borderColor: 'rgba(' + rgb + ',1)',
                        backgroundColor: 'rgba(' + rgb + ',1)',
                        fill: false,
                        //破線
                        borderDash: dsConf.isDash ? [6, 3] : [],
                        //階段
                        steppedLine: dsConf.isStep ? 'middle' : false,
                        //点
                        radius: dsConf.isPoint ? 5 : 0,
                        pointStyle: 'rectRot',
                        pointHoverRadius: 5,
                        pointBorderWidth: 0.3,
                        pointBorderColor: 'rgba(0,0,0,1)'
                    };
            }
        };

    /* グラフ更新
    ----------------------------------------------------------*/
    SiteChartClass.prototype.update =
        /**
         * グラフを更新する。
         * @param {string} selector 要素セレクタ
         * @param {any}    info     更新情報
         */
        function (selector, info) {
            let conf = global.Site.config.chart[selector],
                chart = this.__getChart(selector),
                datasetsLength = chart.data.datasets.length,
                infoLength = info.data.length,
                hasTemperature = false,
                min = 20,
                maxLabelLength = 0,
                labelLength;

            //データの更新
            for (let i = 0; i < datasetsLength; i++) {
                if (i < infoLength) {
                    chart.data.datasets[i].data = info.data[i].values;
                    if (info.data[i].label) {
                        chart.data.datasets[i].label = info.data[i].label;
                    }
                    //ラベル長の最大を退避
                    labelLength = chart.data.datasets[i].label.trim().length;
                    if (maxLabelLength < labelLength) {
                        maxLabelLength = labelLength;
                    }
                    //気温データの場合
                    if (conf.datasets[i].isTemperature) {
                        let length = info.data[i].values.length;
                        for (let j = 0; j < length; j++) {
                            let val = info.data[i].values[j];
                            if (val < min) {
                                min = val;
                            }
                        }
                        hasTemperature = true;
                    }
                } else {
                    chart.data.datasets[i].data = null;
                    chart.data.datasets[i].label = null;
                }
            }
            for (let i = 0; i < datasetsLength; i++) {
                let label = chart.data.datasets[i].label;
                if (label == null) {
                    break;
                }
                chart.data.datasets[i].label = (label.trim() + '　　　　　　　　　　').substr(0, maxLabelLength);
            }

            //X軸ラベルの更新
            let labels = [];
            switch (conf.xAxisType) {
                case global.DEF.CHART.X_AXIS_TYPE.MONTH:
                    labels[0] = this.__createXAxisDateLabels(info.year, info.month, 2);
                    labels[1] = labels[0].map(function (lbl) { return lbl.slice(-3); });
                    break;
                case global.DEF.CHART.X_AXIS_TYPE.YEAR:
                    labels[0] = this.__createXAxisDateLabels(info.year, 3, 13);
                    labels[1] = DEF_CONF.X_AXIS_YEAR_LABELS;
                    break;
            }
            if (0 < labels.length) {
                chart.scales[DEF_CONF.X_AXIS_ID.MAIN].options.labels = labels[0];
                chart.scales[DEF_CONF.X_AXIS_ID.SUB].options.labels = labels[1];
            }

            //気温軸の更新
            if (hasTemperature) {
                //最小値を5の倍数に調整
                min = Math.floor((min - 2) / 5) * 5;
                chart.scales[DEF_CONF.Y_AXIS_ID.SUB].options.ticks.min = min;
                chart.scales[DEF_CONF.Y_AXIS_ID.SUB].options.ticks.max = min + 10 * conf.yAxis.count;
            }

            //グラフへ反映
            chart.update();
        };

    SiteChartClass.prototype.__getChart =
        /**
         * グラフ操作オブジェクトを取得する。
         * @param {string} selector 要素セレクタ
         */
        function (selector) {
            //オブジェクトが存在しない場合
            if (this._data[selector] == null) {
                //オブジェクトの生成
                this._data[selector] = this.__createChart(selector);
            }
            return this._data[selector];
        };

    /* リサイズ
    ----------------------------------------------------------*/
    SiteChartClass.prototype.resize =
        /**
         * グラフをリサイズする。
         */
        function () {
            for (let selector in this._data) {
                this._data[selector].resize();
            }
        };


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    global.Site.Chart = new SiteChartClass();
}(this));