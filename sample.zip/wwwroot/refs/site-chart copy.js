Site.Chart = (function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* Chart.js
    ----------------------------------------------------------*/
    //レスポンシブ
    Chart.defaults.global.responsive = true;
    //余白
    Chart.defaults.global.layout.padding.top = 5;
    Chart.defaults.global.layout.padding.bottom = 10;
    Chart.defaults.global.layout.padding.left = 20;
    Chart.defaults.global.layout.padding.right = 20;
    //フォント
    Chart.defaults.global.defaultFontFamily = document.body.currentStyle.fontFamily;
    Chart.defaults.global.defaultFontSize = 15;
    Chart.defaults.global.legend.labels.fontSize = 15;
    Chart.defaults.global.tooltips.titleFontSize = 18;
    Chart.defaults.global.tooltips.bodyFontSize = 18;
    //色
    Chart.defaults.global.defaultColor = 'rgba(0,0,0,0)';
    Chart.defaults.global.defaultFontColor = document.body.currentStyle.color;

    //ツールチップ
    Chart.defaults.global.hover.intersect = false;
    Chart.defaults.global.hover.mode = 'index';
    Chart.defaults.global.tooltips.intersect = false;
    Chart.defaults.global.tooltips.mode = 'index';
    Chart.defaults.global.tooltips.position = 'nearest';

    /** アニメーション */
    Chart.defaults.global.animation = false;

    /** 折れ線 */
    //Chart.defaults.global.elements.line.backgroundColor = ''
    //Chart.defaults.global.elements.line.borderCapStyle
    //Chart.defaults.global.elements.line.borderColor
    //Chart.defaults.global.elements.line.borderDash
    //Chart.defaults.global.elements.line.borderDashOffset
    //Chart.defaults.global.elements.line.borderJoinStyle
    Chart.defaults.global.elements.line.borderWidth = 3;
    //Chart.defaults.global.elements.line.capBezierPoints
    Chart.defaults.global.elements.line.fill = false;
    Chart.defaults.global.elements.line.tension = 0;
    Chart.defaults.global.elements.point.radius = 0;


    Chart.defaults.global.legend.fullWidth = false;
    Chart.defaults.global.legend.labels.boxWidth = 24;
    Chart.defaults.global.legend.labels.padding = 14;



    /* 内部定数
    ----------------------------------------------------------*/
    const DEF_CONF = {
        //X軸ID
        X_AXIS_ID: {
            MAIN: 'x-axis',
            SUB: 'x-axis-hour'
        },
        //Y軸ID
        Y_AXIS_ID: {
            //主軸
            MAIN: 'y-axis-main',
            //主軸(積み上げ)
            MAIN_STACK: 'y-axis-main-stack',
            //気温軸
            SUB: 'y-axis-sub'
        }
    };

    const DEF_SELECTOR = {
        TARGET: '.chart'
    };
    /* 定数
    ----------------------------------------------------------*/

    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    var SiteChartClass = function () {
        /**
         * 要素セレクタ毎にグラフ操作オブジェクトを格納する。
         */
        this._chart = null;
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype.initialize =
            /**
             * インスタンスを初期化する。
             */
            function () {
                //対象要素の設定
                $(DEF_SELECTOR.TARGET)
                    .wrap('<div />');

                //オブジェクトの生成
                this._chart = {};
            };

        SiteChartClass.prototype.destroy =
            /**
             * インスタンスを破棄する。
             */
            function () {
                //対象要素の設定
                $(DEF_SELECTOR.TARGET)
                    .unwrap();

                //オブジェクトの削除
                for (var selector in this._chart) {
                    this._chart[selector].destroy();
                    this._chart[selector] = null;
                }
                this._chart = null;
            };
    }());

    /* グラフ操作オブジェクト
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype._getChart =
            /**
             * グラフ操作オブジェクトを取得する。
             * @param {string} selector 要素セレクタ
             */
            function (selector) {
                //オブジェクトが存在しない場合
                if (!this._chart[selector]) {
                    //オブジェクトの生成
                    var conf = global.Site.config.chart[selector];
                    this._chart[selector] = new Chart(
                        $(selector)[0].getContext('2d'),
                        {
                            type: conf.type,
                            data: {
                                datasets: this._createDatasets(conf)
                            },
                            options: {
                                scales: {
                                    xAxes: this._createXAxes(conf),
                                    yAxes: this._createYAxes(conf)
                                }
                            }
                        }
                    );
                }
                return this._chart[selector];
            };
    }());

    /* X軸
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype._createXAxes =
            /**
             * X軸を生成する。
             * @param {any} conf グラフ設定
             * @returns X軸
             */
            function (conf) {
                var xAxis = {
                    id: DEF_CONF.X_AXIS_ID.MAIN,
                    gridLines: {

                    },
                    scaleLabel: false,
                    ticks: {
                        autoSkip: true,
                        maxRotation: 0,
                    }
                };
                switch (conf.xAxisType) {
                    case global.DEF.CHART.X_AXIS_TYPE.DAY_288:
                        return [
                            {
                                id: DEF_CONF.X_AXIS_ID.MAIN,
                                labels: global.Site.Chart._createXAxisTimeLabels(5),
                                ticks: {
                                    maxRotation: 0,
                                    maxTicksLimit: 25,
                                    callback: function (label, index, labels) {
                                        var hour = Math.floor(index / 12) + 1;
                                        if (24 < hour) {
                                            return '';
                                        }
                                        return hour + '時';
                                    }
                                }
                            },
                            {
                                id: DEF_CONF.X_AXIS_ID.SUB,
                                display: false,
                                labels: global.Site.Chart._createXAxisTimeLabels(60)
                            }
                        ];

                    case global.DEF.CHART.X_AXIS_TYPE.DAY_048:
                        xAxis.ticks.maxTicksLimit = 24;
                        return [xAxis];

                    case global.DEF.CHART.X_AXIS_TYPE.DAY_024:
                        xAxis.ticks.maxTicksLimit = 24;
                        return [xAxis];

                    case global.DEF.CHART.X_AXIS_TYPE.MONTH:
                        return [xAxis];

                    case global.DEF.CHART.X_AXIS_TYPE.YEAR:
                        return [xAxis];
                }
            };
        function test() {
            var xAxes = [],
                i = 0;

            var opt = (function () {
                var labels,
                    maxTicksLimit,
                    callback;
                switch (conf.xAxisType) {
                    case global.DEF.CHART.X_AXIS_TYPE.DAY_288:
                        labels = global.Site.Chart._createXAxisTimeLabels(5);
                        maxTicksLimit = 24;
                        callback = function (label, index, labels) {
                            var hour = Math.floor(index / 12) + 1;
                            if (24 < hour) {
                                return '';
                            }
                            return hour + '時';
                        };
                        break;

                    case global.DEF.CHART.X_AXIS_TYPE.DAY_048:
                        labels = global.Site.Chart._createXAxisTimeLabels(30);
                        maxTicksLimit = 24;
                        callback = function (label, index, labels) {
                            var hour = Math.floor(index / 2) + 1;
                            if (24 < hour) {
                                return '';
                            }
                            return hour + '時';
                        };
                        break;

                    case global.DEF.CHART.X_AXIS_TYPE.DAY_024:
                        labels = global.Site.Chart._createXAxisTimeLabels(60);
                        maxTicksLimit = 24;
                        break;

                    case global.DEF.CHART.X_AXIS_TYPE.MONTH:
                        maxTicksLimit = 31;
                        callback = function (label, index, labels) {
                            return label.slice(-3);
                        };
                        break;

                    case global.DEF.CHART.X_AXIS_TYPE.YEAR:
                        maxTicksLimit = 13;
                        callback = function (label, index, labels) {
                            if (index == 0) {
                                return '' + label.substr(0, 3);
                            }
                            return label.substr(0, 3);
                        };
                        break;
                }
                return {
                    labels,
                    maxTicksLimit,
                    callback
                };
            }());

            //
            return {
                id: DEF_CONF.X_AXIS_ID.MAIN,
                labels: opt.labels,
                ticks: {
                    maxRotation: 0,
                    maxTicksLimit: opt.maxTicksLimit,
                    callback: opt.callback
                }
            };
        };

        SiteChartClass.prototype._createXAxisTimeLabels =
            /**
             * X軸ラベルを生成する。(時間)
             * @param {number} step 分単位の間隔(5|30|60)
             * @returns X軸ラベル
             */
            function (step) {
                var isHourOnly = (step == 60),
                    labels = [],
                    i = 0;
                for (var hour = 0; hour < 24; hour++) {
                    var hourLabel = (' ' + hour).slice(-2) + '時';
                    if (isHourOnly) {
                        labels[i++] = hourLabel;
                    }
                    else {
                        for (var minute = 0; minute < 60; minute += step) {
                            labels[i++] = hourLabel + (' ' + minute).slice(-2) + '分';
                        }
                    }
                }
                labels[i++] = isHourOnly ? '24時' : '24時 0分';
                labels.shift();
                return labels;
            };

        SiteChartClass.prototype._createXAxisDateLabels =
            /**
             * X軸ラベルを生成する。(日付)
             * @param {number} year  年
             * @param {number} month 月(1～12)
             * @param {number} range 範囲
             * @returns X軸ラベル
             */
            function (year, month, range) {
                var d = new Date(year, month - 1, 1),
                    max = new Date(year, month + range, 1),
                    labels = [],
                    i = 0;
                while (d < max) {
                    labels[i++] = (' ' + (d.getMonth() + 1)).slice(-2) + '月'
                        + (' ' + d.getDate()).slice(-2) + '日';
                    d.setDate(d.getDate() + 1);
                }
                return labels;
            };
    }());

    /* Y軸
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype._createYAxes =
            /**
             * Y軸を生成する。
             * @param {any} conf グラフ設定
             * @returns Y軸
             */
            function (conf) {
                var min = conf.yAxis.min,
                    step = conf.yAxis.step,
                    count = conf.yAxis.count,
                    unit = '(' + conf.yAxis.unit + ')',
                    max = min + (step * count),
                    yAxes = [],
                    i = 0;

                //主軸
                yAxes[i++] = {
                    id: DEF_CONF.Y_AXIS_ID.MAIN,
                    scaleLabel: {

                    },
                    ticks: {
                        min: min,
                        max: max,
                        callback: function (label, index, labels) {
                            if (0 < index) {
                                return global.Site.formatNumber(parseInt(label));
                            }
                            return [unit, global.Site.formatNumber(parseInt(label)), ''];
                        }
                    }
                };

                //主軸(積み上げ)
                yAxes[i++] = {
                    id: DEF_CONF.Y_AXIS_ID.MAIN_STACK,
                    display: false,
                    ticks: {
                        min: min,
                        max: max
                    }
                };

                //気温軸
                yAxes[i++] = (function () {

                    return {
                        id: DEF_CONF.Y_AXIS_ID.SUB,
                        position: 'right',
                        gridLines: {
                            display: false
                        },
                        scaleLabel: {
                            display: false
                        },
                        ticks: {

                        }
                    }
                }());

                return yAxes;
            };
    }());

    /* データセット
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype._createDatasets =
            /**
             * データセットを生成する。
             * @param {any} conf サイト設定
             * @returns データセット
             */
            function (conf) {
                return conf.datasets.map(function (dsConf) {
                    return _createDataset(dsConf);
                });
            };

        /**
         * データセットを生成する。
         * @param {any} dsConf データセット設定
         * @returns データセット
         */
        function _createDataset(dsConf) {
            var rgb = dsConf.rgb.join(',');
            switch (dsConf.type) {
                //積み上げ棒
                case global.DEF.CHART.TYPE.BAR:
                    return {
                        type: 'bar',
                        label: dsConf.label,
                        stacked: true,
                        borderColor: 'rgba(' + rgb + ',1)',
                        backgroundColor: 'rgba(' + rgb + ',0.7)'
                    };

                //折れ線
                case global.DEF.CHART.TYPE.LINE:
                    return {
                        type: 'line',
                        label: dsConf.label,
                        borderColor: 'rgba(' + rgb + ',1)',
                        fill: false
                    };
            }
        };
    }());

    /* グラフ操作
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype.update =
            /**
             * グラフを更新する。
             * @param {string} selector 要素セレクタ
             * @param {any}    info     更新情報
             */
            function (selector, info) {
                var chart = this._getChart(selector),
                    datasets = chart.data.datasets,
                    datasetsLength = datasets.length,
                    infoLength = info.length;

                //データの更新
                for (var i = 0; i < datasetsLength; i++) {
                    if (i < infoLength) {
                        datasets[i].data = info[i].data;
                        if (info[i].label) {
                            datasets[i].label = info[i].label;
                        }
                        datasets[i].visible = true;
                    } else {
                        datasets[i].visible = false;
                    }
                }

                

                //グラフへ反映
                chart.update();
            };

        SiteChartClass.prototype.resize =
            /**
             * グラフをリサイズする。
             */
            function () {
                for (var selector in this._chart) {
                    this._chart[selector].resize();
                }
            };
    }());


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    return new SiteChartClass();
}(this));