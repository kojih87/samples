var Datepicker = (function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* 内部定数
    ----------------------------------------------------------*/
    /** 設定 */
    const DEF_CONF = {
        /** タイプ */
        TYPE: {
            /** 日 */
            DAY: 'day',
            /** 月 */
            MONTH: 'month',
            /** 年 */
            YEAR: 'year',
            /** 半期 */
            HALF: 'half'
        },

        /** タイプ毎のビュー階層 */
        VIEWS: {
            /** 日 */
            'day': ['day', 'month', 'year'],
            /** 月 */
            'month': ['month', 'year'],
            /** 年 */
            'year': ['year'],
            /** 半期 */
            'half': ['half', 'year']
        },

        /** タイプ毎の行列 */
        MATRIX: {
            /** 日 */
            'day': { maxRow: 6, maxCol: 7 },
            /** 月 */
            'month': { maxRow: 3, maxCol: 4 },
            /** 年 */
            'year': { maxRow: 3, maxCol: 4 },
            /** 半期 */
            'half': { maxRow: 1, maxCol: 2 }
        },

        /** カレンダー状態の初期値 */
        DEFAULT: {
            /** タイプ */
            TYPE: 'day',
            /** 最小日付 */
            MIN: new Date(1990, 0, 1),
            /** 最大日付 */
            MAX: new Date(2999, 11, 31)
        },

        /** 属性監視オプション */
        OPTS: {
            attributes: true,
            attributeFilter: ['data-val']
        },

        /** 表示値 */
        TEXT: {
            /** 曜日 */
            DAYS: ['日', '月', '火', '水', '木', '金', '土'],
            /** 月 */
            MONTH: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
            /** 半期 */
            HALF: ['上期', '下期']
        }
    };

    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** 対象要素 */
        TARGET: '.datepicker',
        /** ポップアップ要素 */
        POPUP: '#datepicker-popup',
        /** アクション要素 */
        ACTION: '.calendar-action'
    };

    /** 属性 */
    const DEF_ATTR = {
        /** タイプ */
        TYPE: 'data-type',
        /** 値 */
        VAL: 'data-val',
        /** 最小値 */
        MINVAL: 'data-minval',
        /** 最大値 */
        MAXVAL: 'data-maxval',
        /** アクション */
        ACTION: 'data-action'
    };

    /** アクション */
    const DEF_ACTION = {
        /** 前ビュー遷移 */
        PREV: 'prev',
        /** 次ビュー遷移 */
        NEXT: 'next',
        /** 上位ビュー遷移 */
        UP: 'up',
        /** 下位ビュー遷移 */
        DOWN: 'down',
        /** 選択 */
        SELECT: 'select'
    };

    /** HTML */
    const DEF_HTML = {
        POPUP: '<div id="datepicker-popup">'
            + '<div class="calendar">'
            + '<nav>'
            + '<svg class="calendar-action" data-action="prev"><path d="M25,5 L15,15 25,25"></path></svg>'
            + '<span class="calendar-action" data-action="up"></span>'
            + '<svg class="calendar-action" data-action="next"><path d="M15,5 L25,15 15,25"></path></svg>'
            + '</nav>'
            + '<table></table>'
            + '</div>'
            + '</div>'
    };


    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    var DatepickerClass = function () {
        /**
         * 対象要素の属性監視オブジェクトを格納する。
         */
        this._observer = null;

        /**
         * ポップアップ表示中の対象要素を格納する。
         */
        this._$el = null;

        /**
         * 表示中のポップアップ要素を格納する。
         */
        this._$popup = null;

        /**
         * カレンダーの状態を格納する。
         */
        this._state = null;
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    (function () {
        DatepickerClass.prototype.initialize =
            /**
             * インスタンスを初期化する。
             */
            function () {
                var $target = $(DEF_SELECTOR.TARGET),
                    length = $target.length;
                if (0 < length) {
                    //対象要素の設定
                    $target
                        //読み取り専用
                        .attr('readonly', true)
                        //イベントの登録
                        .on('click', target_focus)
                        .on('focus', target_focus)
                        .on('blur', target_blur);

                    //対象要素の属性監視
                    this._observer = new MutationObserver(target_modified);
                    for (var i = 0; i < length; i++) {
                        this._observer.observe($target[i], DEF_CONF.OPTS);
                    }
                }
            };

        DatepickerClass.prototype.destroy =
            /**
             * インスタンスを破棄する。
             */
            function () {
                if (this._observer) {
                    //対象要素の設定解除
                    $(DEF_SELECTOR.TARGET)
                        //読み取り専用解除
                        .attr('readonly', false)
                        //イベントの削除
                        .off();

                    //対象要素の属性監視解除
                    this._observer.disconnect();
                    this._observer = null;
                }
            };
    }());

    /* ポップアップ
    ----------------------------------------------------------*/
    (function () {
        //キャンセルフラグ
        var _isCancel = false;

        DatepickerClass.prototype.show =
            /**
             * ポップアップを表示する。
             * @param {HTMLInputElement} el 対象要素
             */
            function (el) {
                //既に表示中の場合
                if (this._$popup != null) {
                    return;
                }

                //ポップアップ要素の追加
                var rect = el.getBoundingClientRect();
                this._$el = $(el).after(DEF_HTML.POPUP);
                this._$popup = $(DEF_SELECTOR.POPUP)
                    //イベントの登録
                    .on('mousedown', popup_mousedown)
                    .delegate(DEF_SELECTOR.ACTION, 'click', action_click)
                    //表示位置の設定
                    .offset({ top: rect.bottom + 12, left: rect.left });

                //カレンダーの更新
                this.updateCalendar();
            };

        DatepickerClass.prototype.hide =
            /**
             * 表示中のポップアップを削除する。
             */
            function () {
                //ポップアップ操作中の場合
                if (_isCancel) {
                    this._$el.focus();
                    _isCancel = false;
                    return;
                }
                //表示中ではない場合
                if (this._$popup == null) {
                    return;
                }

                //ポップアップ要素の削除
                this._$popup.remove();
                this._$popup = null;
                this._$el = null;
                this._state = null;
            };

        DatepickerClass.prototype.cancelHide =
            /**
             * 次のポップアップ削除をキャンセルする。
             */
            function () {
                _isCancel = true;
            };
    }());

    /* アクション
    ----------------------------------------------------------*/
    (function () {
        DatepickerClass.prototype.action =
            /**
             * アクションを実行する。
             * @param {HTMLInputElement} el アクション要素
             */
            function (el) {
                var $el = $(el),
                    act = $el.attr(DEF_ATTR.ACTION),
                    val = $el.attr(DEF_ATTR.VAL);
                //console.debug('Datepicker.action( %s, %s )', act, val);

                //アクションの判定
                switch (act) {
                    case DEF_ACTION.PREV:
                    case DEF_ACTION.NEXT:
                        this._state.viewDate = _convValToDate(this._state.baseType, val);
                        break;
                    case DEF_ACTION.UP:
                        this._state.index++;
                        break;
                    case DEF_ACTION.DOWN:
                        this._state.index--;
                        this._state.viewDate = _convValToDate(this._state.baseType, val);
                        break;

                    case DEF_ACTION.SELECT:
                        this._$el.attr(DEF_ATTR.VAL, val);
                        this.hide();
                        return;
                }

                //カレンダーの更新
                this.updateCalendar();
            };
    }());

    /* カレンダー
    ----------------------------------------------------------*/
    (function () {
        //曜日ヘッダ
        var _header = null;

        DatepickerClass.prototype.updateCalendar =
            /**
             * カレンダーを更新する。
             */
            function () {
                var state = this.getState(),
                    type = DEF_CONF.VIEWS[state.baseType][state.index];

                //ナビゲーションの編集
                var prevViewDate = _getPrevViewDate(type, state.viewDate, state.minDate),
                    nextViewDate = _getNextViewDate(type, state.viewDate, state.maxDate),
                    viewText = _getViewText(type, state.viewDate),
                    canUp = state.index < DEF_CONF.VIEWS[state.baseType].length - 1;
                this._$popup.find('svg[data-action=prev]')
                    .css('visibility', prevViewDate ? 'visible' : 'hidden')
                    .attr(DEF_ATTR.VAL, _convDateToVal(state.baseType, prevViewDate));
                this._$popup.find('svg[data-action=next]')
                    .css('visibility', nextViewDate ? 'visible' : 'hidden')
                    .attr(DEF_ATTR.VAL, _convDateToVal(state.baseType, nextViewDate));
                this._$popup.find('span')
                    .text(viewText)
                    .attr('class', canUp ? 'calendar-action' : '');

                //カレンダーの編集
                var html = (function () {
                    var
                        matrix = DEF_CONF.MATRIX[type],
                        d = _getFirstDate(type, state.viewDate),
                        ret;
                    ret = _getHeader(type) + '<tbody>';
                    for (var row = 0; row < matrix.maxRow; row++) {
                        ret += '<tr>';
                        for (var col = 0; col < matrix.maxCol; col++) {
                            if (_isWithinRange(type, d, state.minDate, state.maxDate)) {
                                var act = (state.index == 0 ? DEF_ACTION.SELECT : DEF_ACTION.DOWN),
                                    val = _convDateToVal(state.baseType, d),
                                    cls = _getCellClass(type, d, state.currDate, state.viewDate),
                                    txt = _getCellText(type, d);
                                ret += '<td class="' + cls + '" '
                                    + DEF_ATTR.ACTION + '="' + act + '" '
                                    + DEF_ATTR.VAL + '="' + val + '">'
                                    + txt + '</td>';
                            } else {
                                ret += '<td><br /></td>';
                            }
                            //次の日付
                            _moveNextDate(type, d);
                        }
                        ret += '</tr>';
                    }
                    ret += '</tbody>';
                    return ret;
                }());
                this._$popup.find('table').html(html);
            };

        DatepickerClass.prototype.getState =
            /**
             * カレンダーの状態を取得する。
             * @returns カレンダー状態
             */
            function () {
                //状態が存在しない場合
                if (this._state == null) {
                    //対象要素の属性から生成
                    this._state = (function ($el) {
                        var type = $el.attr(DEF_ATTR.TYPE) || DEF_CONF.DEFAULT.TYPE,
                            minDate = _convValToDate(type, $el.attr(DEF_ATTR.MINVAL))
                                || DEF_CONF.DEFAULT.MIN,
                            maxDate = _convValToDate(type, $el.attr(DEF_ATTR.MAXVAL))
                                || DEF_CONF.DEFAULT.MAX,
                            currDate = _convValToDate(type, $el.attr(DEF_ATTR.VAL))
                                || new Date();
                        return {
                            baseType: type,
                            minDate: minDate,
                            maxDate: maxDate,
                            currDate: currDate,
                            viewDate: currDate,
                            index: 0
                        };
                    }(this._$el));
                }
                return this._state;
            };

        /**
         * 前ビューの日付を取得する。
         * @param {string} type タイプ 
         * @param {Date}   d    日付
         * @param {Date}   min  最小日付
         * @returns 前ビューの日付 または null
         */
        function _getPrevViewDate(type, d, min) {
            var date = null;
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    var val = _convDateToVal(DEF_CONF.TYPE.MONTH, d),
                        minVal = _convDateToVal(DEF_CONF.TYPE.MONTH, min);
                    if (minVal < val) {
                        date = new Date(d.getFullYear(), d.getMonth() - 1, d.getDate());
                        //日が移動後の月末より大きい場合
                        if (d.getMonth() == date.getMonth()) {
                            date.setDate(0);
                        }
                    }
                    break;

                case DEF_CONF.TYPE.MONTH:
                case DEF_CONF.TYPE.HALF:
                    if (min.getFullYear() < d.getFullYear()) {
                        date = new Date(d.getFullYear() - 1, d.getMonth(), d.getDate());
                    }
                    break;

                case DEF_CONF.TYPE.YEAR:
                    var year = Math.floor((d.getFullYear() - 1) / 12) * 12 + 1;
                    if (min.getFullYear() < year) {
                        date = new Date(d.getFullYear() - 12, d.getMonth(), d.getDate());
                    }
                    break;
            }
            return date;
        };

        /**
         * 次ビューの日付を取得する。
         * @param {string} type タイプ 
         * @param {Date}   d    日付
         * @param {Date}   max  最大日付
         * @returns 次ビューの日付 または null
         */
        function _getNextViewDate(type, d, max) {
            var date = null;
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    var val = _convDateToVal(DEF_CONF.TYPE.MONTH, d),
                        maxVal = _convDateToVal(DEF_CONF.TYPE.MONTH, max);
                    if (val < maxVal) {
                        date = new Date(d.getFullYear(), d.getMonth() + 1, d.getDate());
                        //日が移動後の月末より大きい場合
                        if (1 < date.getMonth() - d.getMonth()) {
                            date.setDate(0);
                        }
                    }
                    break;

                case DEF_CONF.TYPE.MONTH:
                case DEF_CONF.TYPE.HALF:
                    if (d.getFullYear() < max.getFullYear()) {
                        date = new Date(d.getFullYear() + 1, d.getMonth(), d.getDate());
                    }
                    break;

                case DEF_CONF.TYPE.YEAR:
                    var year = Math.floor((d.getFullYear() - 1) / 12) * 12 + 13;
                    if (year < max.getFullYear()) {
                        return new Date(d.getFullYear() + 12, d.getMonth(), d.getDate());
                    }
                    break;
            }
            return date;
        };

        /**
         * ビューのタイトルを取得する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         */
        function _getViewText(type, d) {
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    return _convDateToText(DEF_CONF.TYPE.MONTH, d);

                case DEF_CONF.TYPE.MONTH:
                case DEF_CONF.TYPE.HALF:
                    return _convDateToText(DEF_CONF.TYPE.YEAR, d);

                case DEF_CONF.TYPE.YEAR:
                    var year = Math.floor((d.getFullYear() - 1) / 12) * 12 + 1;
                    return year + ' - ' + (year + 11);
            }
        };

        /**
         * カレンダーのヘッダを取得する。
         * @param {string} type タイプ
         * @returns 日カレンダーの場合は曜日ヘッダ、そうでない場合は空
         */
        function _getHeader(type) {
            if (type == DEF_CONF.TYPE.DAY) {
                if (_header == null) {
                    _header = '<thead><tr>';
                    for (var i = 0; i < DEF_CONF.TEXT.DAYS.length; i++) {
                        var cls = '';
                        if (i == 0) {
                            cls = ' class="calendar-cell-holiday"';
                        } else if (i == 6) {
                            cls = ' class="calendar-cell-saturday"';
                        }
                        _header += '<th' + cls + '>' + DEF_CONF.TEXT.DAYS[i] + '</th>'
                    }
                    _header += '</tr></thead>';
                }
                return _header;
            }
            return '';
        };

        /**
         * カレンダーの先頭日付を取得する。
         * @param {string} type タイプ
         * @param {Date}   d    日付
         * @returns 先頭日付
         */
        function _getFirstDate(type, d) {
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    var date = new Date(d.getFullYear(), d.getMonth(), 1);
                    date.setDate(1 - date.getDay());
                    return date;

                case DEF_CONF.TYPE.MONTH:
                case DEF_CONF.TYPE.HALF:
                    return new Date(d.getFullYear(), 0, d.getDate());

                case DEF_CONF.TYPE.YEAR:
                    var year = Math.floor((d.getFullYear() - 1) / 12) * 12 + 1;
                    return new Date(year, d.getMonth(), d.getDate());
            }
        };

        /**
         * カレンダーの次の日付へ移動する。
         * @param {string} type タイプ
         * @param {Date}   d    日付
         */
        function _moveNextDate(type, d) {
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    d.setDate(d.getDate() + 1);
                    return;

                case DEF_CONF.TYPE.MONTH:
                    d.setMonth(d.getMonth() + 1);
                    return;

                case DEF_CONF.TYPE.YEAR:
                    d.setFullYear(d.getFullYear() + 1);
                    return;

                case DEF_CONF.TYPE.HALF:
                    d.setMonth(d.getMonth() + 6);
                    return;
            }
        };

        /**
         * 現在の日付が範囲内か判定する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         * @param {Date}   min  最小日付
         * @param {Date}   max  最大日付
         * @returns 範囲内の場合はtrue、そうでない場合はfalse
         */
        function _isWithinRange(type, d, min, max) {
            var val = _convDateToVal(type, d),
                minVal = _convDateToVal(type, min),
                maxVal = _convDateToVal(type, max);
            return (minVal <= val && val <= maxVal);
        };

        /**
         * セルに追加するCSSクラスを取得する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         * @param {Date}   c    選択中の日付
         * @param {Date}   v    ビューの日付
         * @returns CSSクラス
         */
        function _getCellClass(type, d, c, v) {
            var val = _convDateToVal(type, d),
                currVal = _convDateToVal(type, c),
                cls = 'calendar-action';
            //選択中の場合
            if (val == currVal) {
                cls += ' calendar-cell-current';
            }
            //日カレンダーの場合
            if (type == DEF_CONF.TYPE.DAY) {
                //ビューの年月以外の場合
                if (d.getFullYear() != v.getFullYear()
                    || d.getMonth() != v.getMonth()) {
                    cls += ' calendar-cell-other-month';
                }
                //日曜の場合
                else if (d.getDay() == 0) {
                    cls += ' calendar-cell-holiday';
                }
                //土曜の場合
                else if (d.getDay() == 6) {
                    cls += ' calendar-cell-saturday';
                }
            }
            return cls;
        };

        /**
         * セルに表示する文字列を取得する。
         * @param {string} type タイプ
         * @param {Date}   d    現在の日付
         * @returns 表示値
         */
        function _getCellText(type, d) {
            switch (type) {
                case DEF_CONF.TYPE.DAY:
                    return d.getDate().toString();

                case DEF_CONF.TYPE.MONTH:
                    return DEF_CONF.TEXT.MONTH[d.getMonth()];

                case DEF_CONF.TYPE.YEAR:
                    return d.getFullYear().toString();

                case DEF_CONF.TYPE.HALF:
                    return DEF_CONF.TEXT.HALF[Math.floor(d.getMonth() / 6)];
            }
        };
    }());

    /* 関数
    ----------------------------------------------------------*/
    (function () {
        DatepickerClass.prototype.convValToDate = _convValToDate;
        DatepickerClass.prototype.convDateToVal = _convDateToVal;
        DatepickerClass.prototype.convDateToText = _convDateToText;
    }());


    //==============================================================================
    // 関数
    //==============================================================================
    /**
     * 値を日付に変換する。
     * @param {string} type タイプ
     * @param {string} val  値
     * @returns 日付
     */
    function _convValToDate(type, val) {
        if (!val) {
            return null;
        }
        var val1 = val.substr(0, 4),
            val2 = val.substr(4, 2),
            val3 = val.substr(6, 2),
            date = null;
        switch (type) {
            case DEF_CONF.TYPE.DAY:
                date = new Date(parseInt(val1), parseInt(val2) - 1, parseInt(val3));
                break;

            case DEF_CONF.TYPE.MONTH:
                date = new Date(parseInt(val1), parseInt(val2) - 1, 1);
                break;

            case DEF_CONF.TYPE.YEAR:
                date = new Date(parseInt(val1), 0, 1);
                break;

            case DEF_CONF.TYPE.HALF:
                date = new Date(parseInt(val1), (parseInt(val2.substr(0, 1)) - 1) * 6, 1);
                break;
        }
        return date;
    };

    /**
     * 日付を値に変換する。
     * @param {string} type タイプ
     * @param {Date}   date 日付
     * @returns 値
     */
    function _convDateToVal(type, date) {
        if (!date) {
            return null;
        }
        var val = null;
        switch (type) {
            case DEF_CONF.TYPE.DAY:
                val = date.getFullYear()
                    + ('0' + (date.getMonth() + 1)).slice(-2)
                    + ('0' + date.getDate()).slice(-2);
                break;

            case DEF_CONF.TYPE.MONTH:
                val = date.getFullYear()
                    + ('0' + (date.getMonth() + 1)).slice(-2);
                break;

            case DEF_CONF.TYPE.YEAR:
                val = date.getFullYear().toString();
                break;

            case DEF_CONF.TYPE.HALF:
                val = date.getFullYear()
                    + ((Math.floor(date.getMonth() / 6) + 1) + 'H');
                break;
        }
        return val;
    };

    /**
     * 日付を表示値に変換する。
     * @param {string} type タイプ
     * @param {Date}   date 日付
     * @returns 表示値
     */
    function _convDateToText(type, date) {
        if (!date) {
            return null;
        }
        var text = null;
        switch (type) {
            case DEF_CONF.TYPE.DAY:
                text = date.getFullYear() + '年'
                    + (' ' + (date.getMonth() + 1)).slice(-2) + '月'
                    + (' ' + date.getDate()).slice(-2) + '日'
                    + '（' + DEF_CONF.TEXT.DAYS[date.getDay()] + '）';
                break;

            case DEF_CONF.TYPE.MONTH:
                text = date.getFullYear() + '年'
                    + (' ' + (date.getMonth() + 1)).slice(-2) + '月';
                break;

            case DEF_CONF.TYPE.YEAR:
                text = date.getFullYear() + '年';
                break;

            case DEF_CONF.TYPE.HALF:
                text = date.getFullYear() + '年'
                    + DEF_CONF.TEXT.HALF[Math.floor(date.getMonth() / 6)];
                break;
        }
        return text;
    };

    /**
     * data-val属性値を値に反映する。
     * @param {HTMLInputElement} el 対象要素
     */
    function _reflectValue(el) {
        var $el = $(el),
            type = $el.attr(DEF_ATTR.TYPE);
        $el
            .val(_convDateToText(type, _convValToDate(type, $el.attr(DEF_ATTR.VAL))))
            .change();
    };

    //==============================================================================
    // イベント
    //==============================================================================
    /**
     * 対象要素 の 属性変更 イベントを処理する。
     * @param {MutationRecord[]} mutations 変更
     */
    function target_modified(mutations) {
        //console.group('[Event] datepicker.modified');
        var length = mutations.length;
        for (var i = 0; i < length; i++) {
            //値の反映
            _reflectValue(mutations[i].target);
        }
        //console.groupEnd();
    };

    /**
     * 対象要素 の Click、Focus イベントを処理する。
     * @param {Event} event イベント
     */
    function target_focus(event) {
        //console.group('[Event] datepicker.' + event.type);
        //ポップアップの表示
        global.Datepicker.show(event.target);
        //console.groupEnd();
    };

    /**
     * 対象要素 の Blur イベントを処理する。
     */
    function target_blur() {
        //console.group('[Event] datepicker.blur');
        //ポップアップの削除
        global.Datepicker.hide();
        //console.groupEnd();
    };

    /**
     * ポップアップ要素 の MouseDown イベントを処理する。
     */
    function popup_mousedown() {
        //console.group('[Event] datepicker-popup.mousedown');
        //次のポップアップ削除をキャンセル
        global.Datepicker.cancelHide();
        //console.groupEnd();
    };

    /**
     * アクション要素 の Click イベントを処理する。
     * @param {Event} event イベント
     */
    function action_click(event) {
        //console.group('[Event] calendar-action.click');
        //アクションの実行
        global.Datepicker.action(event.target);
        //console.groupEnd();
    };


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    return new DatepickerClass();
}(this));