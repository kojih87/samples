Site.Pdf = (function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* PDF.js設定
    ----------------------------------------------------------*/
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'refs/download/pdf.worker.min.js';
    pdfjsLib.cMapUrl = 'refs/download/cmaps/';

    /* 内部定数
    ----------------------------------------------------------*/
    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** 対象要素 */
        TARGET: '.pdf',
        /** ダウンロードボタン */
        DOWNLOAD: '.pdf-download'
    };

    /** HTML */
    const DEF_HTML = {
        /** 対象要素に追加する子要素 */
        CHILD: '<div>'
            + '<button class="pdf-download">ダウンロード</button>'
            + '</div>'
            + '<canvas></canvas>'
    };

    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    var SitePdfClass = function () {
        /**
         * 要素セレクタ毎に表示中のデータを格納する。
         */
        this._data = null;
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    (function () {
        SitePdfClass.prototype.initialize =
            /**
             * インスタンスを初期化する。
             */
            function () {
                //対象要素の設定
                $(DEF_SELECTOR.TARGET)
                    //イベントの登録
                    .delegate(DEF_SELECTOR.DOWNLOAD, 'click', download_click);

                //データの初期化
                this._data = {};
            };

        SitePdfClass.prototype.destroy =
            /**
             * インスタンスを破棄する。
             */
            function () {
                //対象要素の設定解除
                $(DEF_SELECTOR.TARGET)
                    //イベントの削除
                    .off()
                    //要素の削除
                    .empty();

                //データの削除
                for (var selector in this._data) {
                    this.setData(selector, null);
                }
                this._data = null;
            };
    }());

    /* PDF遷移
    ----------------------------------------------------------*/
    (function () {
        SitePdfClass.prototype.navigate =
            /**
             * 指定されたPDFファイルを表示する。
             * @param {string} selector 要素セレクタ
             * @param {string} path     PDFフォルダからの相対パス
             */
            function (selector, path) {
                /*----------*/global.logger.debug('Site.Pdf.navigate( %s, %s )', selector, path);
                //読み込み中
                global.Site.loading();

                //ドキュメントの取得
                var url = global.DEF.PDF.PREFIX + path;
                pdfjsLib.getDocument(url)
                    //成功した場合の処理(ドキュメント)
                    .then(function (pdf) {
                        try {
                            /*----------*/global.logger.group(url + ' (done1)', 'PDF');
                            //データの設定
                            global.Site.Pdf.setData(selector, pdf, path.split('/').pop());
                            //先頭ページの取得
                            return pdf.getPage(1);
                        } catch (ex) {
                            throw ex;
                        } finally {
                            /*----------*/global.logger.groupEnd();
                        }
                    })
                    //成功した場合の処理(先頭ページ)
                    .then(function (page) {
                        try {
                            /*----------*/global.logger.group(url + ' (done2)', 'PDF');
                            //対象要素の設定
                            var $container = $(selector).html(DEF_HTML.CHILD);
    
                            //キャンバスのサイズ調整
                            var canvas = $container.find('canvas')[0],
                                scale = $container.width() / page.getViewport(1).width,
                                viewport = page.getViewport(scale);
                            canvas.width = viewport.width;
                            canvas.height = viewport.height;
    
                            //読み込み中
                            global.Site.loading();
                            //キャンバスへ描画
                            page.render({
                                canvasContext: canvas.getContext('2d'),
                                viewport: viewport
                            }).then(function () {
                                //読み込み完了
                                global.Site.loaded();
                                canvas = null;
                            });
                        } catch (ex) {
                            throw ex;
                        } finally {
                            /*----------*/global.logger.groupEnd();
                        }
                    })

                    //失敗した場合の処理
                    .catch(function (ex) {
                        /*----------*/global.logger.group(url + ' (fail) ' + ex.message, 'PDF');
                        //データの設定
                        global.Site.Pdf.setData(selector, null);
                        //エラー表示
                        global.Site.setError('PDF_404', selector);
                        /*----------*/global.logger.groupEnd();
                    })

                    //常に実行する処理
                    .finally(function () {
                        /*----------*/global.logger.group(url + ' (always)', 'PDF');
                        //読み込み完了
                        global.Site.loaded();
                        /*----------*/global.logger.groupEnd();
                    });
            };

        SitePdfClass.prototype.setData =
            /**
             * 表示中のデータを設定する。
             * @param {string} selector 要素セレクタ
             * @param {any}    pdf      PDFオブジェクト
             * @param {string} name     ファイル名
             */
            function (selector, pdf, name) {
                //既に設定されている場合
                if (this._data[selector]) {
                    this._data[selector].pdf.cleanup();
                    this._data[selector].pdf.destroy();
                    this._data[selector].pdf = null;
                    this._data[selector] = null;
                }
                //PDFオブジェクトが指定された場合
                if (pdf != null) {
                    this._data[selector] = {
                        pdf: pdf,
                        name: name
                    };
                }
            };
    }());

    /* PDFダウンロード
    ----------------------------------------------------------*/
    (function () {
        SitePdfClass.prototype.download =
            /**
             * 表示中のPDFファイルをダウンロードする。
             * @param {string} selector 要素セレクタ
             */
            function (selector) {
                /*----------*/global.logger.debug('Site.Pdf.download( %s )', selector);
                //データの取得
                this._data[selector].pdf.getData().then(function (data) {
                    //保存
                    var blob = new Blob([data], { 'type': 'application/octet-stream' }),
                        name = global.Site.Pdf._data[selector].name;
                    if (window.navigator.msSaveOrOpenBlob) {
                        /*----------*/global.logger.debug('use window.navigator.msSaveOrOpenBlob');
                        window.navigator.msSaveOrOpenBlob(blob, name);
                    } else if (window.URL && window.URL.createObjectURL) {
                        /*----------*/global.logger.debug('use window.URL.createObjectURL');
                        var a = document.createElement('a');
                        a.download = name;
                        a.href = window.URL.createObjectURL(blob);
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        a = null;
                    }
                });
            };
    }());


    //==============================================================================
    // イベント
    //==============================================================================
    /**
     * ダウンロードボタン の Click イベントを処理する。
     * @param {Event} event イベント
     */
    function download_click(event) {
        /*----------*/global.logger.group('pdf-download.click');
        //PDFダウンロード
        global.Site.Pdf.download('#' + $(event.target).parents(DEF_SELECTOR.TARGET).attr('id'));
        /*----------*/global.logger.groupEnd();
    };


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    return new SitePdfClass();
}(this));