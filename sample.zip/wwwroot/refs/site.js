var Site = (function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* 内部定数
    ----------------------------------------------------------*/
    /** サイト設定 */
    const DEF_CONF = {
        /** ログ出力フラグ(デバッグ用) */
        LOG: false,

        /** ウィンドウタイトル */
        WIN_TITLE: {
            /** 一般 */
            USER: 'NW給電情報',
            /** 管理 */
            ADMIN: 'NW給電情報管理'
        },

        /** 管理箇所 */
        TEAM: '○○チーム',

        /** URL接頭辞 */
        URL_PREFIX: {
            /** メニューデータ */
            MENU: 'refs/menu/',
            /** 画面 */
            PAGE: 'pages/',
            /** コンテンツデータ(全NW社員向け) */
            DATA: 'data/',
            /** コンテンツデータ */
            DATA_SEC: 'security/data/',
            /** PDF */
            PDF: 'security/pdf/',
            /** WebAPI(管理向け) */
            API: 'api/'
        },

        /** カテゴリ毎の設定 */
        CATEGORY: {
            /** 実績(全NW社員向け) */
            'result_pub': { isAdmin: false, menuNo: 0 },
            /** 実績 */
            'result': { isAdmin: false, menuNo: 1 },
            /** 定期報告 */
            'report': { isAdmin: false, menuNo: 1 },
            /** 主管部管理 */
            'admin': { isAdmin: true, menuNo: 2 },
            /** NW中給管理 */
            'admin_nw': { isAdmin: true, menuNo: 3 }
        },

        /** メニューデータ */
        MENU_DATA: [
            //全NW社員向け
            'user_pub.json',
            //一部NW社員向け
            'user.json',
            //主管部向け
            'admin.json',
            //NW中給向け
            'admin_nw.json'
        ],

        /** 全NW社員向け */
        FILE_PUB: [
            'minute',
            'max_record',
            'power_of_month',
            'energy_of_month',
            'energy_of_year'
        ],

        /** 外部ライブラリ */
        LIBRARIES: {
            /** スタイル */
            STYLE: [
                //日付選択
                'refs/datepicker.css',
                //ファイルアップロード
                'refs/fileupload.css',
                //グリッド
                'refs/download/handsontable.min.css'
            ],
            /** スクリプト */
            SCRIPT: [
                //日付選択
                'refs/datepicker.js',
                //ファイルアップロード
                'refs/fileupload.js',
                //PDF
                'refs/download/pdf.min.js',
                'refs/site-pdf.js',
                //グラフ
                'refs/download/Chart.min.js',
                'refs/site-chart.js',
                //グリッド
                'refs/download/handsontable.min.js',
                'refs/site-grid.js'
            ]
        }
    };

    /** エラーメッセージ */
    const DEF_ERROR = {
        /** PDF表示エラー */
        PDF_404: 'PDFファイルが存在しません。',
        /** データ取得エラー(権限) */
        JSON_403: '権限',
        /** データ取得エラー */
        JSON_404: 'データの取得に失敗しました。<br />30分経過しても解消されない場合はシステム管理者に連絡してください。',
        /** 想定外エラー */
        DEFAULT: '想定外のエラーが発生しました。<br />システム管理者に連絡してください。'
    };

    /** HTML */
    const DEF_HTML = {
        /** メニュー表示切替 */
        MENU_SWITCH: '<a id="menu-switch" href="javascript:void(0)">'
            + '<svg viewbox="0 0 32 32">'
            + '<rect x="0" y="0" width="32" height="32" />'
            + '<g>'
            + '<line x1="7" y1="9" x2="25" y2="9" />'
            + '<line x1="7" y1="16" x2="25" y2="16" />'
            + '<line x1="7" y1="23" x2="25" y2="23" />'
            + '</g>'
            + '</svg>'
            + '</a>',
        /** 前ページ */
        PREV_PAGE: '<a href="javascript:void(0);" class="page-navi" data-add="1" style="visibility:hidden;">'
            + '<svg>'
            + '<polygon points="0,16 16,0 16,32"></polygon>'
            + '</svg>'
            + '</a>',
        /** 次ページ */
        NEXT_PAGE: '<a href="javascript:void(0);" class="page-navi" data-add="-1" style="visibility:hidden;">'
            + '<svg>'
            + '<polygon points="16,16 0,0 0,32"></polygon>'
            + '</svg>'
            + '</a>',
        /** ローディング */
        LOADING: '<div id="loading"><div><br /></div></div>'
    };

    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** メニュー表示切替 */
        MENU_SWITCH: '#menu-switch',
        /** メニュー */
        MENU: 'body > nav',
        /** ヘッダ */
        HEADER: 'body > main > header',
        /** コンテンツタイトル */
        TITLE: 'body > main > header > h1',

        //ページナビゲーション
        /** カレント */
        CURRENT: '#current',
        /** ページナビゲーション */
        PAGE_NAVI: '.page-navi',

        //画面遷移
        /** 画面スクリプト */
        SCRIPT: '#script',
        /** コンテンツ */
        CONTENTS: '#contents',

        /** ローディング */
        LOADING: '#loading'
    };

    /* 定数
    ----------------------------------------------------------*/
    global.DEF = {

        PDF: {
            PREFIX: '../../' + DEF_CONF.URL_PREFIX.PDF
        },
        CHART: {
            /** グラフタイプ */
            TYPE: {
                /** 線 */
                LINE: 'line',
                /** 棒 */
                BAR: 'bar'
            },
            /** X軸タイプ */
            X_AXIS_TYPE: {
                /**  */
                DAY_288: 'day288',
                /**  */
                DAY_048: 'day048',
                /**  */
                DAY_024: 'day024',
                /**  */
                MONTH: 'month',
                /**  */
                YEAR: 'year'
            },
    
            /** 積み上げ棒色リスト(10色まで想定) */
            BAR_RGB: [
                [255, 80, 80],
                [255, 148, 64],
                [252, 252, 32],
                [164, 252, 24],
                [80, 255, 80],
                [64, 228, 255],
                [64, 164, 255],
                [80, 80, 255],
                [164, 128, 255],
                [255, 128, 255]
            ]
        }
    };

    /* コンソールログ出力(デバッグ用)
    ----------------------------------------------------------*/
    global.logger = (function (flag) {
        /**
         * ログ出力停止時のダミー処理を定義する。
         */
        function _dummy() { };

        /**
         * コンソールのグループを開始する。
         * @param {string} name     イベント名
         * @param {string} category カテゴリ(省略可)
         */
        function _group(name, category) {
            console.group('[' + (category || 'Event') + '] ' + name);
        };

        /**
         * コンソールのグループを終了する。
         */
        function _groupEnd() {
            console.groupEnd();
        };

        return {
            group: flag ? _group : _dummy,
            groupEnd: flag ? _groupEnd : _dummy,
            debug: flag ? console.log : _dummy
        };
    }(DEF_CONF.LOG && console));


    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    var SiteClass = function () {
        /**
         * 管理フラグを格納する。
         */
        this._isAdmin = false;

        /**
         * コンテンツデータを格納する。
         * @type {JSON}
         */
        this._contentsData = null;

        /**
         * 現在のページ番号を格納する。
         * @type {number}
         */
        this._pageIndex = 0;

        /**
         * 画面設定を格納する。
         */
        this.config = null;

        /**
         * 各画面で実装するコールバックを格納する。
         */
        this.callbacks = {
            configure:
                /**
                 * 初期化時に画面設定を取得する。
                 * @returns 画面設定
                 */
                function () {
                    /*----------*/global.logger.debug('※※※未実装※※※ Site.callbacks.configure()');
                    return {};
                },

            initializeScreen:
                /**
                 * コンテンツ遷移後に画面を初期化する。
                 */
                function () {
                    /*----------*/global.logger.debug('※※※未実装※※※ Site.callbacks.initializeScreen()');
                },

            updateScreen:
                /**
                 * ページ遷移後に画面を更新する。
                 * @param {JSON}   data  コンテンツデータ
                 * @param {number} index 現在のページ番号
                 */
                function (data, index) {
                    /*----------*/global.logger.debug('※※※未実装※※※ Site.callbacks.updateScreen(data, index)');
                }
        };
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    (function () {
        SiteClass.prototype.initialize =
            /**
             * インスタンスを初期化する。
             * @param {boolean} isFirst 初回フラグ
             */
            function (isFirst) {
                /*----------*/global.logger.debug('==================== initialize ====================');

                //初回の場合
                if (isFirst) {
                    //外部ライブラリの読み込み
                    _loadLibraries();
                    //画面設定の取得
                    this.config = this.callbacks.configure();
                    //共通部品の構築
                    _buildCommonParts();
                }
                //2回目以降の場合
                else {
                    //画面設定の取得
                    this.config = this.callbacks.configure();
                }

                //外部ライブラリの初期化
                _initializeLibraries();
                //コンテンツの設定
                _setupContents();
            };

        SiteClass.prototype.destroy =
            /**
             * インスタンスを破棄する。
             */
            function () {
                /*----------*/global.logger.debug('====================  destroy   ====================');
                /*----------*/global.logger.debug('◇◇◇ destroy libraries ◇◇◇');
                //外部ライブラリの破棄
                global.Datepicker.destroy();
                global.Fileupload.destroy();
                this.Pdf.destroy();
                this.Chart.destroy();
                this.Grid.destroy();
            };

        /**
         * 外部ライブラリを読み込む。
         */
        function _loadLibraries() {
            /*----------*/global.logger.debug('◇◇◇ load libraries ◇◇◇');
            //スタイルの読み込み
            $('link').last().after(
                DEF_CONF.LIBRARIES.STYLE.map(function (item) {
                    return '<link href="' + item + '" rel="stylesheet" />';
                }).join('')
            );

            //スクリプトの読み込み
            $('script').last().before(
                DEF_CONF.LIBRARIES.SCRIPT.map(function (item) {
                    return '<script src="' + item + '"></script>';
                }).join('')
            );
        }

        /**
         * 共通部品を構築する。
         */
        function _buildCommonParts() {
            /*----------*/global.logger.debug('◇◇◇ build common parts ◇◇◇');
            //現在のURLからオプションの取得
            var opt = (function () {
                var ary = location.href.split('/'),
                    dir = ary[ary.length - 2].toLowerCase(),
                    conf = DEF_CONF.CATEGORY[dir];
                return {
                    title: (conf.isAdmin ? DEF_CONF.WIN_TITLE.ADMIN : DEF_CONF.WIN_TITLE.USER),
                    team: (conf.isAdmin ? '' : '<span>（' + DEF_CONF.TEAM + '）</span>'),
                    menuUrl: DEF_CONF.URL_PREFIX.MENU + DEF_CONF.MENU_DATA[conf.menuNo],
                    isAdmin: conf.isAdmin
                };
            }());

            //管理フラグの設定
            Site._isAdmin = opt.isAdmin;

            //ウィンドウタイトルの設定
            document.title = opt.title;

            //コンテンツヘッダの構築
            $(DEF_SELECTOR.HEADER).html('<h1></h1>' + opt.team);

            //メニューの構築
            global.Site.getJson(opt.menuUrl, function (json) {
                var html = json.map(function (item) {
                    //カテゴリブロック
                    return '<li><span>' + item.category + '</span><ul>'
                        + item.menus.map(function (menu) {
                            //メニューリンク
                            return '<li>' + menu.label.link(
                                DEF_CONF.URL_PREFIX.PAGE + menu.link) + '</li>';
                        }).join('')
                        + '</ul></li>';
                }).join('');

                //メニュー部
                $(DEF_SELECTOR.MENU)
                    //要素の追加
                    .append(DEF_HTML.MENU_SWITCH)
                    .append('<ul>' + html + '</ul>')
                    //イベントの登録
                    .delegate('li > a', 'click', menu_click);
                //メニュー表示切替
                $(DEF_SELECTOR.MENU_SWITCH)
                    //イベントの登録
                    .on('click', menuSwitch_click);
            });
        };

        /**
         * 外部ライブラリを初期化する。
         */
        function _initializeLibraries() {
            /*----------*/global.logger.debug('◇◇◇ initialize libraries ◇◇◇');
            global.Datepicker.initialize();
            global.Fileupload.initialize();
            global.Site.Pdf.initialize();
            global.Site.Chart.initialize();
            global.Site.Grid.initialize();
        }

        /**
         * コンテンツを設定する。
         */
        function _setupContents() {
            /*----------*/global.logger.debug('◇◇◇ setup contents ◇◇◇');
            //画面設定の取得
            var siteConfig = global.Site.config,
                title = siteConfig.title,
                pageNavi = siteConfig.pageNavi,
                data = siteConfig.data,
                isAdmin = global.Site._isAdmin;

            //コンテンツタイトルの設定
            $(DEF_SELECTOR.TITLE).text(title);

            //ページナビゲーションの設定
            if (pageNavi) {
                //前ページ・次ページ要素の追加
                $(DEF_SELECTOR.CURRENT)
                    .before($(DEF_HTML.PREV_PAGE).append(pageNavi.prev))
                    .after($(DEF_HTML.NEXT_PAGE).prepend(pageNavi.next));
                //イベント登録
                $(DEF_SELECTOR.PAGE_NAVI).on('click', pageNavi_click);
            }

            //画面の初期化
            global.Site.callbacks.initializeScreen();

            //コンテンツの設定
            if (data) {
                //コンテンツデータの取得
                var dataPrefix = isAdmin ? DEF_CONF.URL_PREFIX.API
                    : (function (file) {
                        return DEF_CONF.FILE_PUB.indexOf(file) < 0
                            ? DEF_CONF.URL_PREFIX.DATA_SEC
                            : DEF_CONF.URL_PREFIX.DATA;
                    }(location.href.split('/').pop().split('.').shift()));
                global.Site.getJson(dataPrefix + data, function (json) {
                    //先頭ページへ遷移
                    global.Site.navigatePage(0, json);
                });
            } else {
                //先頭ページへ遷移
                global.Site.navigatePage(0);
            }
        };
    }());

    /* ローディング
    ----------------------------------------------------------*/
    (function () {
        //読み込み中件数
        var _count = 0;

        SiteClass.prototype.loading =
            /**
             * 読み込み中の画面表示に切り替える。
             */
            function () {
                //既に読み込み中の場合
                if (0 < _count++) {
                    //処理を中断
                    /*----------*/global.logger.debug('.....loading (+)', _count);
                    return;
                }
                /*----------*/global.logger.debug('.....loading start');

                //ローディング要素の表示
                var $loading = $(DEF_SELECTOR.LOADING);
                //存在しない場合
                if ($loading.length == 0) {
                    $(DEF_SELECTOR.CONTENTS).after(DEF_HTML.LOADING);
                }
                //存在する場合
                else {
                    $loading.show();
                }
            };

        SiteClass.prototype.loaded =
            /**
             * 全ての読み込みが完了した場合、読み込み中の画面表示を解除する。
             */
            function () {
                //完了していない場合
                if (1 < _count) {
                    //処理を中断
                    _count--;
                    /*----------*/global.logger.debug('.....loading (-)', _count);
                    return;
                }
                /*----------*/global.logger.debug('.....loading end');

                //ローディング要素の表示解除
                $(DEF_SELECTOR.LOADING)
                    .delay(100)
                    .fadeOut(100, function () {
                        _count--;
                    });
            };

        SiteClass.prototype.isLoading =
            /**
             * 読み込み中か判定する。
             * @returns 読み込み中の場合はtrue、そうでない場合はfalse
             */
            function () {
                return (0 < _count);
            };
    }());

    /* 画面遷移
    ----------------------------------------------------------*/
    (function () {
        SiteClass.prototype.navigateUrl =
            /**
             * 指定されたコンテンツへ遷移する。(メニューリンク)
             * @param {string} url コンテンツのURL
             */
            function (url) {
                /*----------*/global.logger.debug('navigateUrl:', url);
                //ロケーションの書き換え(アドレスバー)
                history.replaceState(null, null, url);

                //コンテンツ遷移
                this.getHtml(url, function (html) {
                    //破棄
                    global.Site.destroy();

                    var $html = $(html);
                    //画面スクリプトの差し替え
                    $(DEF_SELECTOR.SCRIPT)
                        .replaceWith($html.filter(DEF_SELECTOR.SCRIPT));
                    //コンテンツの差し替え
                    $(DEF_SELECTOR.CONTENTS)
                        .replaceWith($html.find(DEF_SELECTOR.CONTENTS));

                    //初期化
                    global.Site.initialize();
                });
            };

        SiteClass.prototype.navigatePage =
            /**
             * 指定されたページへ遷移する。(ページナビゲーション等)
             * @param {number} index ページ番号(省略可)
             * @param {JSON}   data  コンテンツデータ(省略可)
             */
            function (index, data) {
                /*----------*/global.logger.debug('navigatePage:', index);
                //読み込み中
                this.loading();
                try {
                    //画面設定の取得
                    var pageNavi = this.config.pageNavi;

                    //ページ番号の設定
                    if (pageNavi) {
                        this._pageIndex = (function (i, min, max) {
                            //範囲内に設定
                            i = (i < min ? min : max < i ? max : i);
                            //ナビゲーションの表示切替
                            var $navi = $(DEF_SELECTOR.PAGE_NAVI);
                            $navi.eq(0).css('visibility', i == max ? 'hidden' : 'visible');
                            $navi.eq(1).css('visibility', i == min ? 'hidden' : 'visible');
                            return i;
                        }(index, 0, pageNavi.max - 1));
                    } else {
                        this._pageIndex = index;
                    }

                    //コンテンツデータの設定
                    if (data) {
                        this._contentsData = data;
                    }

                    //画面の更新
                    this.callbacks.updateScreen(this._contentsData, this._pageIndex);

                } catch (ex) {
                    /*----------*/global.logger.debug(ex.message);
                    this.setError();
                }
                //読み込み完了
                this.loaded();
            };

        SiteClass.prototype.setError =
            /**
             * エラーメッセージを表示する。
             * @param {string} errCode  エラーコード(省略可)
             * @param {string} selector メッセージを表示する要素セレクタ(省略可)
             */
            function (errCode, selector) {
                //要素の設定(省略時、コンテンツ)
                $(selector || DEF_SELECTOR.CONTENTS)
                    //CSSクラスの追加
                    .addClass('error')
                    //メッセージの設定(未定義の場合、想定外エラー)
                    .html(DEF_ERROR[errCode] || DEF_ERROR.DEFAULT);
            };
    }());

    /* HTTP通信
    ----------------------------------------------------------*/
    (function () {
        SiteClass.prototype.getHtml =
            /**
             * 非同期でHTTP通信を行う。(get html)
             * @param {string}   url      要求するURL
             * @param {Function} callback 成功した応答を処理するコールバック
             */
            function (url, callback) {
                _ajax('get', url, null, 'HTML', callback);
            };

        SiteClass.prototype.getJson =
            /**
             * 非同期でHTTP通信を行う。(get json)
             * @param {string}   url      要求するURL
             * @param {Function} callback 成功した応答を処理するコールバック
             */
            function (url, callback) {
                _ajax('get', url, null, 'JSON', callback);
            };

        SiteClass.prototype.post =
            /**
             * 非同期でHTTP通信を行う。(post)
             * @param {string}   url      要求するURL
             * @param {JSON}     params   要求するパラメータ
             * @param {Function} callback 成功した応答を処理するコールバック
             */
            function (url, params, callback) {
                _ajax('post', url, params, 'JSON', callback);
            };

        /**
         * 非同期でHTTP通信を行う。
         * @param {string}   method   メソッド
         * @param {string}   url      要求するURL
         * @param {JSON}     params   要求するパラメータ
         * @param {string}   dataType 応答のデータタイプ
         * @param {Function} callback 成功した応答を処理するコールバック
         */
        function _ajax(method, url, params, dataType, callback) {
            /*----------*/global.logger.debug('★Ajax: %s', url);
            //読み込み中
            global.Site.loading();

            //HTTP要求
            $.ajax({
                type: method,
                url: url,
                data: params,
                dataType: dataType,
                cache: false,
                async: true
            })
                //成功した場合の処理
                .then(function (data, textStatus, jqXHR) {
                    /*----------*/global.logger.group(url + ' (done)', 'Ajax');
                    //コールバックの呼び出し
                    callback(data);
                    /*----------*/global.logger.groupEnd();
                })
                //失敗した場合の処理
                .catch(function (jqXHR, textStatus, errorThrown) {
                    /*----------*/global.logger.group(url + ' (fail) ' + jqXHR.status, 'Ajax');
                    //エラー表示
                    global.Site.setError(dataType.toUpperCase() + '_' + jqXHR.status);
                    /*----------*/global.logger.groupEnd();
                })
                //常に実行する処理
                .then(function () {
                    /*----------*/global.logger.group(url + ' (always)', 'Ajax');
                    //読み込み完了
                    global.Site.loaded();
                    /*----------*/global.logger.groupEnd();
                });
        };
    }());

    /* 関数
    ----------------------------------------------------------*/
    (function () {
        //数値変換オブジェクト
        var _numFormat = new Intl.NumberFormat('ja-JP');

        SiteClass.prototype.concatArray =
            /**
             * 2つの配列を連結する。
             * @param {Array} ary1 配列1
             * @param {Array} ary2 配列2
             * @returns 連結した配列
             */
            function (ary1, ary2) {
                var ret = ary1.slice();
                ret.push(ary2);
                return ret;
            };

        SiteClass.prototype.formatNumber =
            /**
             * 数値をカンマ区切りに整形する。
             * @param {number} val 数値
             * @returns 整形した文字列
             */
            function (val) {
                return _numFormat.format(val);
            };

        SiteClass.prototype.formatDate =
            /**
             * 日付を表す文字列を表示値に整形する。
             * @param {string}  val     値(yyyy|yyyyMM|yyyyMMdd|yyyyMMddHH)
             * @param {boolean} isShort 年を除去する場合はtrue(省略可)
             * @returns 整形した日付
             */
            function (val, isShort) {
                //値を表示値に変換
                var date,
                    text;
                if(typeof date == 'Date') {
                    date = val;
                    text = global.Datepicker.convDateToText('day', date);
                } else {
                    switch (val.length) {
                        case 4:
                            date = global.Datepicker.convValToDate('year', val);
                            text = global.Datepicker.convDateToText('year', date);
                            break;
    
                        case 6:
                            date = global.Datepicker.convValToDate('month', val);
                            text = global.Datepicker.convDateToText('month', date);
                            break;
    
                        case 8:
                            date = global.Datepicker.convValToDate('day', val);
                            text = global.Datepicker.convDateToText('day', date);
                            break;
    
                        case 10:
                            date = global.Datepicker.convValToDate('day', val);
                            text = global.Datepicker.convDateToText('day', date)
                                + (' ' + parseInt(val.substr(8))).slice(-2) + '時';
                            break;
                    }
                }
                //短い場合
                if(isShort) {
                    //年を除去
                    text = text.substr(5);
                }
                return text;
            };

        SiteClass.prototype.formatTime =
            /**
             * 時分を表示値に整形する。
             * @param {number} hour   年
             * @param {number} minute 分(省略可)
             * @returns 整形した時刻
             */
            function (hour, minute) {
                var text = (' ' + hour).slice(-2) + '時';
                if(minute != null) {
                    text += (' ' + minute).slice(-2) + '分';
                }
                return text;
            };

        SiteClass.prototype.convValToDate =
            /**
             * 値を日付に変換する。
             * @param {string} type タイプ
             * @param {string} val  値
             * @returns 日付
             */
            function (type, val) {
                return global.Datepicker.convValToDate(type, val);
            };
    }());


    //==============================================================================
    // イベント
    //==============================================================================
    /**
     * メニュー表示切替要素 の click イベントを処理する。
     */
    function menuSwitch_click() {
        /*----------*/global.logger.group('menu-switch.click');
        //メニュー表示切替
        $('body').toggleClass('menu-hide');
        //グラフのリサイズ
        global.Site.Chart.resize();
        /*----------*/global.logger.groupEnd();
    };

    /**
     * メニューリンク要素 の click イベントを処理する。
     * @param {Event} event イベント
     * @returns 画面遷移を無効にするためfalse
     */
    function menu_click(event) {
        /*----------*/global.logger.group('menu.click');
        //読み込み中ではない場合
        if (Site.isLoading() == false) {
            //コンテンツ遷移
            Site.navigateUrl($(event.target).attr('href'));
        }
        /*----------*/global.logger.groupEnd();
        return false;
    };

    /**
     * ページナビゲーション要素 の click イベントを処理する。
     * @param {Event} event イベント
     */
    function pageNavi_click(event) {
        /*----------*/global.logger.group('page-navi.click');
        //読み込み中ではない場合
        if (Site.isLoading() == false) {
            //ページ遷移
            Site.navigatePage(Site._pageIndex + parseInt($(event.target).attr('data-add')));
        }
        /*----------*/global.logger.groupEnd();
    };


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    return new SiteClass();
}(this));

//document.DOMContentLoaded
document.addEventListener('DOMContentLoaded', function () {
    /*----------*/logger.group('document.DOMContentLoaded');
    //読み込み中
    Site.loading();
    //初期化
    Site.initialize(true);
    /*----------*/logger.groupEnd();
}, false);

//window.load
window.addEventListener('load', function () {
    /*----------*/logger.group('window.load');
    //読み込み完了
    Site.loaded();
    /*----------*/logger.groupEnd();
}, false);

//window.unload
window.addEventListener('unload', function () {
    /*----------*/logger.group('window.unload');
    //破棄
    Site.destroy();
    /*----------*/logger.groupEnd();
    Site = null;
}, false);