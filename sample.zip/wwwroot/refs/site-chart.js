Site.Chart = (function (global) {
    'use strict';
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* Chart.js設定
    ----------------------------------------------------------*/
    //レスポンシブ
    Chart.defaults.global.responsive = true;
    //アニメーション
    Chart.defaults.global.animation = false;
    //余白
    Chart.defaults.global.layout.padding.top = 5;
    Chart.defaults.global.layout.padding.bottom = 10;
    Chart.defaults.global.layout.padding.left = 20;
    Chart.defaults.global.layout.padding.right = 20;
    //フォント
    Chart.defaults.global.defaultFontFamily = 'Consolas, Meiryo';
    Chart.defaults.global.defaultFontSize = 14;
    Chart.defaults.global.legend.labels.fontSize = 15;
    Chart.defaults.global.tooltips.titleFontSize = 18;
    Chart.defaults.global.tooltips.bodyFontSize = 18;
    //色
    Chart.defaults.global.defaultColor = 'rgba(0,0,0,0)';
    Chart.defaults.global.defaultFontColor = '#333333';
    //凡例
    Chart.defaults.global.legend.fullWidth = false;
    Chart.defaults.global.legend.labels.boxWidth = 24;
    Chart.defaults.global.legend.labels.padding = 14;
    //ツールチップ
    Chart.defaults.global.hover.intersect = false;
    Chart.defaults.global.hover.mode = 'index';
    Chart.defaults.global.tooltips.intersect = false;
    Chart.defaults.global.tooltips.mode = 'index';
    Chart.defaults.global.tooltips.position = 'nearest';
    //折れ線
    Chart.defaults.global.elements.line.borderWidth = 3;
    Chart.defaults.global.elements.line.fill = false;
    Chart.defaults.global.elements.line.tension = 0;
    Chart.defaults.global.elements.point.radius = 0;

    /* 内部定数
    ----------------------------------------------------------*/
    const DEF_CONF = {
        /** X軸ID */
        X_AXIS_ID: {
            /** メイン */
            MAIN: 'x-axis',
            /** サブ(軸表示用) */
            SUB: 'x-axis-display'
        },
        /** Y軸ID */
        Y_AXIS_ID: {
            /** 主軸 */
            MAIN: 'y-axis-main',
            /** 主軸(積み上げ) */
            MAIN_STACK: 'y-axis-main-stack',
            /** 気温軸 */
            SUB: 'y-axis-sub'
        }
    };

    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** 対象要素 */
        TARGET: '.chart'
    };

    /** HTML */
    const DEF_HTML = {
        /** 子要素 */
        CHILD: '<canvas></canvas>'
    };


    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを初期化する。
     * (コンストラクタ)
     */
    var SiteChartClass = function () {
        /**
         * 要素セレクタ毎にグラフ操作オブジェクトを格納する。
         */
        this._chart = null;
    };

    /* 初期化・破棄
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype.initialize =
            /**
             * インスタンスを初期化する。
             */
            function () {
                //対象要素の設定
                $(DEF_SELECTOR.TARGET).html(DEF_HTML.CHILD);

                //オブジェクトの生成
                this._chart = {};
            };

        SiteChartClass.prototype.destroy =
            /**
             * インスタンスを破棄する。
             */
            function () {
                //対象要素の設定解除
                $(DEF_SELECTOR.TARGET).empty();

                //オブジェクトの削除
                for (var selector in this._chart) {
                    this._chart[selector].destroy();
                    this._chart[selector] = null;
                }
                this._chart = null;
            };
    }());

    /* グラフ操作オブジェクト
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype._getChart =
            /**
             * グラフ操作オブジェクトを取得する。
             * @param {string} selector 要素セレクタ
             */
            function (selector) {
                //オブジェクトが存在しない場合
                if (!this._chart[selector]) {
                    //オブジェクトの生成
                    var conf = global.Site.config.chart[selector];
                    this._chart[selector] = new Chart(
                        //コンテキスト
                        $(selector).find('canvas')[0].getContext('2d'),
                        //オプション
                        {
                            //タイプ
                            type: 'bar',
                            data: {
                                //データセット
                                datasets: this._createDatasets(conf)
                            },
                            options: {
                                //軸
                                scales: {
                                    //X軸
                                    xAxes: this._createXAxes(conf),
                                    //Y軸
                                    yAxes: this._createYAxes(conf)
                                },
                                //ツールチップ
                                tooltips: {
                                    callbacks: {
                                        label: function(tooltipItems, data) {
                                            var maxLength = (function () {
                                                var length = data.datasets.length,
                                                    max = 0;
                                                for (var i = 0; i < length; i++) {
                                                    if(data.datasets[i].label == null) {
                                                        break;
                                                    }
                                                    var wk = data.datasets[i].label.length;
                                                    if (max < wk) {
                                                        max = wk;
                                                    }
                                                }
                                                return max;
                                            }());
                                            var label = (data.datasets[tooltipItems.datasetIndex].label + '　'.repeat(maxLength)).substr(0, maxLength),
                                                value = (' '.repeat(6) + global.Site.formatNumber(tooltipItems.yLabel)).slice(-6);
                                            return label + '：' + value;
                                        }
                                    }
                                },
                                //凡例
                                legend: {
                                    labels: {
                                        usePointStyle: true,
                                        filter: function (legendItem, data) {
                                            //ラベルがnullの場合は非表示
                                            return legendItem.text != null;
                                        },
                                        generateLabels: function (chart) {
                                            //カスタマイズ
                                            return chart.data.datasets.map(function (dataset, i) {
                                                var pointStyle;
                                                switch(dataset.type) {
                                                    case global.DEF.CHART.TYPE.LINE:
                                                        pointStyle = 'line';
                                                        break;

                                                    case global.DEF.CHART.TYPE.BAR:
                                                        pointStyle = 'rect';
                                                        break;
                                                }
                                                return {
                                                    text: dataset.label,
                                                    fillStyle: dataset.backgroundColor,
                                                    hidden: !chart.isDatasetVisible(i),
                                                    lineCap: dataset.borderCapStyle,
                                                    lineDash: dataset.borderDash,
                                                    lineDashOffset: dataset.borderDashOffset,
                                                    lineJoin: dataset.borderJoinStyle,
                                                    lineWidth: dataset.borderWidth,
                                                    strokeStyle: dataset.borderColor,
                                                    pointStyle: pointStyle,
                                                    datasetIndex: i
                                                };
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    );
                }
                return this._chart[selector];
            };
    }());

    /* X軸
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype._createXAxes =
            /**
             * X軸を生成する。
             * @param {any} conf グラフ設定
             * @returns X軸
             */
            function (conf) {
                var xAxis = {
                    id: DEF_CONF.X_AXIS_ID.MAIN,
                    gridLines: {

                    },
                    scaleLabel: false,
                    ticks: {
                        autoSkip: true,
                        maxRotation: 0,
                    }
                };
                switch (conf.xAxisType) {
                    case global.DEF.CHART.X_AXIS_TYPE.DAY_288:
                        return [
                            _createXAxis(DEF_CONF.X_AXIS_ID.MAIN, _createXAxisTimeLabels(5), false, false),
                            _createXAxis(DEF_CONF.X_AXIS_ID.SUB, _createXAxisTimeLabels(60, true), true, false)
                        ];

                    case global.DEF.CHART.X_AXIS_TYPE.DAY_048:
                        return [
                            _createXAxis(DEF_CONF.X_AXIS_ID.MAIN, _createXAxisTimeLabels(30), false, false),
                            _createXAxis(DEF_CONF.X_AXIS_ID.SUB, _createXAxisTimeLabels(60, true), true, false)
                        ];

                    case global.DEF.CHART.X_AXIS_TYPE.DAY_024:
                        return [
                            _createXAxis(DEF_CONF.X_AXIS_ID.MAIN, _createXAxisTimeLabels(60), true, false)
                        ];

                    case global.DEF.CHART.X_AXIS_TYPE.MONTH:
                    case global.DEF.CHART.X_AXIS_TYPE.YEAR:
                        return [
                            _createXAxis(DEF_CONF.X_AXIS_ID.MAIN, null, false, false),
                            _createXAxis(DEF_CONF.X_AXIS_ID.SUB, null, true, true)
                        ];
                }
            };

        SiteChartClass.prototype._createXAxisDateLabels =
            /**
             * X軸ラベルを生成する。(日付)
             * @param {number} year  年
             * @param {number} month 月(1～12)
             * @param {number} range 範囲
             * @returns X軸ラベル
             */
            function (year, month, range) {
                var d = new Date(year, month - 1, 1),
                    max = new Date(year, month + range, 1),
                    labels = [],
                    i = 0;
                while (d < max) {
                    labels[i++] = (' ' + (d.getMonth() + 1)).slice(-2) + '月'
                        + (' ' + d.getDate()).slice(-2) + '日';
                    d.setDate(d.getDate() + 1);
                }
                return labels;
            };

        /**
         * X軸を生成する。
         * @param {string}   id         X軸ID
         * @param {string[]} labels     X軸ラベル
         * @param {boolean}  isDisplay  表示用の場合はtrue、そうでない場合はfalse
         * @param {boolean}  isAutoSkip 間引く場合はtrue、そうでない場合はfalse
         * @returns X軸
         */
        function _createXAxis(id, labels, isDisplay, isAutoSkip) {
            var labelOffset = (labels && labels[0] == '') ? -20 : 0;
            return {
                display: isDisplay,
                stacked: true,
                id: id,
                labels: labels,
                ticks: {
                    autoSkip: isAutoSkip,
                    maxRotation: 0,
                    labelOffset: labelOffset
                }
            };
        };

        /**
         * X軸ラベルを生成する。(時間)
         * @param {number}  step    分単位の間隔(5|30|60)
         * @param {boolean} isSpace 先頭を空にする場合はtrue(省略可)
         * @returns X軸ラベル
         */
        function _createXAxisTimeLabels(step, isSpace) {
            var isHourOnly = (step == 60),
                labels = [],
                i = 0;
            for (var hour = 0; hour < 24; hour++) {
                var hourLabel = (' ' + hour).slice(-2) + '時';
                if (isHourOnly) {
                    labels[i++] = hourLabel;
                }
                else {
                    for (var minute = 0; minute < 60; minute += step) {
                        labels[i++] = hourLabel + (' ' + minute).slice(-2) + '分';
                    }
                }
            }
            labels[i++] = isHourOnly ? '24時' : '24時 0分';
            if (isSpace) {
                labels[0] = '';
            } else {
                labels.shift();
            }
            return labels;
        };
    }());

    /* Y軸
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype._createYAxes =
            /**
             * Y軸を生成する。
             * @param {any} conf グラフ設定
             * @returns Y軸
             */
            function (conf) {
                var min = conf.yAxis.min,
                    step = conf.yAxis.step,
                    count = conf.yAxis.count,
                    unit = '(' + conf.yAxis.unit + ')',
                    max = min + (step * count),
                    yAxes = [],
                    i = 0;

                //主軸
                yAxes[i++] = {
                    id: DEF_CONF.Y_AXIS_ID.MAIN,
                    scaleLabel: {

                    },
                    ticks: {
                        min: min,
                        max: max,
                        callback: function (label, index, labels) {
                            if (0 < index) {
                                return global.Site.formatNumber(parseInt(label));
                            }
                            return [unit, global.Site.formatNumber(parseInt(label)), ''];
                        }
                    }
                };

                //主軸(積み上げ)
                yAxes[i++] = {
                    id: DEF_CONF.Y_AXIS_ID.MAIN_STACK,
                    display: false,
                    stacked: true,
                    ticks: {
                        min: min,
                        max: max
                    }
                };

                //気温軸
                yAxes[i++] = (function () {
                    //気温軸データが存在チェック
                    var hasTemperature = (0 <= conf.datasets.map(function (dsConf) {
                        return dsConf.isTemperature;
                    }).indexOf(true));
                    return {
                        id: DEF_CONF.Y_AXIS_ID.SUB,
                        position: 'right',
                        gridLines: {
                            display: false
                        },
                        scaleLabel: {
                            display: false
                        },
                        ticks: {
                            display: hasTemperature,
                            min: 0,
                            max: 10 * conf.yAxis.count,
                            stepSize: 5,
                            callback: function (value, index, values) {
                                var n = Math.floor(values.length / 3);
                                if (index < n) {
                                    return '';
                                } else if (index == n) {
                                    return ['(℃)', value, ''];
                                }
                                return value;
                            }
                        }
                    };
                }());

                return yAxes;
            };
    }());

    /* データセット
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype._createDatasets =
            /**
             * データセットを生成する。
             * @param {any} conf サイト設定
             * @returns データセット
             */
            function (conf) {
                return conf.datasets.map(function (dsConf) {
                    return _createDataset(dsConf);
                });
            };

        /**
         * データセットを生成する。
         * @param {any} dsConf データセット設定
         * @returns データセット
         */
        function _createDataset(dsConf) {
            var rgb = dsConf.rgb.join(',');
            switch (dsConf.type) {
                //積み上げ棒
                case global.DEF.CHART.TYPE.BAR:
                    return {
                        yAxisID: DEF_CONF.Y_AXIS_ID.MAIN_STACK,
                        type: 'bar',
                        label: dsConf.label,
                        stacked: true,
                        borderWidth: 0.5,
                        borderColor: 'rgba(0,0,0,1)',
                        backgroundColor: 'rgba(' + rgb + ',1)'
                    };

                //折れ線
                case global.DEF.CHART.TYPE.LINE:
                    return {
                        yAxisID: dsConf.isTemperature ? DEF_CONF.Y_AXIS_ID.SUB : DEF_CONF.Y_AXIS_ID.MAIN,
                        type: 'line',
                        label: dsConf.label,
                        borderColor: 'rgba(' + rgb + ',1)',
                        backgroundColor: 'rgba(' + rgb + ',1)',
                        fill: false,
                        //破線
                        borderDash: dsConf.isDash ? [6, 3] : [],
                        //階段
                        steppedLine: dsConf.isStep ? 'middle' : false,
                        //点
                        radius: dsConf.isPoint ? 4 : 0,
                        pointStyle: 'rectRot',
                        pointHoverRadius: 4,
                        pointBorderWidth: 0.3,
                        pointBorderColor: 'rgba(0,0,0,1)'
                    };
            }
        };
    }());

    /* グラフ操作
    ----------------------------------------------------------*/
    (function () {
        SiteChartClass.prototype.update =
            /**
             * グラフを更新する。
             * @param {string} selector 要素セレクタ
             * @param {any}    info     更新情報
             */
            function (selector, info) {
                var conf = global.Site.config.chart[selector],
                    chart = this._getChart(selector),
                    datasetsLength = chart.data.datasets.length,
                    infoLength = info.data.length,
                    hasTemperature = false,
                    min = 50;

                //データの更新
                for (var i = 0; i < datasetsLength; i++) {
                    if (i < infoLength) {
                        chart.data.datasets[i].hidden = false;
                        chart.data.datasets[i].data = info.data[i].values;
                        if (info.data[i].label) {
                            chart.data.datasets[i].label = info.data[i].label;
                        }
                        //気温データの場合
                        if (conf.datasets[i].isTemperature) {
                            var length = info.data[i].values.length,
                                min = 50;
                            for (var j = 0; j < length; j++) {
                                var val = info.data[i].values[j];
                                if (val < min) {
                                    min = val;
                                }
                            }
                            hasTemperature = true;
                        }
                    } else {
                        chart.data.datasets[i].data = null;
                        chart.data.datasets[i].label = null;
                    }
                }

                //X軸ラベルの更新
                var labels = null;
                switch (conf.type) {
                    case global.DEF.CHART.X_AXIS_TYPE.MONTH:
                        labels = this._createXAxisDateLabels(info.year, info.month, 2);
                        break;
                    case global.DEF.CHART.X_AXIS_TYPE.YEAR:
                        labels = this._createXAxisDateLabels(info.year, 2, 13);
                        break;
                }
                if (labels != null) {
                    chart.scales[DEF_CONF.X_AXIS_ID.MAIN].options.labels = labels;
                }

                //気温軸の更新
                if(hasTemperature) {
                    //最小値を5の倍数に調整
                    min = Math.floor((min - 2) / 5) * 5;
                    chart.scales[DEF_CONF.Y_AXIS_ID.SUB].options.ticks.min = min;
                    chart.scales[DEF_CONF.Y_AXIS_ID.SUB].options.ticks.max = min + 10 * conf.yAxis.count;
                }

                //グラフへ反映
                chart.update();
            };

        SiteChartClass.prototype.resize =
            /**
             * グラフをリサイズする。
             */
            function () {
                for (var selector in this._chart) {
                    this._chart[selector].resize();
                }
            };
    }());


    //==============================================================================
    // インスタンス生成
    //==============================================================================
    return new SiteChartClass();
}(this));