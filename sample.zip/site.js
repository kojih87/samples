var Site = (function (global) {
    "use strict";
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* 定数
    ----------------------------------------------------------*/
    global.DEF = {


        /** グラフ関連 */
        CHART: {
            /** X軸タイプ */
            XAXIS_TYPE: {
                /** 288点／日(5分間隔) */
                DAY_288: 'day288',
                /** 48点／日(30分間隔) */
                DAY_048: 'day048',
                /** 24点／日(1時間間隔) */
                DAY_024: 'day024',
                /** 2カ月(1日間隔) */
                MONTH: 'month',
                /** 13カ月(1日間隔) */
                YEAR: 'year'
            },

            /** 積み上げ棒グラフのRGB値 */
            BAR_RGB: [
                [255, 80, 80],
                [255, 148, 64],
                [252, 252, 32],
                [164, 252, 24],
                [80, 255, 80],
                [64, 228, 255],
                [64, 164, 255],
                [80, 80, 255],
                [164, 128, 255],
                [255, 128, 255]
            ]
        }
    };

    /* 内部定数
    ----------------------------------------------------------*/
    /** ウィンドウタイトル */
    const DEF_TITLE = 'タイトル';
    /** 管理箇所  */
    const DEF_TEAM = '管理箇所';

    /** 外部ライブラリ */
    const DEF_LIBRARIES = {
        /** スタイル */
        STYLE: [
            //日付選択
            'refs/datepicker.css',
            //ファイルアップロード
            'refs/fileupload.css',
            //グリッド
            'refs/download/handsontable.min.css'
        ],
        /** スクリプト */
        SCRIPT: [
            //日付選択
            'refs/datepicker.js',
            //ファイルアップロード
            'refs/fileupload.js',
            //PDF
            'refs/download/pdf.min.js',
            'refs/site-pdf.js',
            //グラフ
            'refs/download/Chart.min.js',
            'refs/site-chart.js',
            //グリッド
            'refs/download/handsontable.min.js',
            'refs/site-grid.js'
        ]
    };

    /** URL */
    const DEF_URL = {
        /** フォルダ */
        PREFIX: {
            /** メニューデータ */
            MENU: 'refs/menu/',
            /** 画面 */
            PAGE: 'pages/',
            /** コンテンツデータ */
            DATA: [
                'data/',
                'security/data/',
                'api/'
            ],
            /** 定期報告書 */
            REPORT: 'security/pdf/'
        },
        /** メニューデータ */
        MENU_DATA: [
            'user_pub.json',
            'user.json',
            'admin.json',
            'admin_nw.json'
        ]
    };

    /** 要素セレクタ */
    const DEF_SELECTOR = {
        /** メニュー */
        MENU: 'body > nav',
        /** メニュー表示切替 */
        MENU_SWITCH: '#menu-switch',
        /** ヘッダ */
        HEADER: 'body > main > header',
        /** タイトル */
        TITLE: 'body > main > header > h1',
        /** コンテンツ */
        CONTENTS: 'body > main > article',
        /** ローディング */
        LOADING: '#loading',
        /** カレント */
        CURRENT: '#current',
        /** 前ページ */
        PREVPAGE: '#prev-page',
        /** 次ページ */
        NEXTPAGE: '#next-page',
        /** スクリプト */
        SCRIPT: '#script'
    };

    /** エラーメッセージ */
    const DEF_ERROR = {
        /** PDF取得エラー */
        PDF_404: '指定されたPDFファイルは存在しません。',
        /** 権限エラー */
        JSON_403: '権限がありません。',
        /** データ取得エラー() */
        JSON_404: 'データが取得できませんでした。<br />30分経過しても解消されない場合は、システム管理者に連絡してください。',
        /** コンテンツ遷移エラー(通常発生しない) */
        HTML_404: '画面が存在しません。<br />システム管理者に連絡してください。',
        /** 未定義のエラー */
        DEFAULT: '想定外のエラーが発生しました。<br />システム管理者に連絡してください。'
    };

    //==============================================================================
    // クラス定義
    //==============================================================================
    /**
     * インスタンスを生成する。
     */
    function SiteClass() {
        /**
         * 読み込み中件数
         * @type {number}
         */
        this._loadingCount = 0;

        /**
         * 設定値
         */
        this._config = {};

        /**
         * コンテンツデータ
         * @type {JSON}
         */
        this._contentsData = null;
        /**
         * ページ番号
         * @type {number}
         */
        this._pageIndex = 0;

        /**
         * 数値整形オブジェクト
         * @type {Intl.NumberFormat}
         */
        this._nummberFormat = Intl.NumberFormat();

        /**
         * 各画面で実装するコールバック
         */
        this.callbacks = {
            /**
             * 設定を取得する。
             * @return {any} 設定
             */
            configure: function () { return {}; },
            /**
             * ページ遷移後に呼び出され、画面を更新する処理を定義する。
             * @param {JSON}   contentsData コンテンツデータ
             * @param {number} index        ページ番号
             */
            navigatePage: function (contentsData, index) { }
        };

        /**
         * イベント操作用のハンドラ
         */
        this.handler = (function () {
            var events = [],
                key = 0;
            return {
                /**
                 * イベントを追加する。
                 * @param {HTMLElement} target   対象要素
                 * @param {string}      type     イベント
                 * @param {Function}    listener イベント発生時に呼び出す処理
                 * @param {boolean}     capture  キャプチャフェーズの場合はtrue、バブルフェーズの場合はfalse
                 * @returns {number} キー
                 */
                addListener: function (target, type, listener, capture) {
                    console.debug('Site.handler.addListener()', key, target.toString(), type);
                    target.addEventListener(type, listener, capture);
                    events[key] = {
                        target: target,
                        type: type,
                        listener: listener,
                        capture: capture
                    };
                    return key++;
                },
                /**
                 * 指定したキーのイベントを削除する。
                 * @param {number} key キー
                 */
                removeListener: function (key) {
                    var e = events[key];
                    console.debug('Site.handler.removeListener()', key, e.target.toString(), e.type);
                    e.target.removeEventListener(e.type, e.listener, e.capture);
                },
                /**
                 * 全てのイベントを削除する。
                 */
                removeAllListener: function () {
                    var e;
                    while (e = events.pop()) {
                        console.debug('Site.handler.removeAllListener()', events.length, e.target.toString(), e.type);
                        e.target.removeEventListener(e.type, e.listener, e.capture);
                    }
                }
            };
        }());
    };
    //空のプロトタイプ設定
    SiteClass.prototype = { constructor: SiteClass };

    /* 初期化
    ----------------------------------------------------------*/
    /**
     * インスタンスを初期化する。
     * @param {boolean} isFirst 初回フラグ(省略可)
     */
    SiteClass.prototype.initialize = function (isFirst) {
        console.debug('Site.initialize()', isFirst);

        //設定値の読み込み
        this._config = this.callbacks.configure();

        //初回の場合
        if (isFirst) {
            //外部ライブラリの読み込み
            this._loadLibraries();
            //共通部品の構築
            this._buildCommonParts();
        }
        //外部ライブラリの初期化
        this._initLibraries();
        //コンテンツの設定
        this._setupContents();
    };

    /**
     * 外部ライブラリを読み込む。(初回のみ)
     */
    SiteClass.prototype._loadLibraries = function () {
        console.debug('Site._loadLibraries()');

        //スタイルの読み込み
        var style = '';
        for (var i in DEF_LIBRARIES.STYLE) {
            style += '<link href="' + DEF_LIBRARIES.STYLE[i] + '" rel="stylesheet" />';
        }
        $('link').last().before(style);

        //スクリプトの読み込み
        var script = '';
        for (var i in DEF_LIBRARIES.SCRIPT) {
            script += '<script src="' + DEF_LIBRARIES.SCRIPT[i] + '"></script>';
        }
        $('script').last().before(script);
    };

    /**
     * 共通部品を構築する。(初回のみ)
     */
    SiteClass.prototype._buildCommonParts = function () {
        console.debug('Site._buildCommonParts()');

        var menuNo = this._config.menuNo,
            team = (1 < menuNo ? '<span>（' + DEF_TEAM + '）</span>' : '');

        //タイトルの設定
        document.title = DEF_TITLE;
        //ヘッダの構築
        $(DEF_SELECTOR.HEADER).html('<h1></h1>' + team);
        //メニューの構築
        this._ajax(
            'json',
            DEF_URL.PREFIX.MENU + DEF_URL.MENU_DATA[menuNo],
            function (json) {
                $(DEF_SELECTOR.MENU)
                    //メニュー要素の構築
                    .html(Site.__formatMenuHtml(json))
                    //イベントの登録
                    .delegate('a', 'click', menu_click)
                    //メニュー表示切替要素の追加
                    .after(Site.__createMenuSwitchHtml());
                $(DEF_SELECTOR.MENU_SWITCH)
                    //イベント登録
                    .on('click', menuSwitch_click);
            }
        );
    };

    /**
     * JSON形式のデータからメニュー要素のHTMLを整形する。(初回のみ)
     * @param {object} json メニューデータ
     * @returns {string} HTML
     */
    SiteClass.prototype.__formatMenuHtml = function (json) {
        var jsonLength = json.length,
            html = '<ul>';
        for (var i = 0; i < jsonLength; i++) {
            var menus = json[i].menus,
                menusLength = menus.length;
            //カテゴリの追加
            html += '<li><span>' + json[i].category + '</span><ul>';
            for (var j = 0; j < menusLength; j++) {
                var menu = menus[j];
                //メニューの追加
                html += '<li><a href="' + DEF_URL.PREFIX.PAGE + menu.link + '">'
                    + menu.label + '</a></li>';
            }
            html += '</ul></li>';
        }
        html += '</ul>';
        return html;
    };

    /**
     * メニュー表示切替要素のHTMLを生成する。(初回のみ)
     * @returns {string} HTML
     */
    SiteClass.prototype.__createMenuSwitchHtml = function () {
        return '<a id="menu-switch" href="javascript:void(0)">'
            + '<svg viewbox="0 0 32 32">'
            + '<rect x="0" y="0" width="32" height="32" rx="5" />'
            + '<g>'
            + '<line x1="7" y1="9" x2="25" y2="9" />'
            + '<line x1="7" y1="16" x2="25" y2="16" />'
            + '<line x1="7" y1="23" x2="25" y2="23" />'
            + '</g>'
            + '</svg>'
            + '</a>';
    };

    /**
     * 外部ライブラリを初期化する。
     */
    SiteClass.prototype._initLibraries = function () {
        console.debug('Site._initLibraries()');

    };

    /**
     * コンテンツを設定する。
     */
    SiteClass.prototype._setupContents = function () {
        console.debug('Site._setupContents()');

        var title = this._config.title,
            pageNavi = this._config.pageNavi,
            contents = this._config.contents;

        //コンテンツタイトルの設定
        $(DEF_SELECTOR.TITLE).text(title);

        //ページナビゲーションの設定
        if (pageNavi) {
            $(DEF_SELECTOR.CURRENT)
                //前ページ要素の追加
                .before(__createPageNavigationHtml(pageNavi.prev, true))
                //次ページ要素の追加
                .after(__createPageNavigationHtml(pageNavi.next, false));
            //イベント登録
            $(DEF_SELECTOR.PREVPAGE).on('click', prevPage_click);
            $(DEF_SELECTOR.NEXTPAGE).on('click', nextPage_click);
        }

        //コンテンツデータの取得
        if (contents) {
            this._ajax(
                'json',
                DEF_URL.PREFIX.DATA[contents.type] + contents.name,
                function (json) {
                    //コンテンツデータの設定
                    Site._contentsData = json;
                    //先頭ページへ遷移
                    Site.navigatePage(0);
                }
            );
        } else {
            //先頭ページへ遷移
            this.navigatePage();
        }
    };

    /**
     * ページナビゲーション要素のHTMLを生成する。
     * @param {string} label ラベル
     * @param {boolean} isPrev 前ページフラグ
     * @returns {string} HTML
     */
    SiteClass.prototype.__createPageNavigationHtml = function (label, isPrev) {
        var id = (isPrev ? 'prev-page' : 'next-page'),
            label1 = (isPrev ? '' : label),
            label2 = (isPrev ? label : ''),
            points = (isPrev ? '0,16 16,0 16,32' : '16,16 0,0 0,32');
        return '<a id="' + id + '" href="javascript:void(0);">'
            + label1
            + '<svg><polygon points="' + points + '"></polygon></svg>'
            + label2
            + '</a>';
    }

    /* 破棄
    ----------------------------------------------------------*/
    /**
     * インスタンスを破棄する。
     * @param {boolean} isLast 最終フラグ(省略可)
     */
    SiteClass.prototype.destroy = function (isLast) {
        console.debug('Site.destroy()', isLast);

        //最終の場合
        if (isLast) {
            //イベントの削除
            this.handler.removeAllListener();
            //ライブラリの解放
            this._destroyLibraries();
            //定数の解放
            global.DEF = null;
            global = null;
        }
    };

    /**
     * 外部ライブラリを破棄する。
     */
    SiteClass.prototype._destroyLibraries = function () {
        Datepicker.destroy();
        Fileupload.destroy();
        this.Pdf.destroy();
        this.Chart.destroy();
        this.Grid.destroy();

        Datepicker = null;
        Fileupload = null;
        this.Pdf = null;
        this.Chart = null;
        this.Grid = null;
    };

    /* 画面遷移
    ----------------------------------------------------------*/
    /**
     * 指定したコンテンツへ遷移する。
     * @param {string} url 画面URL
     */
    SiteClass.prototype.navigateUrl = function (url) {
        console.debug('Site.navigateUrl()', url);

        //アドレスバーの書き換え
        history.replaceState(null, null, url);

        //HTTP要求
        this._ajax(
            'html',
            url,
            function (html) {
                //破棄
                Site.destroy();

                //個別スクリプト要素の入れ替え
                $(DEF_SELECTOR.SCRIPT)
                    .after($(html).filter(DEF_SELECTOR.SCRIPT))
                    .remove();

                //コンテンツ要素の入れ替え
                $(DEF_SELECTOR.CONTENTS)
                    .after($(html).find(DEF_SELECTOR.CONTENTS))
                    .remove();

                //初期化
                Site.initialize();
            }
        );
    };

    /**
     * 指定したページへ遷移する。
     * @param {number} index ページ番号(省略可)
     */
    SiteClass.prototype.navigatePage = function (index) {
        console.debug('Site.navigatePage()', index);

        //読み込み中
        this.loading();

        var pageNavi = Site._config.pageNavi;
        if (pageNavi) {
            //ページ番号の設定
            this._pageIndex = (function (i, min, max) {
                //範囲内に設定
                i = (i < min ? min : max < i ? max : i);
                //ナビゲーションの表示切替
                $(DEF_SELECTOR.PREVPAGE).css('visibility', i == max ? 'hidden' : 'visible');
                $(DEF_SELECTOR.NEXTPAGE).css('visibility', i == min ? 'hidden' : 'visible');
                return i;
            }(index, 0, pageNavi.max - 1));
        } else {
            //ページ番号の設定
            this._pageIndex = index;
        }

        //コールバックの呼び出し
        this.callbacks.navigatePage(this._contentsData, this._pageIndex);

        //読み込み完了
        this.loaded();
    };

    /**
     * エラーメッセージを表示する。
     * @param {number} errorCode エラーコード
     * @param {string} selector メッセージを表示する要素セレクタ(省略可)
     */
    SiteClass.prototype.setError = function (errorCode, selector) {
        console.debug('Site.setError()', errorCode, selector);

        $(selector || DEF_SELECTOR.CONTENTS)
            .addClass('error')
            .html(DEF_ERROR[errorCode] || DEF_ERROR.DEFAULT);
    };

    /* ローディング
    ----------------------------------------------------------*/
    /**
     * 読み込み中の画面表示に切り替える。
     * @param {string} 読み込み中の要素セレクタ(省略可)
     */
    SiteClass.prototype.loading = function (selector) {
        //読み込み中件数のインクリメント
        this._loadingCount++;
        console.debug('.....loading(+)', this._loadingCount);

        //ローディング要素の存在チェック
        var $loading = $(DEF_SELECTOR.LOADING),
            $target;
        //存在しない場合
        if ($loading.length == 0) {
            //対象要素の取得
            $target = $(selector || DEF_SELECTOR.CONTENTS);
            //ローディング要素の追加
            $loading = $('<div id="loading" />');
            $target.after($loading);
        }
        //存在する場合
        else {
            //対象要素の取得
            $target = $loading.prev();
        }

        //表示切替
        $loading
            .offset({ top: $target.offset().top - 5, left: 0 })
            .height($target.height() + 10)
            .css('background-position-x', $target.width() / 2 - 64)
            .show();
    };

    /**
     * 全ての読み込みが完了した場合、読み込み中の画面表示を解除する。
     */
    SiteClass.prototype.loaded = function () {
        //読み込み中件数の判定
        if (0 < --this._loadingCount) {
            console.debug('.....loading(-)', this._loadingCount);
            return;
        }
        console.debug('.....loading(-) end');

        //ローディング要素の取得
        var $loading = $(DEF_SELECTOR.LOADING);
        $loading.fadeOut(200, function () {
            //対象要素の再描画
            $loading.prev().hide().show();
            $loading = null;
        });
    };

    /* HTTP通信
    ----------------------------------------------------------*/
    /**
     * 非同期でHTTP通信を行う。
     * @param {string}   dataType データタイプ
     * @param {string}   url      要求するURL
     * @param {Function} callbak  正常な応答を処理するコールバック
     */
    SiteClass.prototype._ajax = function (dataType, url, callback) {
        console.debug('>>> ajax', dataType, url)

        //読み込み中
        Site.loading();

        //HTTP要求
        $.ajax({
            type: 'get',
            url: url,
            dataType: dataType,
            cache: false
        })
            //成功した場合の処理
            .then(function (data, textStatus, jqXHR) {
                console.debug('<<< ajax', dataType, '(done)', jqXHR.status);
                //コールバック呼び出し
                callback(data);
            })
            //失敗した場合の処理
            .catch(function (jqXHR, textStatus, errorThrown) {
                console.debug('<<< ajax', dataType, '(fail)', jqXHR.status);
                //エラー表示
                Site.setError(dataType.toUpperCase() + '_' + jqXHR.status);
            })
            //常に実行する処理
            .then(function () {
                console.debug('<<< ajax', dataType, '(always)');
                //読み込み完了
                Site.loaded();
            });
    }


    //==============================================================================
    // イベント
    //==============================================================================
    document.addEventListener('DOMContentLoaded', document_DOMContentLoaded, false);
    window.addEventListener('load', window_load, false);
    window.addEventListener('unload', window_unload, false);

    /**
     * ドキュメントのDOM読み込み完了イベントを処理する。
     */
    function document_DOMContentLoaded() {
        console.debug('↓↓↓↓↓ document.DOMContentLoaded ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓');

        //読み込み中
        Site.loading();
        //初期化
        Site.initialize(true);

        console.debug('↑↑↑↑↑ document.DOMContentLoaded ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑');
    };

    /**
     * ウィンドウのロードイベントを処理する。
     */
    function window_load() {
        console.debug('↓↓↓↓↓ window.load               ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓');

        //読み込み完了
        Site.loaded();

        console.debug('↑↑↑↑↑ window.load               ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑');
    };

    /**
     * ウィンドウのアンロードイベントを処理する。
     */
    function window_unload() {
        console.debug('↓↓↓↓↓ window.unload             ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓');

        //破棄
        Site.destroy(true);
        Site = null;

        console.debug('↑↑↑↑↑ window.unload             ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑');
    };

    /**
     * メニュー表示切替のクリックイベントを処理する。
     */
    function menuSwitch_click() {
        console.debug('↓↓↓↓↓ menu-switch.click         ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓');

        //メニュー表示切替
        $('body').toggleClass('menu-hide');

        console.debug('↑↑↑↑↑ menu-switch.click         ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑');
    };

    /**
     * メニューのクリックイベントを処理する。
     */
    function menu_click() {
        console.debug('↓↓↓↓↓ menu.click                ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓');

        //コンテンツ遷移
        Site.navigateUrl($(this).attr('href'));

        console.debug('↑↑↑↑↑ menu.click                ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑');
        //遷移のキャンセル(非同期で実装)
        return false;
    };

    /**
     * 前ページのクリックイベントを処理する。
     */
    function prevPage_click() {
        console.debug('↓↓↓↓↓ prev-page.click           ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓');

        //前ページへ遷移
        Site.navigatePage(Site._pageIndex + 1);

        console.debug('↑↑↑↑↑ prev-page.click           ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑');
    };

    /**
     * 次ページのクリックイベントを処理する。
     */
    function nextPage_click() {
        console.debug('↓↓↓↓↓ next-page.click           ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓');

        //次ページへ遷移
        Site.navigatePage(Site._pageIndex - 1);

        console.debug('↑↑↑↑↑ next-page.click           ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑');
    };

    /* インスタンス生成
    ----------------------------------------------------------*/
    return new SiteClass();
}(this));