var Site = (function () {
    "use strict";

    //==============================================================================
    // 環境設定
    //==============================================================================

    /* デバッグログ出力
    --------------------------------------*/
    //console.debug = function () { };

    /* 定数
    --------------------------------------*/
    /** 定数 */
    const DEF = {
        /** システム管理箇所 */
        TEAM: 'システム管理箇所',

        /** URL関連 */
        URL: {
            /** ディレクトリ */
            DIR: {
                /** メニューデータ */
                MENU: 'refs/menu/',

                /** ページ */
                PAGE: 'pages/',

                /** ページデータ */
                DATA: 'data/',

                /** ページデータ（公開制限） */
                DATA_SEC: 'security/data/',

                /** PDF */
                PDF: 'security/pdf/'
            },

            /** メニューファイル名リスト */
            MENUS: [
                'user1',
                'user2',
                'admin1',
                'admin2'
            ],

            /** データ拡張子 */
            EXTENSION: '.json'
        },

        /** HTML要素関連 */
        ELM: {
            /** ID */
            ID: {
                /** ヘッダ */
                HEADER: '#header',

                /** メニュー */
                MENU: '#menu',

                /** コンテンツ */
                CONTENTS: '#contents',

                /** ローディング */
                LOADING: '#loading',

                /** カレント */
                CURRENT: '#current',

                /** 前ページ */
                PREV: '#prev',

                /** 次ページ */
                NEXT: '#next'
            },

            /** クラス */
            CLS: {
                /** 日付選択 */
                DATEPICKER: '.datepicker',

                /** PDF */
                PDF: '.pdf',

                /** グラフ */
                CHART: '.chart',

                /** メニュー非表示 */
                HIDE_MENU: 'hide-menu'
            }
        }
    };

    /* 変数
    --------------------------------------*/
    /** ページデータ */
    var _pageData;
    /** ページ番号 */
    var _pageIndex;


    //==============================================================================
    // 関数
    //==============================================================================

    /* 画面初期化
    --------------------------------------*/
    /**
     * 画面を初期化する。
     */
    function _initScreen() {
        //ライブラリの初期化
        _initPdfLibrary();
        _initChartLibrary();
        _initDatepickerLibrary();

        //共通部品の設定
        _setupCommonParts();
    }

    /**
     * 共通部品を設定する。
     */
    function _setupCommonParts() {
        //設定値の取得
        var title = Site.config.title;
        var menuNo = Site.config.menuNo;
        var pageNavi = Site.config.pageNavi;
        var isAdmin = (1 < menuNo);

        //ウィンドウタイトルの設定
        document.title = title;

        //ヘッダの設定
        $(DEF.ELM.ID.HEADER).html(
            '<h1>' + title + '</h1>'
            + (isAdmin ? '' : '<span>（' + DEF.TEAM + '）</span>')
        );

        //メニューの設定
        _getJson(
            DEF.URL.DIR.MENU + DEF.URL.MENUS[menuNo] + DEF.URL.EXTENSION,
            function (json) {
                $(DEF.ELM.ID.MENU)
                    .append(_createCommonPartsMenu(json))
                    .after(_createCommonPartsMenuSwitch());
            }
        );

        //ページナビゲーション有りの場合
        if (pageNavi) {
            //ページナビゲーションの設定
            $(DEF.ELM.ID.CURRENT)
                .before(_createCommonPartsPageNavigation(pageNavi.prev, true))
                .after(_createCommonPartsPageNavigation(pageNavi.next, false));
        }
    }

    /**
     * メニューデータからメニュー要素を生成する。
     * @param {object} json メニューデータ
     * @returns {object} jQuery要素オブジェクト
     */
    function _createCommonPartsMenu(json) {
        var $ul1 = $('<ul />');

        //カテゴリ毎のループ
        for (var i in json) {
            var $ul2 = $('<ul />');

            //メニュー毎のループ
            for (var j in json[i].menus) {
                var menu = json[i].menus[j];
                //リンクの追加
                $ul2.append($('<li />').html('<a href="' + DEF.URL.DIR.PAGE + menu.link + '">' + menu.label + '</a>'));
            }

            //カテゴリの追加
            $ul1.append($('<li />')
                .append('<span>' + json[i].category + '</span>')
                .append($ul2)
            );
        }

        return $ul1;
    }

    /**
     * メニュー表示切替要素を生成する。
     */
    function _createCommonPartsMenuSwitch() {
        return $('<a id="menu-switch" href="javascript:void(0);" title="メニュー表示切替" />')
            .append(
                '<svg viewBox="0,0,32,32">'
                + '<rect x="0" y="0" width="32" height="32" rx="5" />'
                + '<g>'
                + '<line x1="6" y1="9" x2="26" y2="9" />'
                + '<line x1="6" y1="16" x2="26" y2="16" />'
                + '<line x1="6" y1="23" x2="26" y2="23" />'
                + '</g>'
                + '</svn>'
            )
            .on('click', function () {
                console.debug('↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ menu-switch.click         ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  --  site.js');

                //メニュー表示切替
                $('body').toggleClass('hide-menu');

                console.debug('↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ menu-switch.click         ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  --  site.js');
            });
    }

    /**
     * ページナビゲーション要素を生成する。
     * @param {string} label ラベル
     * @param {boolean} isPrev 前ページフラグ
     * @returns {object} jQuery要素オブジェクト
     */
    function _createCommonPartsPageNavigation(label, isPrev) {
        if (isPrev) {
            //前ページ
            return $('<a id="prev" href="javascript:void(0);" />')
                .append('<svg><polygon points="0,16 16,0 16,32"></polygon></svg>')
                .append(label)
                .on('click', _navigatePrevPage);
        }
        else {
            //次ページ
            return $('<a id="next" href="javascript:void(0);" />')
                .append(label)
                .append('<svg><polygon points="16,16 0,0 0,32"></polygon></svg>')
                .on('click', _navigateNextPage);
        }
    }

    function _loadPageData() {
        //設定値の取得
        var isSecurity = Site.config.isSecurity;
        var dataName = Site.config.dataName;

        //URL
        var dataUrl
            = (isSecurity ? DEF.URL.DIR.DATA_SEC : DEF.URL.DIR.DATA)
            + dataName + DEF.URL.EXTENSION;
        _getJson(
            dataUrl,
            function (json) {
                //ページデータの設定
                _pageData = json;
                //先頭ページへ遷移
                _navigatePage(0);
            }
        );
    }

    /* ページナビゲーション
    --------------------------------------*/
    /**
     * 前ページへ遷移する。
     */
    function _navigatePrevPage() {
        _navigatePage(_pageIndex + 1);
    }

    /**
     * 次ページへ遷移する。
     */
    function _navigateNextPage() {
        _navigatePage(_pageIndex - 1);
    }

    /**
     * 指定されたページへ遷移する。
     * @param {number} index ページ番号
     */
    function _navigatePage(index) {
        //設定値の取得
        var pageNavi = Site.config.pageNavi;

        //ページナビゲーション有りの場合
        if (pageNavi) {
            _pageIndex = (function (i, min, max) {
                //インデックスが範囲外の場合に調整する
                i = (i < min) ? min : (max < i) ? max : i;

                //ページナビゲーション要素の表示切替
                $(DEF.ELM.ID.PREV).css('visiblity', (i == max) ? 'hidden' : 'visible');
                $(DEF.ELM.ID.NEXT).css('visiblity', (i == min) ? 'hidden' : 'visible');
                return i;
            })(index, 0, pageNavi.max);
        }

        //画面の更新
        Site.updateScreen(_pageData, _pageIndex);
    }

    /* datepicker.js関連
    --------------------------------------*/
    function _initDatepickerLibrary() {
        //要素の存在チェック
        var $elms = $(DEF.ELM.CLS.DATEPICKER);
        if ($elms.length == 0) {
            console.debug('init library(datepicker) - cancel');
            return;
        }
        console.debug('init library(datepicker)');

        //ライブラリの読み込み
        _loadLibrary('refs/datepicker.js', 'refs/datepicker.css');
    }

    /* PDF.js関連
    --------------------------------------*/
    /**
     * PDF.jsの読み込みが必要な場合、ライブラリの読み込みと初期化処理を行う。
     */
    function _initPdfLibrary() {
        //要素の存在チェック
        var $elms = $(DEF.ELM.CLS.PDF);
        if ($elms.length == 0) {
            console.debug('init library(pdf) - cancel');
            return;
        }
        console.debug('init library(pdf)');

        //ライブラリの読み込み
        _loadLibrary('refs/download/pdf.min.js');

        //ライブラリの初期化
        //pdfjsLib.GlobalWorkerOptions.workerSrc = 
        pdfjsLib.cMapUrl = _getAbsoluteUrl('refs/download/cmaps/');
        pdfjsLib.cMapPacked = true;
    }

    /**
     * 指定された要素にPDFを描画する。
     * @param {string} selector 要素ID
     * @param {string} relativeUrl PDFファイルの相対URL
     */
    function _navigatePdf(selector, relativeUrl) {
        //親要素のクリア
        var $container = $(selector);
        $container.empty();

        //PDFドキュメントの取得
        pdfjsLib.getDocument(_getAbsoluteUrl(DEF.URL.PDF + relativeUrl))
            //成功した場合の処理
            .then(function (pdf) {
                //ページ毎のループ
                for (var i = 1; i <= pdf.numPages; i++) {
                    //ページの取得
                    pdf.getPage(i).then(function (page) {
                        //Viewportの取得
                        var viewport = page.getViewport(1.5);

                        //Canvas要素の追加
                        var canvas = $('<canvas />').get(0);
                        canvas.width = viewport.width;
                        canvas.height = viewport.height;
                        $container.append(canvas);

                        //Canvas要素へ描画
                        page.render({
                            canvasContext: canvas.getContext('2d'),
                            viewport: viewport
                        });
                    })
                }
            })
            //失敗した場合の処理
            .catch(function (error) {
                _setErrorMessage($container, '');
            });
    }

    /* Chart.js関連
    --------------------------------------*/
    /**
     * Chart.jsの読み込みが必要な場合、ライブラリの読み込みと初期化処理を行う。
     */
    function _initChartLibrary() {
        //要素の存在チェック
        var $elms = $(DEF.ELM.CLS.CHART);
        if ($elms.length == 0) {
            console.debug('init library(chart) - cancel');
            return;
        }
        console.debug('init library(chart)');

        //ライブラリの読み込み
        _loadLibrary('refs/download/chart.min.js');
    }

    /* その他関数
    --------------------------------------*/
    /**
     * ライブラリの資源を読み込む。
     * @param {string} srcScript JavaScriptのURL
     * @param {string} srcStyle CSSのURL(省略可)
     */
    function _loadLibrary(srcScript, srcStyle) {
        //スクリプトの追加
        $('script').last().after($('<script />').attr('src', srcScript));
        //スタイルの追加
        if (srcStyle) {
            $('link').last().after($('<link rel="stylesheet" />').attr('href', srcStyle))
        }
    }


    /**
     * Ajaxを使用してJSON形式のデータを取得する。
     * @param {string} relativeUrl 要求するURL
     * @param {function} callback 成功した場合のコールバック
     */
    function _getJson(relativeUrl, callback) {
        //Ajax要求
        var absoluteUrl = _getAbsoluteUrl(relativeUrl);
        console.debug('ajax >>>', absoluteUrl);
        $.ajax({
            url: absoluteUrl,
            type: 'get',
            dataType: 'json',
            chace: false,
            async: false
        })
            //成功した場合の処理
            .done(function (data, textStatus, jqXHR) {
                console.debug('ajax <<< (done)', jqXHR.status, data);
                callback(data);
            })
            //失敗した場合の処理
            .fail(function (jqXHR, textStatus, errorThrown) {
                console.debug('ajax <<< (fail)', jqXHR.status, errorThrown);
                //エラーメッセージの設定
                var message;
                switch (jqXHR.status) {
                    case 403:
                        message = '';
                        break;
                    default:
                        break;
                }
                _setErrorMessage($(DEF.ELM.ID.CONTENTS), message);
            });
    }

    /**
     * 相対URLから絶対URLを取得する。
     * @param {string} relativeUrl 相対URL
     * @returns {string} 絶対URL
     */
    function _getAbsoluteUrl(relativeUrl) {
        return $('<a />').attr('href', relativeUrl).prop('href');
    }

    /**
     * 読み込み中の画面に切り替える。※多重実行不可
     * @param {string} selector 対象の要素セレクタ(省略可)
     */
    function _loading(selector) {
        //対象要素の取得(省略時はコンテンツ)
        var $target = $(selector || DEF.ELM.ID.CONTENTS);

        //表示切替
        $target.hide();
        $target.before('<div id="loading" />');
    }

    /**
     * 読み込み中の画面を元に戻す。
     */
    function _loaded() {
        //ローディング要素の取得
        var $loading = $(DEF.ELM.ID.LOADING);

        //表示切替
        $loading.fadeOut(200, function(){
            $loading.next().fadeIn(200);
            $loading.remove();
        });
    }

    /**
     * 指定された要素にエラーメッセージを設定する。
     * @param {object} $elm jQuery要素オブジェクト
     * @param {string} message エラーメッセージ
     */
    function _setErrorMessage($elm, message) {
        $elm.addClass('error').text(message);
    }


    //==============================================================================
    // イベント登録
    //==============================================================================

    // DOMツリー構築完了
    document.addEventListener('DOMContentLoaded', function (event) {
        console.debug('↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ document.DOMContentLoaded ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  --  site.js');

        //読み込み中
        _loading();
        //画面の初期化
        _initScreen();

        console.debug('↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ document.DOMContentLoaded ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  --  site.js');
    }, false);

    // 読み込み完了
    window.addEventListener('load', function () {
        console.debug('↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ window.load               ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  --  site.js');

        //読み込み完了
        _loaded();

        console.debug('↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ window.load               ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  --  site.js');
    }, false);


    //==============================================================================
    // 公開
    //==============================================================================
    return {
        config: {}
    };
})();