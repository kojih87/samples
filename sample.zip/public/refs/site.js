/**
 * @fileoverview サイト内で利用する共通スクリプトを定義する。
 */
let Site = ( function() {
	"use strict";

	//==============================================================================
	// 環境設定
	//==============================================================================

	/* デバッグログ停止 (release時コメント解除)
	--------------------------------------*/
	//console.debug = function () { };
	console.debug( '>>>>> start -- site.js' );

	/* 定数
	--------------------------------------*/
	/**
	 * システムの管理箇所を定義する。
	 * @const {string}
	 */
	const DEF_TEAM = '管理箇所';

	/**
	 * URL関連の定数を定義する。
	 * @const {object}
	 */
	const DEF_URL = {
		/**
		 * ドキュメントルートからの相対パスでディレクトリを定義する。
		 * @const {object}
		 */
		DIR: {
			/**
			 * メニュー
			 * @const {string}
			 */
			MENU: 'refs/menus/',

			/**
			 * サードパティ製ライブラリ
			 * @const {string}
			 */
			LIB: 'refs/download/',

			/**
			 * ページデータ
			 * @const {string}
			 */
			DATA: 'data/',

			/**
			 * ページデータ(公開制限)
			 * @const {string}
			 */
			DATA_SEC: 'security/data/',

			/**
			 * PDF
			 * @const {string}
			 */
			PDF: 'security/pdf/'
		},

		/**
		 * メニューデータのファイル名(拡張子除く)を定義する。
		 * @const {array}
		 */
		MENU_DATA: [
			//全社員
			'user_pub',
			//一部社員
			'user',
			//管理
			'admin'
		],

		//JSON拡張子
		EXT_JSON: '.json'
	};

	/* 変数
	--------------------------------------*/
	/**
	 * 読み込み中の件数を保持する。
	 * @type {number}
	 */
	let _loadingCount = 0;

	/**
	 * ページデータを保持する。
	 * @type {object}
	 */
	let _pageData = null;

	/**
	 * 現在のページ番号を保持する。
	 * @type {number}
	 */
	let _pageIndex = 0;

	/**
	 * グラフオブジェクトを保持する。(Chart.js)
	 * @type {object}
	 */
	let _chart = null;

	/**
	 * PDF操作オブジェクトを保持する。(PDF.js)
	 * @type {object}
	 */
	let _pdfjs = null;

	//==============================================================================
	// 関数
	//==============================================================================

	/* 画面初期化
	--------------------------------------*/
	/**
	 * 画面を初期化する。
	 */
	function _initScreen() {
		//設定値の取得
		let title = Site.config.title;
		let menuNo = Site.config.menuNo;
		let pageNavi = Site.config.pageNavi;

		//タイトルの編集
		document.title = title;

		//ヘッダの編集
		$('#header').append( '<h1>' + title + '</h1><span>（' + DEF_TEAM + '）</span>' );

		//メニューの編集
		_getJson(
			DEF_URL.DIR.MENU + DEF_URL.MENU_DATA[menuNo] + DEF_URL.EXT_JSON,
			function( json ) {
				$('#menu')
					.append( _createMenuElements( json ) )
					.after( _createMenuSwitchElement() );
			}
		);

		//ページナビゲーションの編集
		if( pageNavi ) {
			let elms = _createPageNaviElements( pageNavi );
			$('#target')
				.before( elms[0] )
				.after( elms[1] );
		}

		//グラフ要素が存在する場合
		let $chart = $('canvas.chart');
		if( $chart.length ) {
		}

		//PDF要素が存在する場合
		let $pdf = $('canvas.pdf');
		if( $pdf.length ) {
			//PDF操作オブジェクトの生成
			_pdfjs = window['pdfjs-dist/build/pdf'];
			_pdfjs.GlobalWorkerOptions.workerSrc = _getAbsoluteUrl('./pdf.worker.js');
			_pdfjs.cMapUrl = _getAbsoluteUrl('./cmaps/');
			_pdfjs.cMapPacked = true;
		}

Site.updateScreen();
	}

	/**
	 * JSON形式のメニューデータからHTML要素を生成する。
	 * @param {object} json メニューデータ
	 * @returns {array} jQueryオブジェクト配列
	 */
	function _createMenuElements( json ) {
		let result = [];

		//カテゴリ毎の繰り返し
		let dataLength = json.length;
		for( let i=0; i<dataLength; i++ ) {
			let data = json[i];
			let $ul = $('<ul />');

			//メニュー毎の繰り返し
			let menuLength= data.menus.length;
			for( let j=0; j<menuLength; j++ ) {
				let menu = data.menus[j];

				//メニューの追加
				$ul.append( $('<li />')
					.append( $('<a href="javascript:void(0);">' + menu.label + '</a>' )
						.on( 'click', function() {
							//読み込み中
							_loading();
							//画面遷移
							location.href = _getAbsoluteUrl( menu.link );
						} )
					)
				);
			}

			//カテゴリの追加
			result[i] = $('<div />')
				.append( '<span>' + data.category + '</span>' )
				.append( $ul );
		}
		return result;
	}

	/**
	 * メニュー表示切替要素を生成する。
	 * @returns {object} jQueryオブジェクト
	 */
	function _createMenuSwitchElement() {
		//アイコンの生成
		let icon
			= '<svg viewBox="0 0 36 36">'
			+ '<rect x="0" y="0" width="36" height="36" rx="5" />'
			+ '<g>'
			+ '<line x1="7" y1="10" x2="29" y2="10" />'
			+ '<line x1="7" y1="18" x2="29" y2="18" />'
			+ '<line x1="7" y1="26" x2="29" y2="26" />'
			+ '</g>';

		return $('<a id="menu-switch" href="javascript:void(0)" title="メニュー表示切替" />')
			.append( icon )
			.on( 'click', function() {
				$('body').toggleClass( 'hide-menu' );
			} );
	}

	/**
	 * ページナビゲーション要素を生成する。
	 * @param {object} 設定値
	 * @returns {object} jQueryオブジェクト配列
	 */
	function _createPageNaviElements( pageNavi ) {
		return [
			$('<a href="javascript:void(0);" />')
				.append( '<svg><polygon points="16,0 16,32 0,16" /></svg>' + pageNavi.prev ),
			$('<a href="javascript:void(0);" />')
				.append( pageNavi.next + '<svg><polygon points="0,0 0,32 16,16" /></svg>' )
		];
	}

	/* ページナビゲーション
	--------------------------------------*/
	/**
	 * 前ページへ遷移する。
	 */
	function _navigatePrevPage() {
		_setPage( _pageNo + 1 );
	}

	/**
	 * 次ページへ遷移する。
	 */
	function _navigateNextPage() {
		_setPage( _pageNo - 1 );
	}

	/**
	 * 指定したページへ遷移する。
	 * @param {number} ページ番号
	 */
	function _setPage( pageNo ) {
	}


	/* グラフ
	--------------------------------------*/

	/* PDF表示
	--------------------------------------*/
	function _navigatePdf( id, reqUrl ) {
		//読み込み中
		_loading();
		
		//PDFの読み込み(非同期)
		let loadingTask = _pdfjs.getDocument( _getAbsoluteUrl(DEF_URL.DIR.PDF + reqUrl) );
		loadingTask.promise.then( function( pdf ) {
			//読み込み完了
			
			pdf.getPage( 1 ).then( function( page ) {
				let $canvas = $('#' + id);
				
				
				let scale = $('#base').innerWidth() / page.getViewport(1.0).width;
				let viewport = page.getViewport( {scale: scale} );
				
				$canvas.width(viewport.width).height(viewport.height);
				let context = $canvas[0].getContext('2d');
				
				var renderContext = {
					canvasContext: context,
					viewport: viewport
				};
				let renderTask = page.render( renderContext );
				renderTask.promise.then(function() {
					_loaded();
				});
			} );
		}, function( reason ) {
			//
			alert('err');
					_loaded();
		} );
		
	}

	/* 共通
	--------------------------------------*/
	/**
	 * ajax通信でJSON形式のデータを取得する。
	 * @param {string}   要求するURL
	 * @param {function} 要求が成功した場合のコールバック
	 */
	function _getJson( reqUrl, callback ) {
		//読み込み中
		_loading();

		//HTTP要求
		$.ajax({
			type: 'get',
			url: reqUrl,
			cache: false,
			dataType:  'json'
		})
			.done(function( response, textStatus, jqXHR ) {
				//成功
				callback( response );
			})
			.fail(function( jqXHR, textStatus, errorThrown ) {
				//失敗
				switch( jqXHR.status ) {
					case 403:
						
						break;

					default:
						break;
				}
			})
			.always(function() {
				//読み込み完了
				_loaded();
			});
	}

	/**
	 * 
	 */
	function _loading() {
		console.debug( 'loading ' + _loadingCount + ' → ' + (_loadingCount+1) );

		//既に読み込み中の場合
		if( 1 < ++_loadingCount ) {
			return;
		}

		//要素の取得
		let $contents = $('#contents');
		let $loading = $('#loading');

		//読み込み中要素が存在しない場合
		if( $loading.length == 0 ) {
			$loading = $('<div id="loading" />');
			$contents.before( $loading );
		}

		//表示切替
		$contents.hide();
		$loading.show();
	}

	/**
	 * 
	 */
	function _loaded() {
		console.debug( 'loaded ' + _loadingCount + ' → ' + (_loadingCount-1) );

		//読み込みが未完了の場合
		if( --_loadingCount < 1 ) {
			return;
		}

		//要素の取得
		let $contents = $('#contents');
		let $loading = $('#loading');

		//表示切替
		$loading.fadeOut( 200, function() {
			$contents.fadeIn( 100 );
		} );
		
	}

	/**
	 * 相対URLから絶対URLを取得する。
	 * @param {string} relativeUrl 相対URL
	 * @returns 絶対URL
	 */
	function _getAbsoluteUrl( relativeUrl ) {
		return $('<a />').attr( 'href', relativeUrl ).prop( 'href' );
	}


	//==============================================================================
	// イベント登録
	//==============================================================================
	//DOMツリー構築完了時
	document.addEventListener( 'DOMContentLoaded', function() {
		console.debug( '> document.DOMContentLoaded() start -- site.js' );

		//読み込み中
		_loading();

		//画面初期化
		_initScreen();

		console.debug( '> document.DOMContentLoaded() end   -- site.js' );
	}, false );

	//ロード完了時
	window.addEventListener( 'load', function() {
		console.debug( '> window.load() start -- site.js' );

		//読み込み完了
		_loaded();

		console.debug( '> window.load() end   -- site.js' );
	}, false );


	//==============================================================================
	// 外部公開 (各画面からSite.*で利用)
	//==============================================================================
	return {
	
		navigatePdf: _navigatePdf
	};
}() );

console.debug( '>>>>> end   -- site.js' );
