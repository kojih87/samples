Site.Pdf = (function () {
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* PDF.js
    --------------------------------------*/
    //core layerのパス設定
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'refs/download/pdf.worker.min.js';
    //character mapsのパス設定
    pdfjsLib.cMapUrl = 'refs/download/cmaps/';

    /* 変数
    --------------------------------------*/
    /** PDFフォルダ */
    var _pdfDir = '';


    //==============================================================================
    // 関数
    //==============================================================================

    function _initialize() {
    }

    /**
     * PDFフォルダのパスを設定する。
     * @param {string} path パス
     */
    function _setPdfDirectory(path) {
        _pdfDir = path;
    }

    /**
     * PDFファイルを表示する。
     * @param {string} selector 要素セレクタ
     * @param {string} file PDFフォルダからの相対パス
     */
    function _navigate(selector, file) {
        var url = _pdfDir + file;
        console.debug('PDF.js >', url);
        //読み込み中(ドキュメント)
        Site.loading(selector);

        //ドキュメントの取得
        pdfjsLib.getDocument(url)
            .then(function (pdf) {
                console.debug('PDF.js > (done)');

                var numPages = pdf.numPages;
                for (var i = 1; i <= numPages; i++) {
                    //読み込み中(ページ)
                    Site.loading();

                    //ページの取得
                    pdf.getPage(i).then(function (page) {
                        //倍率の計算
                        var $container = $(selector),
                            scale = $container.width() / page.getViewport(1).width,
                            viewport = page.getViewport(scale);

                        //キャンバスの追加
                        var canvas = $('<canvas />')[0];
                        canvas.width = viewport.width;
                        canvas.height = viewport.height;
                        $container.append(canvas);

                        //キャンバスへ描画
                        page.render({
                            canvasContext: canvas.getContext('2d'),
                            viewport: viewport
                        });

                        //読み込み完了(ページ)
                        Site.loaded();

                        viewport = null;
                        canvas = null;
                        page = null;
                    });

                }

                //読み込み完了(ドキュメント)
                Site.loaded();

                pdf = null;
            })
            .catch(function (error) {
                console.debug('PDF.js > (fail)', error);
                //エラー表示
                Site.setError('PDF_404', selector);
                //読み込み完了
                Site.loaded();
            });
    }


    //==============================================================================
    // 公開(Site.Pdf.*)
    //==============================================================================
    return {
        /**
         * ライブラリを初期化する。(未実装)
         */
        initialize: _initialize,

        /**
         * PDFフォルダのパスを設定する。
         * @param {string} path パス
         */
        setPdfDirectory: _setPdfDirectory,

        /**
         * PDFファイルを表示する。
         * @param {string} selector 要素セレクタ
         * @param {string} url 要求するURL
         */
        navigate: _navigate
    };
}());