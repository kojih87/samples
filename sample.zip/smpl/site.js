var Site = (function () {
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* 定数
    --------------------------------------*/
    /**
     * システムの管理箇所を定義する。
     */
    const DEF_TEAM = '管理箇所';

    /**
     * URLに関連する情報を定義する。
     */
    const DEF_URL = {
        /** フォルダ */
        PREFIX: {
            MENU: 'refs/menu/',
            PAGE: 'pages/',
            DATA: [
                'data/',
                'security/data/',
                'api/'
            ],
            REPORT: 'security/pdf/'
        },

        /** データ拡張子 */
        DATA_EXTENSION: '.json',

        /** メニュー番号に対応するメニューデータ */
        MENU_DATA: [
            'user_pub',
            'user',
            'admin',
            'admin_nw'
        ]
    };

    /**
     * エラーコードに対応するメッセージを定義する。
     */
    const DEF_ERROR = {
        JSON_403: '権限無し',
        JSON_404: 'データファイルが存在しません。',
        PDF_404: 'PDFファイルが存在しません。',
        HTML_404: '画面が存在しません。',
        DEFAULT: '想定外のエラーが発生しました。<br />システム管理者に連絡してください。'
    };

    /* 変数
    --------------------------------------*/
    /** 読み込み中件数 */
    var _loadingCount = 0;

    /** コンテンツデータ */
    var _contentsData = null;
    /** ページ番号 */
    var _pageIndex = 0;


    //==============================================================================
    // 初期化
    //==============================================================================
    /**
     * サイトを初期化する。
     * @param {boolean} isLoad 初期表示フラグ
     */
    function _initialize(isLoad) {
        if (isLoad) {
            //外部ライブラリの読み込み
            _loadLibraries();
        }
        //外部ライブラリの初期化
        _initLibraries();

        //画面設定の読み込み
        Site.callbacks.configure();

        if (isLoad) {
            //共通部品の構築
            _buildCommonParts();
        }
        //コンテンツの設定
        _setupContents();
    }

    /* 外部ライブラリ
    --------------------------------------*/
    /**
     * 外部ライブラリを読み込む。
     */
    function _loadLibraries() {
        //console.debug('load libraries');

        //スタイルの追加
        const STYLE = function (path) {
            return '<link href="' + path + '" rel="stylesheet" />';
        };
        $('link').last()
            //日付選択
            .after(STYLE('refs/datepicker.css'))
            //ファイルアップロード
            .after(STYLE('refs/fileupload.css'))
            //グリッド
            .after(STYLE('refs/download/handsontable.min.css'));

        //スクリプトの追加
        const SCRIPT = function (path) {
            return '<script src="' + path + '"></script>';
        };
        $('script').last()
            //日付選択
            .before(SCRIPT('refs/datepicker.js'))
            //ファイルアップロード
            .before(SCRIPT('refs/fileupload.js'))
            //PDF
            .before(SCRIPT('refs/download/pdf.min.js'))
            .before(SCRIPT('refs/site-pdf.js'))
            //グラフ
            .before(SCRIPT('refs/download/Chart.min.js'))
            .before(SCRIPT('refs/site-chart.js'))
            //グリッド
            .before(SCRIPT('refs/download/handsontable.min.js'))
            .before(SCRIPT('refs/site-grid.js'));

        //PDFフォルダの設定
        Site.Pdf.setPdfDirectory('../../' + DEF_URL.PREFIX.REPORT);
    }

    /**
     * 外部ライブラリを初期化する。
     */
    function _initLibraries() {
        //日付選択
        Datepicker.initialize();
        //ファイルアップロード
        Fileupload.initialize();
        //PDF
        Site.Pdf.initialize();
        //グラフ
        Site.Chart.initialize();
        //グリッド
        Site.Grid.initialize();
    }

    /* 共通部品の構築
    --------------------------------------*/
    /**
     * 共通部品を構築する。
     */
    function _buildCommonParts() {
        var menuNo = Site.config.menuNo || 0,
            team = (menuNo < 2 ? '<span>（' + DEF_TEAM + '）</span>' : '');

        //ヘッダ要素の構築
        $('#header').html('<h1></h1>' + team);

        //メニューデータの取得
        _ajax(
            'json',
            DEF_URL.PREFIX.MENU + DEF_URL.MENU_DATA[menuNo] + DEF_URL.DATA_EXTENSION,
            function (json) {
                $('#menu')
                    //メニュー要素の構築
                    .html(__formatMenuHtml(json))
                    //イベントの登録
                    .delegate('a', 'click', menu_click)
                    //メニュー表示切替要素の追加
                    .after(__createMenuSwitchHtml());
                $('#menu-switch')
                    //イベント登録
                    .on('click', menuSwitch_click);
            }
        );
    }

    /**
     * JSON形式のデータからメニュー要素のHTMLを整形する。
     * @param {object} json メニューデータ
     * @returns {string} HTML
     */
    function __formatMenuHtml(json) {
        var jsonLength = json.length,
            html = '<ul>';
        for (var i = 0; i < jsonLength; i++) {
            var menus = json[i].menus,
                menusLength = menus.length;
            //カテゴリの追加
            html += '<li><span>' + json[i].category + '</span><ul>';
            for (var j = 0; j < menusLength; j++) {
                var menu = menus[j];
                //メニューの追加
                html += '<li><a href="'
                    + DEF_URL.PREFIX.PAGE + menu.link + '">' + menu.label + '</a></li>';
            }
            html += '</ul></li>';
        }
        html += '</ul>';
        return html;
    }

    /**
     * メニュー表示切替要素のHTMLを生成する。
     * @returns {string} HTML
     */
    function __createMenuSwitchHtml() {
        return '<a id="menu-switch" href="javascript:void(0)">'
            + '<svg viewbox="0 0 32 32">'
            + '<rect x="0" y="0" width="32" height="32" rx="5" />'
            + '<g>'
            + '<line x1="7" y1="9" x2="25" y2="9" />'
            + '<line x1="7" y1="16" x2="25" y2="16" />'
            + '<line x1="7" y1="23" x2="25" y2="23" />'
            + '</g>'
            + '</svg>'
            + '</a>';
    }

    /* コンテンツの設定
    --------------------------------------*/
    /**
     * コンテンツを設定する。
     */
    function _setupContents() {
        var title = Site.config.title,
            pageNavi = Site.config.pageNavi,
            contents = Site.config.contents;

        //タイトルの設定
        document.title = title;

        //ヘッダの設定
        $('#header > h1').text(title);

        //ページナビゲーションの編集
        if (pageNavi) {
            $('#current')
                //前ページ要素の追加
                .before(__createPageNavigationHtml(pageNavi.prev, true))
                //次ページ要素の追加
                .after(__createPageNavigationHtml(pageNavi.next, false));
            //イベント登録
            $('#page-prev').on('click', pagePrev_click);
            $('#page-next').on('click', pageNext_click);
        }

        //コンテンツデータの取得
        if (contents) {
            _ajax(
                'json',
                DEF_URL.PREFIX.DATA[contents.type] + contents.name + DEF_URL.DATA_EXTENSION,
                function (json) {
                    _contentsData = json;
                    //先頭ページへ遷移
                    _navigatePage(0);
                }
            );
        } else {
            //先頭ページへ遷移
            _navigatePage(0);
        }
    }

    /**
     * ページナビゲーション要素のHTMLを生成する。
     * @param {string} label ラベル
     * @param {boolean} isPrev 前ページフラグ
     * @returns {string} HTML
     */
    function __createPageNavigationHtml(label, isPrev) {
        var id = (isPrev ? 'page-prev' : 'page-next'),
            label1 = (isPrev ? '' : label),
            label2 = (isPrev ? label : ''),
            points = (isPrev ? '0,16 16,0 16,32' : '16,16 0,0 0,32');
        return '<a id="' + id + '" href="javascript:void(0);">'
            + label1
            + '<svg><polygon points="' + points + '"></polygon></svg>'
            + label2
            + '</a>';
    }


    //==============================================================================
    // 画面遷移
    //==============================================================================

    /* コンテンツ遷移
    --------------------------------------*/
    /**
     * サイト内の別コンテンツへ画面遷移を行う。(メニューリンク)
     * @param {string} url 要求するURL
     */
    function _navigateUrl(url) {
        //アドレスバーの書き換え
        history.replaceState(null, null, url);

        //HTTP要求
        _ajax(
            'html',
            url,
            function (html) {
                //個別スクリプト要素の入れ替え
                $('#script')
                    .after($(html).filter('#script'))
                    .remove();

                //コンテンツ要素の入れ替え
                $('#contents')
                    .after($(html).find('#contents'))
                    .remove();

                //初期化
                _initialize();
            }
        );
    }

    /* ページ遷移
    --------------------------------------*/
    /**
     * 指定したページへ遷移する。
     * @param {number} index ページ番号
     */
    function _navigatePage(index) {
        //読み込み中
        _loading();

        var pageNavi = Site.config.pageNavi;
        if (pageNavi) {
            //ページ番号の設定
            _pageIndex = (function (i, min, max) {
                //範囲内に設定
                i = (i < min ? min : max < i ? max : i);
                //ナビゲーションの表示切替
                $('#page-prev').css('visibility', i == max ? 'hidden' : 'visible');
                $('#page-next').css('visibility', i == min ? 'hidden' : 'visible');
                return i;
            }(index, 0, pageNavi.max - 1));
        }

        //コールバックの呼び出し
        Site.callbacks.navigatePage(_contentsData, _pageIndex);

        //読み込み完了
        _loaded();
    }

    /* エラー表示
    --------------------------------------*/
    /**
     * 指定した要素にエラーメッセージを表示する。
     * @param {string} errCode エラーコード
     * @param {string} selector 要素セレクタ
     */
    function _setError(errCode, selector) {
        $(selector || '#contents')
            .addClass('error')
            .html(DEF_ERROR[errCode] || DEF_ERROR.DEFAULT);
    }

    /* ローディング
    --------------------------------------*/
    /**
     * 読み込み中の画面表示に切り替える。
     * @param {string} selector 読み込み対象の要素セレクタ
     */
    function _loading(selector) {
        //読み込み中件数のチェック
        if (1 < ++_loadingCount) {
            //console.debug('..... loading (+)', _loadingCount);
        } else {
            //console.debug('..... loading start');
        }

        //ローディング要素の取得
        var $loading = $('#loading'),
            $target;

        //要素が存在しない場合
        if ($loading.length == 0) {
            //対象要素の取得
            $target = $(selector || '#contents');

            //ローディング要素の追加
            $loading = $('<div id="loading" />').hide();
            $target.after($loading);
        }
        //要素が存在する場合
        else {
            //対象要素の取得
            $target = $loading.prev();
        }

        //表示切替
        var offset = $target.offset();
        $loading
            .offset({ top: offset.top - 5, left: 0 })
            .height($target.height() + 10)
            .css('background-position', (($target.width() / 2) + offset.left - 48) + 'px 50px')
            .show();
    }

    /**
     * 全ての読み込みが完了した場合、読み込み中の画面表示を解除する。
     */
    function _loaded() {
        //読み込み中件数のチェック
        if (0 < --_loadingCount) {
            //console.debug('..... loading (-)', _loadingCount);
            return;
        }
        //console.debug('..... loading end');

        //ローディング要素の取得
        var $loading = $('#loading');
        $loading
            .fadeOut(100, function () {
                $loading.remove();
            });
    }


    //==============================================================================
    // 関数
    //==============================================================================

    /* HTTP通信
    --------------------------------------*/
    /**
     * 非同期でHTTP通信を行う。
     * @param {string} dataType データタイプ(json or html)
     * @param {string} url 要求するURL
     * @param {function} callback 応答を処理するコールバック
     */
    function _ajax(dataType, url, callback) {
        //console.debug('ajax:', dataType, '>', url);
        //読み込み中
        _loading();

        //HTTP要求
        $.ajax({
            type: 'get',
            url: url,
            dataType: dataType,
            cache: false
        })
            //成功した場合の処理
            .done(function (data, textStatus, jqXHR) {
                //console.debug('ajax:', dataType, '> (done)', jqXHR.status);
                //コールバックの呼び出し
                callback(data);
            })
            //失敗した場合の処理
            .fail(function (jqXHR, textStatus, errorThrown) {
                //console.debug('ajax:', dataType, '> (fail)', jqXHR.status, errorThrown);
                //エラー表示
                _setError(dataType.toUpperCase() + '_' + jqXHR.status);
            })
            //常に実行する処理
            .always(function () {
                //console.debug('ajax:', dataType, '> (always)');
                //読み込み完了
                _loaded();
            });
    }


    //==============================================================================
    // イベント
    //==============================================================================
    document.addEventListener('DOMContentLoaded', document_DOMContentLoaded, false);
    window.addEventListener('load', window_load, false);
    window.addEventListener('beforeunload', window_beforeunload, false);

    /**
     * DOMツリー構築完了時のイベントを処理する。
     */
    function document_DOMContentLoaded() {
        //console.debug('↓↓↓ document.DOMContentLoaded  ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  -- site.js');

        //読み込み中
        _loading();

        //初期化
        _initialize(true);

        //console.debug('↑↑↑ document.DOMContentLoaded  ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  -- site.js');
    }

    /**
     * ロード完了時のイベントを処理する。
     */
    function window_load() {
        //console.debug('↓↓↓ window.load                ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  -- site.js');

        //読み込み完了
        _loaded();

        //console.debug('↑↑↑ window.load                ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  -- site.js');
    }

    /**
     * アンロード前のイベントを処理する。
     */
    function window_beforeunload() {
        //console.debug('↓↓↓ window.beforeunload        ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  -- site.js');

        //console.debug('↑↑↑ window.beforeunload        ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  -- site.js');
    }

    /**
     * メニューのクリックイベントを処理する。
     */
    function menu_click() {
        //console.debug('↓↓↓ menu.click                 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  -- site.js');

        //コンテンツ遷移
        _navigateUrl($(this).attr('href'));

        //console.debug('↑↑↑ menu.click                 ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  -- site.js');

        //遷移のキャンセル(非同期で実装)
        return false;
    }

    /**
     * メニュー表示切替のクリックイベントを処理する。
     */
    function menuSwitch_click() {
        //console.debug('↓↓↓ menu-switch.click          ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  -- site.js');

        //メニュー表示切替
        $('body').toggleClass('menu-hide');

        //console.debug('↑↑↑ menu-switch.click          ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  -- site.js');
    }

    /**
     * ページナビゲーション(前ページ)のクリックイベントを処理する。
     */
    function pagePrev_click() {
        //console.debug('↓↓↓ page-prev.click            ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  -- site.js');

        //前ページへ遷移
        _navigatePage(_pageIndex + 1);

        //console.debug('↑↑↑ page-prev.click            ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  -- site.js');
    }

    /**
     * ページナビゲーション(次ページ)のクリックイベントを処理する。
     */
    function pageNext_click() {
        //console.debug('↓↓↓ page-next.click            ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  -- site.js');

        //次ページへ遷移
        _navigatePage(_pageIndex - 1);

        //console.debug('↑↑↑ page-next.click            ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  -- site.js');
    }


    //==============================================================================
    // 公開(Site.*)
    //==============================================================================
    return {
        config: {},


        setError: _setError,
        loading: _loading,
        loaded: _loaded,


        /**
         * 
         */
        callbacks: {
            configure: function () { },
            navigatePage: function (contentsData, index) { }
        }
    };
}());