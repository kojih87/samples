Site.Grid = (function () {
    //==============================================================================
    // 環境設定
    //==============================================================================
    /* 変数
    --------------------------------------*/
    /** 要素セレクタに対応するグリッド操作オブジェクト */
    var _grid;


    //==============================================================================
    // 関数
    //==============================================================================
    /* 初期化
    --------------------------------------*/
    /**
     * ライブラリを初期化する。
     */
    function _initialize() {
        //既存のグリッド操作オブジェクトの破棄
        for(var i in _grid) {
            _grid[i].destroy();
            _grid[i] = null;
        }
        _grid = {};
    }

    /* オブジェクト
    --------------------------------------*/
    /**
     * グリッド操作オブジェクトを生成する。
     * @param {string} selector 要素セレクタ
     * @param {HTMLDivElement} container 要素
     */
    function _createObject(selector) {
        var conf = Site.config.grid[selector],
            callbacks = conf.callbacks || {},
            container = document.querySelector(selector);
        return new Handsontable(container, {
            //全体
            height: conf.height,
            //行
            rowHeaders: true,
            minRows: 1,

            //列
            colHeaders: true,
            columns: conf.columns,
            autoColumnSize: false,

            //データ
            data: [],

            //コンテキストメニュー
            contextMenu: {
                items: {
                    'row_above': { name: '上に行を挿入' },
                    'row_below': { name: '下に行を挿入' },
                    '---------': null,
                    'remove_row': { name: '行を削除' }
                }
            },

            afterDeselect: function(){
                console.debug('afterDeselect');
                //空行の削除
                var countRows = this.countRows();
                for (var row = countRows - 1; 0 <= row; row--) {
                    if(this.isEmptyRow(row)) {
                        this.alter('remove_row', row);
                    }
                }
            }
        });
    }

    /* 更新
    --------------------------------------*/

    function _setDropdownList(selector, col, items) {
        if(!_grid[selector]){
            return;
        }
        _grid[selector].view.settings.columns[col].source = items;
    }



    function _update(selector, data) {
        //
        if (!_grid[selector]) {
            _grid[selector] = _createObject(selector);
        }

        _grid[selector].loadData(data);
    }

    /* データ取得
    --------------------------------------*/

    /* データ取得
    --------------------------------------*/
    /**
     * 指定した列のデータを取得する。
     * @param {string} selector 要素セレクタ
     * @param {number} no 列番号(0～)
     */
    function _getDataAtCol(selector, no) {
        if(_grid[selector]){
            return _grid[selector].getDataAtCol(no);
        }
        return [];
    }

    /**
     * 
     * @param {string} selector 要素セレクタ
     */
    function _getData(selector) {
        return _grid[selector].getSourceData();
    }

    //==============================================================================
    // 公開(Site.Grid.*)
    //==============================================================================
    return {
        /**
         * ライブラリを初期化する。
         */
        initialize: _initialize,

        getDataAtCol: _getDataAtCol,
        setDropdownList: _setDropdownList,

        update: _update,
        getData: _getData,
    };
}());